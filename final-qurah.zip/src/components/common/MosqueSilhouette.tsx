import React from 'react';

interface MosqueSilhouetteProps {
  className?: string;
  showText?: boolean;
}

export const MosqueSilhouette: React.FC<MosqueSilhouetteProps> = ({
  className = 'w-24 h-16 opacity-30',
  showText = true,
}) => {
  return (
    <div className="flex flex-col items-center justify-center pointer-events-none select-none">
      <svg
        viewBox="0 0 120 70"
        fill="currentColor"
        className={className}
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Left Minaret */}
        <rect x="14" y="24" width="5" height="42" rx="1" />
        <polygon points="16.5,12 13,24 20,24" />
        <circle cx="16.5" cy="11" r="1.5" />

        {/* Left-center small dome */}
        <path d="M 24 66 L 24 38 Q 33 24 42 38 L 42 66 Z" />
        <polygon points="33,21 31.5,24 34.5,24" />

        {/* Central Grand Dome */}
        <path d="M 40 66 L 40 34 Q 60 12 80 34 L 80 66 Z" />
        {/* Dome Crescent Finial */}
        <line x1="60" y1="12" x2="60" y2="4" stroke="currentColor" strokeWidth="1.5" />
        <path
          d="M 60 5 A 3 3 0 1 1 61.5 2 A 2.2 2.2 0 1 0 60 5 Z"
          fill="currentColor"
        />

        {/* Right-center small dome */}
        <path d="M 78 66 L 78 38 Q 87 24 96 38 L 96 66 Z" />
        <polygon points="87,21 85.5,24 88.5,24" />

        {/* Right Minaret */}
        <rect x="101" y="24" width="5" height="42" rx="1" />
        <polygon points="103.5,12 100,24 107,24" />
        <circle cx="103.5" cy="11" r="1.5" />

        {/* Base line */}
        <rect x="8" y="66" width="104" height="2" rx="1" />
      </svg>

      {showText && (
        <span className="text-[10px] tracking-wider text-slate-500 font-medium mt-1 uppercase">
          Together We Grow
        </span>
      )}
    </div>
  );
};
