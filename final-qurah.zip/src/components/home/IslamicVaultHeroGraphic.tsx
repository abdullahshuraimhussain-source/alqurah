import React from 'react';

export const IslamicVaultHeroGraphic: React.FC = () => {
  return (
    <div className="relative w-full max-w-[440px] aspect-square flex items-center justify-center select-none">
      {/* Ambient background glow */}
      <div className="absolute inset-0 bg-radial from-slate-700/20 via-slate-900/10 to-transparent blur-2xl rounded-full pointer-events-none" />

      {/* SVG 3D Islamic Mihrab Arch + Open Safe Vault + Silver Coins + Crescent + Olive Branch */}
      <svg
        viewBox="0 0 500 500"
        className="w-full h-full drop-shadow-[0_20px_35px_rgba(0,0,0,0.8)] overflow-visible"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Gradients for Mihrab Arch */}
          <linearGradient id="archOuter" x1="250" y1="30" x2="250" y2="440" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#475569" />
            <stop offset="25%" stopColor="#1e293b" />
            <stop offset="70%" stopColor="#0f172a" />
            <stop offset="100%" stopColor="#020617" />
          </linearGradient>

          <linearGradient id="archRim" x1="100" y1="40" x2="400" y2="440" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#94a3b8" />
            <stop offset="50%" stopColor="#334155" />
            <stop offset="100%" stopColor="#0f172a" />
          </linearGradient>

          <linearGradient id="archInnerRecess" x1="250" y1="50" x2="250" y2="430" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#0f141e" />
            <stop offset="50%" stopColor="#07090e" />
            <stop offset="100%" stopColor="#020408" />
          </linearGradient>

          {/* Crescent Moon Glow */}
          <radialGradient id="moonGlow" cx="250" cy="120" r="50" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.9" />
            <stop offset="50%" stopColor="#cbd5e1" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#0f172a" stopOpacity="0" />
          </radialGradient>

          {/* Safe Vault Body Gradients */}
          <linearGradient id="safeFront" x1="170" y1="210" x2="350" y2="380" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#334155" />
            <stop offset="50%" stopColor="#1e293b" />
            <stop offset="100%" stopColor="#0f172a" />
          </linearGradient>

          <linearGradient id="safeBevel" x1="160" y1="200" x2="360" y2="390" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#64748b" />
            <stop offset="20%" stopColor="#334155" />
            <stop offset="80%" stopColor="#0f172a" />
            <stop offset="100%" stopColor="#020617" />
          </linearGradient>

          <linearGradient id="safeInterior" x1="200" y1="230" x2="310" y2="340" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#020408" />
            <stop offset="60%" stopColor="#090d14" />
            <stop offset="100%" stopColor="#1e293b" />
          </linearGradient>

          {/* Safe Door Gradient (Angled Open Door) */}
          <linearGradient id="safeDoor" x1="290" y1="220" x2="395" y2="360" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#475569" />
            <stop offset="40%" stopColor="#334155" />
            <stop offset="80%" stopColor="#1e293b" />
            <stop offset="100%" stopColor="#0f172a" />
          </linearGradient>

          {/* Metallic Coin Gradient */}
          <linearGradient id="silverCoin" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="30%" stopColor="#cbd5e1" />
            <stop offset="70%" stopColor="#64748b" />
            <stop offset="100%" stopColor="#334155" />
          </linearGradient>

          <linearGradient id="silverCoinEdge" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#94a3b8" />
            <stop offset="50%" stopColor="#475569" />
            <stop offset="100%" stopColor="#1e293b" />
          </linearGradient>

          {/* Olive Leaf Silver Gradient */}
          <linearGradient id="silverLeaf" x1="380" y1="180" x2="440" y2="320" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#f8fafc" />
            <stop offset="40%" stopColor="#cbd5e1" />
            <stop offset="80%" stopColor="#64748b" />
            <stop offset="100%" stopColor="#334155" />
          </linearGradient>

          {/* Floor Shadow Filter */}
          <radialGradient id="groundShadow" cx="250" cy="420" rx="180" ry="30" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#000000" stopOpacity="0.9" />
            <stop offset="60%" stopColor="#000000" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#000000" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* 1. Ground Shadow */}
        <ellipse cx="250" cy="420" rx="190" ry="28" fill="url(#groundShadow)" />

        {/* 2. ISLAMIC POINTED ARCH (Mihrab Backdrop) */}
        {/* Outer Frame */}
        <path
          d="M 120 420
             L 120 220
             C 120 120, 210 50, 250 35
             C 290 50, 380 120, 380 220
             L 380 420
             Z"
          fill="url(#archOuter)"
          stroke="url(#archRim)"
          strokeWidth="6"
        />

        {/* Inner Bevel Contour */}
        <path
          d="M 136 415
             L 136 222
             C 136 135, 215 72, 250 58
             C 285 72, 364 135, 364 222
             L 364 415
             Z"
          fill="url(#archInnerRecess)"
          stroke="rgba(255, 255, 255, 0.12)"
          strokeWidth="2"
        />

        {/* Inside Arch: Mosque Silhouettes & Crescent Moon */}
        <g opacity="0.45">
          {/* Left Minaret silhouette inside arch */}
          <path d="M 170 320 L 170 240 L 175 220 L 178 240 L 178 320 Z" fill="#1e293b" />
          <line x1="174" y1="210" x2="174" y2="220" stroke="#475569" strokeWidth="2" />
          {/* Right Mosque Dome silhouette inside arch */}
          <path d="M 280 340 L 280 260 C 280 230, 330 230, 330 260 L 330 340 Z" fill="#1e293b" />
          <circle cx="305" cy="225" r="3" fill="#64748b" />
        </g>

        {/* Crescent Moon Glow & Moon Shape */}
        <circle cx="250" cy="120" r="36" fill="url(#moonGlow)" />
        <path
          d="M 258 102
             A 22 22 0 1 0 258 138
             A 17 17 0 1 1 258 102 Z"
          fill="#ffffff"
          className="drop-shadow-[0_0_12px_rgba(255,255,255,0.8)]"
        />
        {/* Tiny star beside crescent */}
        <circle cx="268" cy="115" r="2" fill="#ffffff" />

        {/* 3. METALLIC SAFE VAULT (3D Box in Center) */}
        {/* Outer Vault Frame */}
        <rect
          x="165"
          y="210"
          width="170"
          height="165"
          rx="22"
          fill="url(#safeFront)"
          stroke="url(#safeBevel)"
          strokeWidth="7"
          className="drop-shadow-[0_15px_25px_rgba(0,0,0,0.9)]"
        />

        {/* Recessed Interior Cavity (When Door is Open) */}
        <rect
          x="180"
          y="225"
          width="125"
          height="135"
          rx="14"
          fill="url(#safeInterior)"
          stroke="#0f172a"
          strokeWidth="3"
        />

        {/* Shelf inside safe */}
        <line x1="180" y1="285" x2="305" y2="285" stroke="#334155" strokeWidth="3" />

        {/* Coins inside safe on upper & lower shelf */}
        {/* Upper shelf coins */}
        <g>
          <ellipse cx="230" cy="278" rx="14" ry="4" fill="url(#silverCoin)" />
          <ellipse cx="230" cy="274" rx="14" ry="4" fill="url(#silverCoin)" stroke="#94a3b8" strokeWidth="0.5" />
          <ellipse cx="255" cy="280" rx="12" ry="3.5" fill="url(#silverCoin)" />
          <ellipse cx="255" cy="276" rx="12" ry="3.5" fill="url(#silverCoin)" stroke="#94a3b8" strokeWidth="0.5" />
        </g>

        {/* Lower shelf coins & bullion stack */}
        <g>
          <rect x="200" y="325" width="28" height="12" rx="2" fill="url(#silverCoin)" stroke="#64748b" strokeWidth="1" />
          <rect x="204" y="318" width="20" height="8" rx="1.5" fill="url(#silverCoin)" stroke="#94a3b8" strokeWidth="1" />
          {/* Stacked coins */}
          <ellipse cx="260" cy="340" rx="16" ry="5" fill="url(#silverCoin)" />
          <ellipse cx="260" cy="335" rx="16" ry="5" fill="url(#silverCoin)" />
          <ellipse cx="260" cy="330" rx="16" ry="5" fill="url(#silverCoin)" />
          <ellipse cx="260" cy="325" rx="16" ry="5" fill="url(#silverCoin)" stroke="#ffffff" strokeWidth="0.8" />
        </g>

        {/* 4. SAFE DOOR (Swung open to the right with 3D perspective) */}
        <path
          d="M 305 225
             L 375 235
             C 382 236, 386 242, 386 249
             L 386 345
             C 386 352, 382 357, 375 358
             L 305 360
             Z"
          fill="url(#safeDoor)"
          stroke="#64748b"
          strokeWidth="3.5"
          className="drop-shadow-[-8px_10px_15px_rgba(0,0,0,0.8)]"
        />

        {/* Door Bevel Edge */}
        <line x1="305" y1="228" x2="305" y2="357" stroke="#94a3b8" strokeWidth="3" />

        {/* Door Dial / Wheel Handle on open door */}
        <circle cx="348" cy="295" r="18" fill="#1e293b" stroke="#94a3b8" strokeWidth="3" />
        <circle cx="348" cy="295" r="10" fill="#0f172a" stroke="#cbd5e1" strokeWidth="2" />
        {/* Turn spokes on dial */}
        <line x1="348" y1="275" x2="348" y2="315" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" />
        <line x1="328" y1="295" x2="368" y2="295" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" />
        <circle cx="348" cy="295" r="4" fill="#ffffff" />

        {/* Keyhole below dial */}
        <circle cx="348" cy="326" r="3" fill="#020617" />
        <polygon points="346.5,326 349.5,326 350.5,333 345.5,333" fill="#020617" />

        {/* 5. LEFT FOREGROUND: Stacks of Silver Coins & Miniature Minaret */}
        {/* Miniature Minaret spire on left */}
        <g>
          {/* Base */}
          <rect x="135" y="345" width="22" height="35" rx="3" fill="url(#silverCoinEdge)" stroke="#475569" strokeWidth="1" />
          {/* Mid balustrade */}
          <rect x="132" y="340" width="28" height="6" rx="2" fill="url(#silverCoin)" />
          {/* Tower shaft */}
          <rect x="138" y="295" width="16" height="46" rx="2" fill="url(#silverCoinEdge)" stroke="#64748b" strokeWidth="1" />
          {/* Dome & spire */}
          <path d="M 138 295 C 138 275, 154 275, 154 295 Z" fill="url(#silverCoin)" stroke="#94a3b8" strokeWidth="1" />
          <line x1="146" y1="265" x2="146" y2="278" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />
          <circle cx="146" cy="265" r="2" fill="#ffffff" />
        </g>

        {/* Tall Stacks of Coins (Front Left) */}
        {/* Stack 1 (Middle) */}
        <g>
          {[0, 6, 12, 18, 24, 30].map((offset, i) => (
            <g key={`coin1-${i}`}>
              <path
                d={`M 115 ${370 - offset}
                    L 115 ${376 - offset}
                    A 20 6 0 0 0 155 ${376 - offset}
                    L 155 ${370 - offset}
                    Z`}
                fill="url(#silverCoinEdge)"
              />
              <ellipse
                cx="135"
                cy={370 - offset}
                rx="20"
                ry="6"
                fill="url(#silverCoin)"
                stroke="rgba(255,255,255,0.6)"
                strokeWidth="0.75"
              />
            </g>
          ))}
        </g>

        {/* Stack 2 (Frontmost Left) */}
        <g>
          {[0, 6, 12, 18].map((offset, i) => (
            <g key={`coin2-${i}`}>
              <path
                d={`M 145 ${390 - offset}
                    L 145 ${396 - offset}
                    A 22 7 0 0 0 189 ${396 - offset}
                    L 189 ${390 - offset}
                    Z`}
                fill="url(#silverCoinEdge)"
              />
              <ellipse
                cx="167"
                cy={390 - offset}
                rx="22"
                ry="7"
                fill="url(#silverCoin)"
                stroke="rgba(255,255,255,0.7)"
                strokeWidth="0.8"
              />
            </g>
          ))}
        </g>

        {/* Single coin lying tilted */}
        <ellipse cx="205" cy="405" rx="16" ry="5" fill="url(#silverCoin)" stroke="#cbd5e1" strokeWidth="0.8" />

        {/* 6. RIGHT FOREGROUND: Silver Dial Medallion with "6" & Olive Branch Leaves */}
        {/* Silver Medallion Token with numeral "6" (Matching screenshot) */}
        <g className="drop-shadow-[0_10px_15px_rgba(0,0,0,0.8)]">
          {/* Thick rim */}
          <circle cx="395" cy="365" r="26" fill="url(#silverCoinEdge)" stroke="#94a3b8" strokeWidth="2.5" />
          <circle cx="395" cy="365" r="21" fill="url(#silverCoin)" stroke="#ffffff" strokeWidth="1" />
          <circle cx="395" cy="365" r="16" fill="#1e293b" stroke="#475569" strokeWidth="1" />
          {/* Numeral "6" */}
          <text
            x="395"
            y="372"
            fill="#ffffff"
            fontSize="18"
            fontWeight="900"
            fontFamily="Plus Jakarta Sans, sans-serif"
            textAnchor="middle"
          >
            6
          </text>
        </g>

        {/* Elegant Silver Olive / Palm Branch Leaves (Matching screenshot) */}
        <g className="drop-shadow-[0_10px_20px_rgba(0,0,0,0.6)]">
          {/* Curved Stem */}
          <path
            d="M 405 350
               C 420 300, 430 250, 435 190"
            stroke="#94a3b8"
            strokeWidth="3"
            strokeLinecap="round"
          />

          {/* Leaves along stem */}
          {/* Leaf 1 (Top) */}
          <path
            d="M 435 190
               C 445 180, 452 165, 452 150
               C 438 160, 430 175, 435 190 Z"
            fill="url(#silverLeaf)"
            stroke="#ffffff"
            strokeWidth="0.8"
          />
          {/* Leaf 2 (Upper right) */}
          <path
            d="M 433 210
               C 448 205, 465 210, 472 220
               C 455 222, 442 218, 433 210 Z"
            fill="url(#silverLeaf)"
            stroke="#ffffff"
            strokeWidth="0.8"
          />
          {/* Leaf 3 (Upper left) */}
          <path
            d="M 428 230
               C 412 220, 396 222, 388 232
               C 402 236, 418 235, 428 230 Z"
            fill="url(#silverLeaf)"
            stroke="#cbd5e1"
            strokeWidth="0.8"
          />
          {/* Leaf 4 (Mid right) */}
          <path
            d="M 425 255
               C 442 255, 458 265, 464 278
               C 446 276, 434 268, 425 255 Z"
            fill="url(#silverLeaf)"
            stroke="#ffffff"
            strokeWidth="0.8"
          />
          {/* Leaf 5 (Mid left) */}
          <path
            d="M 418 280
               C 400 270, 385 275, 378 288
               C 394 290, 408 286, 418 280 Z"
            fill="url(#silverLeaf)"
            stroke="#cbd5e1"
            strokeWidth="0.8"
          />
          {/* Leaf 6 (Lower right) */}
          <path
            d="M 412 305
               C 426 312, 438 325, 442 340
               C 428 335, 418 322, 412 305 Z"
            fill="url(#silverLeaf)"
            stroke="#ffffff"
            strokeWidth="0.8"
          />
        </g>
      </svg>
    </div>
  );
};
