import React, { useState } from 'react';
import {
  Plus,
  Search,
  ChevronRight,
  Users,
  Shield,
  Layers,
} from 'lucide-react';
import { Qurah, User } from '../types';
import { Footer } from './Footer';

interface WorkspacePageProps {
  currentUser: User | null;
  quras: Qurah[];
  onCreateQurahClick: () => void;
  onSelectQura: (quraId: string) => void;
  onNavigate?: (page: 'home' | 'workspace') => void;
}

export const WorkspacePage: React.FC<WorkspacePageProps> = ({
  currentUser,
  quras,
  onCreateQurahClick,
  onSelectQura,
  onNavigate,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  // Filter Quras by search query
  const filteredQuras = quras.filter((q) =>
    q.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    q.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen flex flex-col bg-[#050608] text-white">
      {/* MAIN WORKSPACE CONTENT - Clean layout without top sidebar */}
      <main className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1">
        {/* Header Row: "Your Qurahs" + Search + "+ Create Qurah" */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">Your Qurahs</h1>
            <p className="text-xs text-slate-400 mt-1">
              Select any Qurah to view its Dashboard, Al Qurah Payment, and Document certificates.
            </p>
          </div>

          <div className="flex items-center gap-3">
            {/* Search Bar */}
            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 absolute left-3.5 top-3 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search Qurah..."
                className="w-full bg-[#131720] border border-white/10 rounded-full pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-white/30 transition-colors"
              />
            </div>

            {/* + Create Qurah Button */}
            <button
              type="button"
              onClick={onCreateQurahClick}
              className="shrink-0 px-4 py-2 rounded-full bg-white text-slate-950 hover:bg-slate-200 text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create Qurah</span>
            </button>
          </div>
        </div>

        {/* Qurahs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Tile 1: Dashed "+ Create Qurah" Card */}
          <div
            onClick={onCreateQurahClick}
            className="border-2 border-dashed border-white/15 hover:border-white/30 rounded-2xl p-6 flex flex-col items-center justify-center text-center cursor-pointer group bg-[#0b0e14]/40 hover:bg-[#0b0e14]/80 transition-all min-h-[170px]"
          >
            <div className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-slate-400 group-hover:text-white group-hover:scale-110 transition-all mb-3">
              <Plus className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-slate-300 group-hover:text-white">Create Qurah</span>
            <span className="text-[11px] text-slate-500 mt-1">Start a new revolving committee</span>
          </div>

          {/* Active User Qurahs */}
          {filteredQuras.map((qura) => {
            const completedCycles = qura.cycles.filter((c) => c.status === 'completed').length;
            const progressPct = Math.round((completedCycles / qura.memberCount) * 100);

            return (
              <div
                key={qura.id}
                onClick={() => onSelectQura(qura.id)}
                className="bg-[#0b0e14] hover:bg-[#10141d] border border-white/10 hover:border-white/20 rounded-2xl p-5 flex flex-col justify-between cursor-pointer transition-all duration-150 group shadow-sm hover:shadow-md"
              >
                <div>
                  {/* Top Row: Icon + Name + Chevron */}
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-[#1b2230] border border-white/10 flex items-center justify-center text-slate-200 font-bold shrink-0">
                        {qura.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-white group-hover:text-slate-100 transition-colors line-clamp-1">
                          {qura.name}
                        </h3>
                        <div className="text-[11px] text-slate-400 mt-0.5">
                          {qura.memberCount} Members
                        </div>
                      </div>
                    </div>

                    <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-white transition-colors shrink-0 mt-1" />
                  </div>

                  {/* Stats */}
                  <div className="flex items-center justify-between text-xs py-1">
                    <span className="text-slate-400 font-medium">Per Member:</span>
                    <span className="font-extrabold font-mono text-white">
                      {qura.currencySymbol || 'Rs'} {qura.amountPerMember.toLocaleString()}
                    </span>
                  </div>

                  <div className="text-xs text-slate-400 mt-0.5 font-medium">
                    Cycle {qura.currentCycleNumber} of {qura.memberCount}
                  </div>
                </div>

                {/* Progress Bar & Percentage */}
                <div className="mt-4 pt-3 border-t border-white/5 flex items-center gap-3">
                  <div className="flex-1 h-1.5 bg-[#1b2230] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-white rounded-full transition-all duration-300"
                      style={{ width: `${Math.max(5, progressPct)}%` }}
                    />
                  </div>
                  <span className="text-[11px] font-mono text-slate-400 shrink-0">
                    {progressPct}%
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Empty State when no Qurahs exist */}
        {quras.length === 0 && (
          <div className="mt-8 bg-[#0b0e14] border border-white/10 rounded-2xl p-8 sm:p-12 text-center max-w-lg mx-auto">
            <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mx-auto mb-4 text-slate-300">
              <Layers className="w-7 h-7" />
            </div>
            <h3 className="text-base font-bold text-white">No Qurahs Created Yet</h3>
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">
              You haven&apos;t created any Qurah committee yet. Create one now to manage members, record installment payments, and run automated interest-free lucky draws.
            </p>
            <button
              type="button"
              onClick={onCreateQurahClick}
              className="mt-5 px-5 py-2.5 rounded-full bg-white text-slate-950 hover:bg-slate-200 text-xs font-bold inline-flex items-center gap-2 shadow-sm transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <Plus className="w-4 h-4" />
              <span>Create Your First Qurah</span>
            </button>
          </div>
        )}

        {/* Filter Empty State (when search query doesn't match) */}
        {quras.length > 0 && filteredQuras.length === 0 && (
          <div className="text-center py-16 text-slate-500 text-xs">
            No Qurahs match &quot;{searchQuery}&quot;. Clear search to see all Qurahs.
          </div>
        )}
      </main>

      {/* Compact Footer */}
      <Footer onNavigate={onNavigate} />
    </div>
  );
};
