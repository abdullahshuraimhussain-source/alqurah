import React from 'react';

interface FooterProps {
  onNavigate?: (page: 'home' | 'workspace') => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-[#050608] border-t border-white/10 text-slate-400 text-xs mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
        {/* Brand & Mini Tagline */}
        <div className="flex items-center gap-2.5">
          <div
            className="flex items-center gap-2 cursor-pointer text-white group"
            onClick={() => onNavigate && onNavigate('home')}
          >
            <div className="w-5 h-5 rounded-md bg-white/10 flex items-center justify-center text-white border border-white/15 group-hover:bg-white/20 transition-colors">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" className="w-3 h-3">
                <path d="M4 21V10C4 6 7.5 3 12 3C16.5 3 20 6 20 10V21" />
                <path d="M9 21V13C9 11.5 10.5 10 12 10C13.5 10 15 11.5 15 13V21" />
              </svg>
            </div>
            <span className="text-xs font-black tracking-wider text-white">AL QURA</span>
          </div>

          <span className="text-slate-600 hidden sm:inline">&bull;</span>
          <span className="text-[11px] text-slate-500 hidden sm:inline">
            Interest-Free Halal Committee System
          </span>
        </div>

        {/* Minimal Navigation & Copyright */}
        <div className="flex items-center gap-4 text-[11px] text-slate-400">
          <button
            onClick={() => onNavigate && onNavigate('home')}
            className="hover:text-white transition-colors cursor-pointer"
          >
            Home
          </button>
          <button
            onClick={() => onNavigate && onNavigate('workspace')}
            className="hover:text-white transition-colors cursor-pointer"
          >
            Your Qurahs
          </button>
          <button
            onClick={() => onNavigate && (onNavigate as any)('404')}
            className="text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
          >
            404 Preview
          </button>
          <span className="text-slate-600">&bull;</span>
          <span className="text-slate-500">
            &copy; {new Date().getFullYear()} Al Qura
          </span>
        </div>
      </div>
    </footer>
  );
};
