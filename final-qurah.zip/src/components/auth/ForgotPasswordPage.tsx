import React, { useState } from 'react';
import { Mail, Lock, AlertCircle, ArrowLeft, CheckCircle2, ShieldCheck, Loader2 } from 'lucide-react';
// @ts-ignore
import { supabase } from '../../supabaseClient';

interface ForgotPasswordPageProps {
  onNavigateToLogin: () => void;
  isUpdatingPassword?: boolean;
  onPasswordUpdated?: () => void;
}

export const ForgotPasswordPage: React.FC<ForgotPasswordPageProps> = ({
  onNavigateToLogin,
  isUpdatingPassword = false,
  onPasswordUpdated,
}) => {
  const [email, setEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleRequestReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      setErrorMessage('Please enter your email address.');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
        redirectTo: `${window.location.origin}/#reset-password`,
      });
      if (error) {
        setErrorMessage(error.message);
      } else {
        setIsSuccess(true);
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to send password reset instructions.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || newPassword.length < 6) {
      setErrorMessage('New password must be at least 6 characters.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setErrorMessage('Passwords do not match.');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      const { error } = await supabase.auth.updateUser({
        password: newPassword,
      });
      if (error) {
        setErrorMessage(error.message);
      } else {
        setIsSuccess(true);
        if (onPasswordUpdated) {
          setTimeout(onPasswordUpdated, 1500);
        }
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to update your password.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex-1 flex items-center justify-center p-4 sm:p-6 py-12 bg-[#050608]">
      <div className="w-full max-w-md bg-[#0b0e14] border border-white/10 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        {/* Top Mosque Logo & Wordmark */}
        <div className="flex flex-col items-center text-center mb-6">
          <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center text-white border border-white/15 mb-3 shadow-inner">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" className="w-7 h-7">
              <path d="M4 21V10C4 6 7.5 3 12 3C16.5 3 20 6 20 10V21" />
              <path d="M9 21V13C9 11.5 10.5 10 12 10C13.5 10 15 11.5 15 13V21" />
            </svg>
          </div>
          <span className="text-sm font-extrabold tracking-widest text-white uppercase">AL QURA</span>
          <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white mt-2">
            {isUpdatingPassword ? 'Set New Password' : 'Reset Password'}
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-xs">
            {isUpdatingPassword
              ? 'Enter a new secure password for your Al Qura account.'
              : 'Enter your account email and we will send you password reset instructions.'}
          </p>
        </div>

        {/* Success State */}
        {isSuccess ? (
          <div className="p-5 rounded-2xl bg-emerald-500/10 border border-emerald-500/25 text-center space-y-3 animate-in fade-in duration-200">
            <div className="w-10 h-10 rounded-full bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center mx-auto text-emerald-400">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-white">
              {isUpdatingPassword ? 'Password Successfully Updated!' : 'Reset Link Sent'}
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              {isUpdatingPassword
                ? 'Your password has been changed. You can now sign in with your new credentials.'
                : `We have sent a secure password recovery link to ${email || 'your email'}. Please check your inbox.`}
            </p>
            <button
              type="button"
              onClick={onNavigateToLogin}
              className="w-full mt-2 px-5 py-2.5 rounded-full bg-white text-slate-950 hover:bg-slate-200 text-xs font-bold transition-all"
            >
              Back to Sign In
            </button>
          </div>
        ) : isUpdatingPassword ? (
          <>
            {/* Set New Password Form */}
            <form onSubmit={handleUpdatePassword} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">New Password *</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                  <input
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Min. 6 characters"
                    required
                    className="w-full bg-[#161a24] border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-white/40 font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">Confirm New Password *</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Repeat new password"
                    required
                    className="w-full bg-[#161a24] border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-white/40 font-medium"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full flex items-center justify-center gap-2 px-6 py-2.5 rounded-full bg-white text-slate-950 hover:bg-slate-200 text-xs font-bold transition-all disabled:opacity-50 mt-2 shadow-sm cursor-pointer"
              >
                {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <span>Update Password</span>}
              </button>
            </form>

            {/* Error under form */}
            {errorMessage && (
              <div
                id="auth-error-message"
                className="mt-3 p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-start gap-2 animate-in fade-in duration-150"
              >
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span className="flex-1 font-medium">{errorMessage}</span>
              </div>
            )}
          </>
        ) : (
          <>
            {/* Request Password Reset Form */}
            <form onSubmit={handleRequestReset} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">Email Address</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    required
                    className="w-full bg-[#161a24] border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-white/40 font-medium"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full flex items-center justify-center gap-2 px-6 py-2.5 rounded-full bg-white text-slate-950 hover:bg-slate-200 text-xs font-bold transition-all disabled:opacity-50 mt-2 shadow-sm cursor-pointer"
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <span>Send Reset Link</span>
                )}
              </button>
            </form>

            {/* Error under form */}
            {errorMessage && (
              <div
                id="auth-error-message"
                className="mt-3 p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-start gap-2 animate-in fade-in duration-150"
              >
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span className="flex-1 font-medium">{errorMessage}</span>
              </div>
            )}
          </>
        )}

        {/* Back to Login Link */}
        <div className="mt-6 pt-5 border-t border-white/10 text-center">
          <button
            type="button"
            onClick={onNavigateToLogin}
            className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Sign In</span>
          </button>
        </div>

        {/* Safe Guarantee */}
        <div className="mt-4 flex items-center justify-center gap-1.5 text-[11px] text-slate-500 font-mono">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Encrypted Authentication Flow</span>
        </div>
      </div>
    </div>
  );
};
