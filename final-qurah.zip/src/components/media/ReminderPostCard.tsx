import React, { useRef, useEffect, useState } from 'react';
import { Download, Clock, Copy, Check, Share2, Maximize2 } from 'lucide-react';
import { Qurah, Cycle, StoredReminderImage } from '../../types';
import {
  renderReminderCanvas,
  formatDrawDate,
  getCycleTotalDuration,
  isVariantEligible,
} from '../../lib/reminderImageGenerator';
import { StorageService } from '../../lib/storage';

export { QurahReminderVariants } from './QurahReminderVariants';

interface ReminderPostCardProps {
  daysLeft?: number;
  daysRemaining?: number;
  qurah?: Qurah;
  qurahName?: string;
  cycle?: Cycle;
  cycleNumber?: number;
  drawDate?: string;
}

export const ReminderPostCard: React.FC<ReminderPostCardProps> = ({
  daysLeft,
  daysRemaining,
  qurah,
  qurahName,
  cycle,
  cycleNumber,
  drawDate,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [dataUrl, setDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);

  // Normalize variant days to one of 7, 3, or 1
  const rawDays = daysLeft !== undefined ? daysLeft : daysRemaining !== undefined ? daysRemaining : 3;
  const variantDays: 7 | 3 | 1 = rawDays <= 1 ? 1 : rawDays <= 3 ? 3 : 7;
  const isUrgent = variantDays === 1;

  // Fallback Qurah and Cycle objects if not fully supplied
  const effectiveQurah: Qurah = qurah || {
    id: 'demo-qura',
    userId: 'user',
    name: qurahName || 'Blessings Circle',
    description: 'Islamic mutual savings committee',
    memberCount: 8,
    amountPerMember: 10000,
    totalAmount: 80000,
    cycleDurationDays: 15,
    durationOption: 15,
    startDate: '2026-03-01',
    endDate: '2026-07-01',
    members: [],
    cycles: [],
    currentCycleNumber: cycleNumber || 1,
    status: 'active',
    createdAt: new Date().toISOString(),
  };

  const effectiveCycle: Cycle = cycle || {
    cycleNumber: cycleNumber || 1,
    startDate: '2026-03-01',
    drawDate: drawDate || '2026-03-15',
    status: 'current',
    payments: {},
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    try {
      const url = renderReminderCanvas(canvas, variantDays, effectiveQurah, effectiveCycle);
      setDataUrl(url);

      // Save to storage
      if (effectiveQurah.id && effectiveCycle.cycleNumber) {
        const stored = StorageService.getStoredReminderImages(
          effectiveQurah.id,
          effectiveCycle.cycleNumber
        );
        stored[variantDays] = {
          variantDays,
          cycleNumber: effectiveCycle.cycleNumber,
          qurahId: effectiveQurah.id,
          qurahName: effectiveQurah.name,
          drawDate: effectiveCycle.drawDate,
          memberCount: effectiveQurah.memberCount,
          dataUrl: url,
          generatedAt: new Date().toISOString(),
        };
        StorageService.saveStoredReminderImages(
          effectiveQurah.id,
          effectiveCycle.cycleNumber,
          stored
        );
      }
    } catch (err) {
      console.error('Error drawing reminder canvas:', err);
    }
  }, [variantDays, effectiveQurah.name, effectiveCycle.cycleNumber, effectiveCycle.drawDate]);

  const handleDownload = () => {
    if (!dataUrl) return;
    const link = document.createElement('a');
    const safeName = effectiveQurah.name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    link.download = `alqura-${safeName}-cycle-${effectiveCycle.cycleNumber}-${variantDays}d-reminder.png`;
    link.href = dataUrl;
    link.click();
  };

  const handleCopy = async () => {
    if (!dataUrl) return;
    try {
      const res = await fetch(dataUrl);
      const blob = await res.blob();
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      navigator.clipboard.writeText(dataUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div
      className={`rounded-2xl border p-4 sm:p-5 flex flex-col justify-between text-white ${
        isUrgent
          ? 'bg-gradient-to-b from-[#180407] to-[#0e0204] border-red-500/30'
          : 'bg-[#121620] border-white/10'
      }`}
    >
      <div>
        <div className="flex items-center justify-between mb-3">
          <span
            className={`text-xs font-bold px-2.5 py-1 rounded-full flex items-center gap-1.5 ${
              isUrgent ? 'bg-red-500/20 text-red-400' : 'bg-white/10 text-white'
            }`}
          >
            <Clock className="w-3 h-3 text-current" />
            <span>
              {variantDays} {variantDays === 1 ? 'Day' : 'Days'} Remaining &bull;{' '}
              {isUrgent ? 'Urgent Red' : 'Dark Monochrome'}
            </span>
          </span>
          <span className="text-[10px] text-slate-400 font-mono">1:1 Square</span>
        </div>

        {/* 1:1 Canvas */}
        <div className="w-full aspect-square bg-[#0a0c10] rounded-xl overflow-hidden border border-white/5 flex items-center justify-center">
          <canvas ref={canvasRef} className="w-full h-full object-contain block" />
        </div>
      </div>

      {/* Controls */}
      <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between gap-2">
        <button
          type="button"
          onClick={handleCopy}
          className="text-xs text-slate-300 hover:text-white font-semibold px-3 py-1.5 rounded-full hover:bg-white/5 flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          <span>{copied ? 'Copied' : 'Copy'}</span>
        </button>

        <button
          type="button"
          onClick={handleDownload}
          className={`text-xs font-bold px-4 py-1.5 rounded-full flex items-center gap-1.5 transition-all shadow-xs cursor-pointer ${
            isUrgent
              ? 'bg-red-500 hover:bg-red-600 text-white'
              : 'bg-white hover:bg-slate-200 text-slate-950'
          }`}
        >
          <Download className="w-3.5 h-3.5" />
          <span>Download</span>
        </button>
      </div>
    </div>
  );
};
