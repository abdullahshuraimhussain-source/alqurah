import React, { useState, useRef, useEffect } from 'react';
import { X, Download, Share2, Copy, Check, ShieldCheck, Globe, Sparkles } from 'lucide-react';
import { Qurah } from '../../types';

interface WhatsAppAnnouncementModalProps {
  isOpen: boolean;
  onClose: () => void;
  qurah: Qurah;
}

export const WhatsAppAnnouncementModal: React.FC<WhatsAppAnnouncementModalProps> = ({
  isOpen,
  onClose,
  qurah,
}) => {
  const [language, setLanguage] = useState<'english' | 'urdu'>('english');
  const [copied, setCopied] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    drawAnnouncementCard();
  }, [isOpen, language, qurah]);

  const drawAnnouncementCard = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Canvas dimensions: 1200x800
    const w = 1200;
    const h = 800;
    canvas.width = w;
    canvas.height = h;

    // Background gradient: Deep rich Emerald
    const bgGrad = ctx.createLinearGradient(0, 0, w, h);
    bgGrad.addColorStop(0, '#064e3b');
    bgGrad.addColorStop(0.5, '#022c22');
    bgGrad.addColorStop(1, '#064e3b');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, w, h);

    // Decorative Islamic border
    ctx.strokeStyle = '#d97706'; // gold
    ctx.lineWidth = 4;
    ctx.strokeRect(30, 30, w - 60, h - 60);

    ctx.strokeStyle = 'rgba(217, 119, 6, 0.4)';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(45, 45, w - 90, h - 90);

    // Corner Ornaments
    const drawCorner = (x: number, y: number) => {
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(x, y, 6, 0, Math.PI * 2);
      ctx.fill();
    };
    drawCorner(45, 45);
    drawCorner(w - 45, 45);
    drawCorner(45, h - 45);
    drawCorner(w - 45, h - 45);

    // Header: Bismillah
    ctx.fillStyle = '#fde68a';
    ctx.font = '28px "Amiri", "Traditional Arabic", serif';
    ctx.textAlign = 'center';
    ctx.fillText('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', w / 2, 95);

    if (language === 'english') {
      // English layout
      ctx.fillStyle = '#6ee7b7';
      ctx.font = '700 16px "Plus Jakarta Sans", sans-serif';
      ctx.letterSpacing = '2px';
      ctx.fillText('OFFICIAL COMMITTEE ANNOUNCEMENT', w / 2, 140);

      // Qura Name
      ctx.fillStyle = '#ffffff';
      ctx.font = '800 46px "Plus Jakarta Sans", sans-serif';
      ctx.fillText(qurah.name, w / 2, 210);

      // Description
      ctx.fillStyle = '#a7f3d0';
      ctx.font = '400 18px "Plus Jakarta Sans", sans-serif';
      ctx.fillText('Islamic Interest-Free Mutual Savings Pool &middot; Al Qura System', w / 2, 255);

      // 4 Metric Highlight Boxes
      const boxY = 320;
      const boxW = 250;
      const boxH = 140;
      const gap = 30;
      const startX = (w - (4 * boxW + 3 * gap)) / 2;

      const sym = qurah.currencySymbol || 'Rs';
      const metrics = [
        { label: 'CYCLE POOL', val: `${sym} ${qurah.totalAmount.toLocaleString()}`, sub: '100% Interest-Free' },
        { label: 'TOTAL MEMBERS', val: `${qurah.memberCount} Members`, sub: 'Equal Rotation' },
        { label: 'PER MEMBER', val: `${sym} ${qurah.amountPerMember.toLocaleString()}`, sub: 'Fixed Contribution' },
        { label: 'CYCLE DURATION', val: `${qurah.cycleDurationDays} Days`, sub: 'Scheduled Draw' },
      ];

      metrics.forEach((m, idx) => {
        const bx = startX + idx * (boxW + gap);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
        ctx.strokeStyle = 'rgba(245, 158, 11, 0.4)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.roundRect(bx, boxY, boxW, boxH, 16);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = '#93c5fd';
        ctx.font = '700 12px "Plus Jakarta Sans", sans-serif';
        ctx.fillText(m.label, bx + boxW / 2, boxY + 38);

        ctx.fillStyle = '#fbbf24';
        ctx.font = '800 24px "Plus Jakarta Sans", monospace';
        ctx.fillText(m.val, bx + boxW / 2, boxY + 78);

        ctx.fillStyle = '#d1fae5';
        ctx.font = '500 12px "Plus Jakarta Sans", sans-serif';
        ctx.fillText(m.sub, bx + boxW / 2, boxY + 112);
      });

      // Sharia Trust Bar
      ctx.fillStyle = 'rgba(16, 185, 129, 0.15)';
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(startX, 500, w - startX * 2, 100, 16);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.font = '700 20px "Plus Jakarta Sans", sans-serif';
      ctx.fillText('100% Halal &bull; Zero Interest (No Sood) &bull; Verified Fair Draw', w / 2, 542);

      ctx.fillStyle = '#a7f3d0';
      ctx.font = '400 14px "Plus Jakarta Sans", sans-serif';
      ctx.fillText(
        `Start Date: ${qurah.startDate}  |  Draw Cycles: 1 to ${qurah.memberCount}  |  Automated WhatsApp & Video Reports`,
        w / 2,
        574
      );

      // Footer
      ctx.fillStyle = '#6ee7b7';
      ctx.font = '500 14px "Plus Jakarta Sans", sans-serif';
      ctx.fillText('Organized on Al Qura — Islamic Community Committee Portal', w / 2, 730);
    } else {
      // Urdu / Arabic layout
      ctx.fillStyle = '#6ee7b7';
      ctx.font = '700 22px "Amiri", serif';
      ctx.fillText('القرعہ کمیٹی — باضابطہ اعلان برائے واٹس ایپ گروپ', w / 2, 145);

      // Qura Name
      ctx.fillStyle = '#ffffff';
      ctx.font = '800 44px "Plus Jakarta Sans", sans-serif';
      ctx.fillText(qurah.name, w / 2, 210);

      ctx.fillStyle = '#fde68a';
      ctx.font = '700 24px "Amiri", serif';
      ctx.fillText('سود سے پاک اسلامی باہمی تعاون کمیٹی (قرضِ حسنہ نظام)', w / 2, 260);

      // 4 Metrics in Urdu/Arabic style
      const boxY = 320;
      const boxW = 250;
      const boxH = 140;
      const gap = 30;
      const startX = (w - (4 * boxW + 3 * gap)) / 2;

      const symUrdu = qurah.currencySymbol || 'Rs';
      const metricsUrdu = [
        { label: 'کل قرعہ رقم', val: `${symUrdu} ${qurah.totalAmount.toLocaleString()}`, sub: 'بغیر کسی سود کے' },
        { label: 'کل ممبران', val: `${qurah.memberCount} اراکین`, sub: 'برابر باری' },
        { label: 'ماہانہ/دورانیہ قسط', val: `${symUrdu} ${qurah.amountPerMember.toLocaleString()}`, sub: 'فی ممبر رقم' },
        { label: 'قرعہ کی مدت', val: `${qurah.cycleDurationDays} دن`, sub: 'شفاف پرچی قرعہ' },
      ];

      metricsUrdu.forEach((m, idx) => {
        const bx = startX + idx * (boxW + gap);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
        ctx.strokeStyle = 'rgba(245, 158, 11, 0.4)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.roundRect(bx, boxY, boxW, boxH, 16);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = '#93c5fd';
        ctx.font = '700 18px "Amiri", serif';
        ctx.fillText(m.label, bx + boxW / 2, boxY + 40);

        ctx.fillStyle = '#fbbf24';
        ctx.font = '800 24px "Plus Jakarta Sans", monospace';
        ctx.fillText(m.val, bx + boxW / 2, boxY + 80);

        ctx.fillStyle = '#d1fae5';
        ctx.font = '500 16px "Amiri", serif';
        ctx.fillText(m.sub, bx + boxW / 2, boxY + 115);
      });

      // Sharia Bar
      ctx.fillStyle = 'rgba(16, 185, 129, 0.15)';
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(startX, 500, w - startX * 2, 100, 16);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.font = '700 22px "Amiri", serif';
      ctx.fillText('تمام رقم شفاف طریقے سے پرچی قرعہ اندازی کے ذریعے ادا کی جائے گی', w / 2, 545);

      ctx.fillStyle = '#fde68a';
      ctx.font = '500 18px "Amiri", serif';
      ctx.fillText(`تاریخ آغاز: ${qurah.startDate}   •   کوئی اضافی فیس یا سود نہیں`, w / 2, 578);

      ctx.fillStyle = '#6ee7b7';
      ctx.font = '500 16px "Amiri", serif';
      ctx.fillText('پیش کردہ: القُرعۃ (Al Qura) — اسلامی کمیٹی پورٹل', w / 2, 730);
    }
  };

  if (!isOpen) return null;

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `${qurah.name.toLowerCase().replace(/\s+/g, '-')}-announcement-${language}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  const handleCopy = async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    try {
      canvas.toBlob(async (blob) => {
        if (!blob) return;
        await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      });
    } catch {
      // Fallback
      handleDownload();
    }
  };

  const handleWhatsAppShare = () => {
    const textEn = `*Assalamu Alaikum! Official Announcement for "${qurah.name}"*\n\nAlhamdulillah, our Islamic interest-free committee is confirmed.\n\n• Pool per cycle: $${qurah.totalAmount.toLocaleString()}\n• Members: ${qurah.memberCount}\n• Per Member: $${qurah.amountPerMember.toLocaleString()}\n• Cycle Duration: ${qurah.cycleDurationDays} days\n• Start Date: ${qurah.startDate}\n\n100% Sood-Free & Transparent Draw on Al Qura!`;

    const textUr = `*السلام علیکم ورحمۃ اللہ*\n\nکمیٹی کا باضابطہ اعلان: *${qurah.name}*\n\n• کل قرعہ رقم: $${qurah.totalAmount.toLocaleString()}\n• کل اراکین: ${qurah.memberCount}\n• فی ممبر قسط: $${qurah.amountPerMember.toLocaleString()}\n• قرعہ دورانیہ: ${qurah.cycleDurationDays} دن\n• آغاز تاریخ: ${qurah.startDate}\n\nسود سے پاک اور مکمل شفاف پرچی قرعہ اندازی!`;

    const message = language === 'urdu' ? textUr : textEn;
    const url = `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-[#11141c] rounded-3xl shadow-2xl border border-white/15 overflow-hidden flex flex-col max-h-[95vh] text-white">
        {/* Top Header */}
        <div className="bg-[#141822] text-white p-5 flex items-center justify-between border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center text-white font-bold border border-white/10">
              <Share2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">WhatsApp Announcement Card</h3>
              <p className="text-xs text-slate-400">Shareable Qura Announcement in English &amp; Urdu</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Language Switcher */}
            <div className="bg-[#0b0e14] p-1 rounded-full flex items-center border border-white/10">
              <button
                type="button"
                onClick={() => setLanguage('english')}
                className={`px-3.5 py-1 rounded-full text-xs font-bold transition-colors ${
                  language === 'english' ? 'bg-white text-slate-950 shadow-xs' : 'text-slate-400 hover:text-white'
                }`}
              >
                English
              </button>
              <button
                type="button"
                onClick={() => setLanguage('urdu')}
                className={`px-3.5 py-1 rounded-full text-xs font-bold transition-colors font-arabic ${
                  language === 'urdu' ? 'bg-white text-slate-950 shadow-xs' : 'text-slate-400 hover:text-white'
                }`}
              >
                اردو (Urdu)
              </button>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Canvas Display */}
        <div className="p-6 bg-[#0a0d14] flex-1 overflow-y-auto flex items-center justify-center">
          <div className="w-full max-w-2xl bg-[#11141c] rounded-2xl shadow-xl overflow-hidden border border-white/10">
            <canvas ref={canvasRef} className="w-full h-auto block" />
          </div>
        </div>

        {/* Actions Bar */}
        <div className="p-4 bg-[#141822] border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="text-slate-400 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>High-res 1200&times;800 export for WhatsApp &amp; Telegram communities</span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={handleCopy}
              className="flex-1 sm:flex-none px-4 py-2 rounded-full border border-white/15 hover:bg-white/10 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Copied!' : 'Copy'}</span>
            </button>

            <button
              type="button"
              onClick={handleDownload}
              className="flex-1 sm:flex-none px-5 py-2 rounded-full bg-white hover:bg-slate-200 text-slate-950 text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition-all hover:scale-[1.02]"
            >
              <Download className="w-4 h-4" />
              <span>Download PNG</span>
            </button>

            <button
              type="button"
              onClick={handleWhatsAppShare}
              className="flex-1 sm:flex-none px-5 py-2 rounded-full bg-emerald-500 hover:bg-emerald-600 text-slate-950 text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-emerald-500/20 transition-all hover:scale-[1.02]"
            >
              <Share2 className="w-4 h-4" />
              <span>Send to WhatsApp</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
