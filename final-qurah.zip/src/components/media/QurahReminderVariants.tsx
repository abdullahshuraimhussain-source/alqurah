import React, { useState, useEffect, useRef } from 'react';
import {
  Download,
  Calendar,
  Clock,
  Copy,
  Check,
  RefreshCw,
  Maximize2,
  AlertCircle,
  ShieldCheck,
  Share2,
  FileCheck,
  Sparkles,
  Info,
} from 'lucide-react';
import { Qurah, Cycle, StoredReminderImage } from '../../types';
import { StorageService } from '../../lib/storage';
import {
  REMINDER_VARIANTS,
  getCycleTotalDuration,
  isVariantEligible,
  renderReminderCanvas,
  generateEligibleReminderImages,
  formatDrawDate,
} from '../../lib/reminderImageGenerator';

interface QurahReminderVariantsProps {
  qurah: Qurah;
  cycle: Cycle;
  onStoredImagesUpdated?: (images: Record<number, StoredReminderImage>) => void;
}

export const QurahReminderVariants: React.FC<QurahReminderVariantsProps> = ({
  qurah,
  cycle,
  onStoredImagesUpdated,
}) => {
  const [storedImages, setStoredImages] = useState<Record<number, StoredReminderImage>>({});
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState<'all' | 7 | 3 | 1>('all');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [previewModalImage, setPreviewModalImage] = useState<StoredReminderImage | null>(null);

  const cycleDuration = getCycleTotalDuration(qurah, cycle);

  // Load stored images or generate them if missing
  useEffect(() => {
    loadOrGenerateImages();
  }, [qurah.id, cycle.cycleNumber, cycleDuration, cycle.drawDate, qurah.name, qurah.memberCount]);

  const loadOrGenerateImages = (forceRegenerate = false) => {
    setIsGenerating(true);
    try {
      const existing = forceRegenerate
        ? {}
        : StorageService.getStoredReminderImages(qurah.id, cycle.cycleNumber);

      const eligibleVariants = REMINDER_VARIANTS.filter((v) =>
        isVariantEligible(v, cycleDuration)
      );

      // Check if all eligible variants are present
      const allPresent =
        !forceRegenerate &&
        eligibleVariants.length > 0 &&
        eligibleVariants.every((v) => !!existing[v]?.dataUrl);

      if (allPresent) {
        setStoredImages(existing);
        if (onStoredImagesUpdated) onStoredImagesUpdated(existing);
        setIsGenerating(false);
        return;
      }

      // Generate missing or fresh images
      const freshImages = generateEligibleReminderImages(qurah, cycle);
      const merged = { ...existing, ...freshImages };

      // Persist permanently in vault storage
      StorageService.saveStoredReminderImages(qurah.id, cycle.cycleNumber, merged);
      setStoredImages(merged);
      if (onStoredImagesUpdated) onStoredImagesUpdated(merged);
    } catch (err) {
      console.error('Failed to load/generate reminder images:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = (variantDays: 7 | 3 | 1, dataUrl: string) => {
    if (!dataUrl) return;
    const link = document.createElement('a');
    const safeName = qurah.name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    link.download = `alqura-${safeName}-cycle-${cycle.cycleNumber}-${variantDays}d-draw-reminder.png`;
    link.href = dataUrl;
    link.click();
  };

  const handleDownloadAll = () => {
    REMINDER_VARIANTS.forEach((variant) => {
      const img = storedImages[variant];
      if (img?.dataUrl) {
        setTimeout(() => {
          handleDownload(variant, img.dataUrl);
        }, variant * 150);
      }
    });
  };

  const handleCopyImage = async (variantDays: 7 | 3 | 1, dataUrl: string) => {
    try {
      const res = await fetch(dataUrl);
      const blob = await res.blob();
      await navigator.clipboard.write([
        new ClipboardItem({
          'image/png': blob,
        }),
      ]);
      setCopiedKey(`img-${variantDays}`);
      setTimeout(() => setCopiedKey(null), 2500);
    } catch (err) {
      // Fallback: Copy data URL or text
      navigator.clipboard.writeText(dataUrl);
      setCopiedKey(`img-${variantDays}`);
      setTimeout(() => setCopiedKey(null), 2500);
    }
  };

  const handleCopyWhatsAppCaption = (variantDays: 7 | 3 | 1) => {
    const isUrgent = variantDays === 1;
    const drawDateFormatted = formatDrawDate(cycle.drawDate);
    const text = isUrgent
      ? `🚨 *FINAL NOTICE: 1 DAY REMAINING UNTIL DRAW!* 🚨\n\n` +
        `🌙 *Al Qura Sharia-Compliant Committee*\n` +
        `📌 *Committee:* ${qurah.name}\n` +
        `🔄 *Cycle:* Cycle ${cycle.cycleNumber} of ${qurah.cycles.length}\n` +
        `📅 *Exact Draw Date:* ${drawDateFormatted}\n` +
        `👥 *Total Members:* ${qurah.memberCount} Members\n` +
        `💰 *Contribution:* ${qurah.currencySymbol || 'Rs'} ${qurah.amountPerMember.toLocaleString()}\n\n` +
        `⚠️ Please ensure all cycle contributions are deposited immediately. The automated draw reveal video will be unlocked on draw day.\n\n` +
        `_100% Interest-Free • Sharia-Compliant Mutual Savings_`
      : `🔔 *OFFICIAL REMINDER: ${variantDays} DAYS REMAINING BEFORE DRAW* 🔔\n\n` +
        `🌙 *Al Qura Committee Update*\n` +
        `📌 *Committee:* ${qurah.name}\n` +
        `🔄 *Cycle:* Cycle ${cycle.cycleNumber} of ${qurah.cycles.length}\n` +
        `📅 *Exact Draw Date:* ${drawDateFormatted}\n` +
        `👥 *Total Members:* ${qurah.memberCount} Members\n` +
        `💰 *Contribution:* ${qurah.currencySymbol || 'Rs'} ${qurah.amountPerMember.toLocaleString()}\n\n` +
        `Please confirm your payment with the administrator before the scheduled draw.\n\n` +
        `_100% Interest-Free • Al Qura Mutual Savings_`;

    navigator.clipboard.writeText(text);
    setCopiedKey(`txt-${variantDays}`);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  return (
    <div className="space-y-5">
      {/* SYSTEM HEADER BAR & POLICY BADGES */}
      <div className="bg-[#141824] border border-white/10 rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-200 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>3-Variant Cycle Draw Reminder Suite</span>
            </span>
            <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded-full bg-white/10 text-white border border-white/10">
              Cycle Total Duration: {cycleDuration} Days
            </span>
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
              <FileCheck className="w-3 h-3 text-emerald-400" />
              <span>Durable Vault Storage Active</span>
            </span>
          </div>
          <p className="text-xs text-slate-400">
            Automated 1:1 square countdown posters for WhatsApp and social updates. Generates 7-Day,
            3-Day, and Urgent 1-Day variants based on cycle duration.
          </p>
        </div>

        {/* Action Buttons: Regenerate & Filter */}
        <div className="flex items-center gap-2 self-start md:self-auto shrink-0 flex-wrap">
          <button
            type="button"
            onClick={() => loadOrGenerateImages(true)}
            disabled={isGenerating}
            className="px-3.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold flex items-center gap-1.5 transition-all border border-white/10 disabled:opacity-50 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isGenerating ? 'animate-spin text-emerald-400' : ''}`} />
            <span>{isGenerating ? 'Generating...' : 'Regenerate Vault Images'}</span>
          </button>

          <button
            type="button"
            onClick={handleDownloadAll}
            className="px-3.5 py-1.5 rounded-xl bg-white hover:bg-slate-200 text-slate-950 text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download All Active</span>
          </button>
        </div>
      </div>

      {/* FILTER TABS */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        <button
          type="button"
          onClick={() => setActiveTab('all')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'all'
              ? 'bg-white text-slate-950 shadow-sm'
              : 'bg-[#141824] text-slate-400 hover:text-white border border-white/10'
          }`}
        >
          All 3 Variants
        </button>

        {REMINDER_VARIANTS.map((days) => {
          const isEligible = isVariantEligible(days, cycleDuration);
          const isUrgent = days === 1;
          const label = days === 1 ? '1 Day (Urgent Red)' : `${days} Days (Monochrome)`;

          return (
            <button
              key={days}
              type="button"
              onClick={() => setActiveTab(days)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === days
                  ? isUrgent
                    ? 'bg-red-500 text-white shadow-sm'
                    : 'bg-white text-slate-950 shadow-sm'
                  : 'bg-[#141824] text-slate-400 hover:text-white border border-white/10'
              } ${!isEligible ? 'opacity-60' : ''}`}
            >
              <span>{label}</span>
              {!isEligible && (
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-white/10 text-slate-400">
                  N/A
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* 3 VARIANTS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
        {REMINDER_VARIANTS.filter((v) => activeTab === 'all' || activeTab === v).map((days) => {
          const isEligible = isVariantEligible(days, cycleDuration);
          const isUrgent = days === 1;
          const stored = storedImages[days];

          if (!isEligible) {
            // Variant excluded because cycle total duration <= days
            return (
              <div
                key={days}
                className="bg-[#121620] border border-white/10 rounded-2xl p-5 flex flex-col justify-between opacity-80"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-white/5 text-slate-400 flex items-center gap-1.5">
                      <Clock className="w-3 h-3 text-slate-400" />
                      <span>{days} {days === 1 ? 'Day' : 'Days'} Remaining</span>
                    </span>
                    <span className="text-[10px] text-amber-400 font-mono font-bold bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20">
                      Duration Rule Omitted
                    </span>
                  </div>

                  <div className="aspect-square rounded-xl border border-dashed border-white/10 bg-[#0a0c10] flex flex-col items-center justify-center p-6 text-center">
                    <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center text-slate-400 mb-3">
                      <AlertCircle className="w-6 h-6 text-amber-400" />
                    </div>
                    <h5 className="text-sm font-bold text-white mb-1">
                      {days}-Day Variant Not Applicable
                    </h5>
                    <p className="text-xs text-slate-400 leading-relaxed max-w-xs">
                      The cycle total duration is <strong className="text-white">{cycleDuration} days</strong>.
                      Per requirements, variants are only generated if the cycle's total duration is
                      longer than {days} days.
                    </p>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-white/5 text-[11px] text-slate-500 text-center font-mono">
                  Condition: cycle duration ({cycleDuration}d) &gt; {days}d (False)
                </div>
              </div>
            );
          }

          // Eligible variant card
          const cardBorder = isUrgent
            ? 'border-red-500/30 hover:border-red-500/50 bg-gradient-to-b from-[#180407] to-[#100204]'
            : 'border-white/10 hover:border-white/20 bg-[#121620]';

          return (
            <div
              key={days}
              className={`rounded-2xl border p-4 sm:p-5 flex flex-col justify-between transition-all duration-200 shadow-lg ${cardBorder}`}
            >
              <div>
                {/* Variant Header Pill */}
                <div className="flex items-center justify-between mb-3.5">
                  <span
                    className={`text-xs font-bold px-2.5 py-1 rounded-full flex items-center gap-1.5 ${
                      isUrgent
                        ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                        : 'bg-white/10 text-white border border-white/15'
                    }`}
                  >
                    <Clock className={`w-3.5 h-3.5 ${isUrgent ? 'text-red-400' : 'text-slate-300'}`} />
                    <span>
                      {days} {days === 1 ? 'Day' : 'Days'} Remaining &bull;{' '}
                      {isUrgent ? 'Urgent Red' : 'Dark Monochrome'}
                    </span>
                  </span>

                  <span className="text-[10px] text-slate-400 font-mono">1:1 Square</span>
                </div>

                {/* 1:1 Aspect Image Container */}
                <div className="relative group rounded-xl overflow-hidden border border-white/10 bg-[#090b10] aspect-square flex items-center justify-center">
                  {stored?.dataUrl ? (
                    <img
                      src={stored.dataUrl}
                      alt={`${days} Days Remaining Reminder Poster for ${qurah.name}`}
                      className="w-full h-full object-contain block transition-transform duration-300 group-hover:scale-[1.02]"
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center text-slate-400 gap-2">
                      <RefreshCw className="w-6 h-6 animate-spin text-slate-500" />
                      <span className="text-xs">Generating 1:1 Variant...</span>
                    </div>
                  )}

                  {/* Hover Overlay with Preview Trigger */}
                  {stored?.dataUrl && (
                    <div
                      onClick={() => setPreviewModalImage(stored)}
                      className="absolute inset-0 bg-black/60 backdrop-blur-xs opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex flex-col items-center justify-center cursor-pointer gap-2"
                    >
                      <div className="w-11 h-11 rounded-full bg-white text-slate-950 flex items-center justify-center shadow-lg">
                        <Maximize2 className="w-5 h-5" />
                      </div>
                      <span className="text-xs font-bold text-white tracking-wide">
                        Click to View Full 1080p
                      </span>
                    </div>
                  )}
                </div>

                {/* Info Metadata */}
                <div className="mt-3.5 flex items-center justify-between text-[11px] text-slate-400">
                  <div className="flex items-center gap-1.5 truncate">
                    <FileCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span className="truncate">
                      Stored in Vault &bull; {stored?.generatedAt ? new Date(stored.generatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Ready'}
                    </span>
                  </div>
                  <span className="font-mono text-slate-500 shrink-0">1080 &times; 1080 PNG</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-4 pt-3 border-t border-white/5 space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => stored?.dataUrl && handleCopyImage(days, stored.dataUrl)}
                    className="w-full py-2 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    {copiedKey === `img-${days}` ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-slate-300" />
                        <span>Copy Image</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => handleCopyWhatsAppCaption(days)}
                    className="w-full py-2 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    {copiedKey === `txt-${days}` ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Share2 className="w-3.5 h-3.5 text-slate-300" />
                        <span>WhatsApp Text</span>
                      </>
                    )}
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => stored?.dataUrl && handleDownload(days, stored.dataUrl)}
                  className={`w-full py-2 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-xs cursor-pointer ${
                    isUrgent
                      ? 'bg-red-500 hover:bg-red-600 text-white'
                      : 'bg-white hover:bg-slate-200 text-slate-950'
                  }`}
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download 1:1 PNG Poster</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* FULLSCREEN PREVIEW MODAL */}
      {previewModalImage && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="relative max-w-2xl w-full bg-[#0a0c10] border border-white/20 rounded-3xl p-4 sm:p-6 shadow-2xl flex flex-col items-center">
            {/* Modal Header */}
            <div className="w-full flex items-center justify-between pb-3 mb-3 border-b border-white/10 text-xs">
              <div className="flex items-center gap-2">
                <span className="font-bold text-white">
                  {previewModalImage.variantDays} {previewModalImage.variantDays === 1 ? 'Day' : 'Days'} Remaining Reminder
                </span>
                <span className="text-[10px] text-slate-400 font-mono">
                  Cycle {previewModalImage.cycleNumber} &bull; 1080 &times; 1080 HD
                </span>
              </div>
              <button
                type="button"
                onClick={() => setPreviewModalImage(null)}
                className="px-3 py-1 rounded-full bg-white/10 hover:bg-white/20 text-white font-mono text-xs transition-colors cursor-pointer"
              >
                Close ✕
              </button>
            </div>

            {/* Modal Full Image Preview */}
            <div className="w-full aspect-square rounded-2xl overflow-hidden border border-white/10 bg-black flex items-center justify-center">
              <img
                src={previewModalImage.dataUrl}
                alt="Full Preview"
                className="w-full h-full object-contain block"
              />
            </div>

            {/* Modal Actions */}
            <div className="w-full mt-4 flex items-center justify-between gap-3 flex-wrap">
              <div className="text-[11px] text-slate-400 font-mono">
                Stored in Vault &bull; Sharia-Compliant Media Suite
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() =>
                    handleCopyImage(previewModalImage.variantDays, previewModalImage.dataUrl)
                  }
                  className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Image</span>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    handleDownload(previewModalImage.variantDays, previewModalImage.dataUrl)
                  }
                  className="px-5 py-2 rounded-xl bg-white hover:bg-slate-200 text-slate-950 text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download High-Res PNG</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
