import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Download,
  Volume2,
  VolumeX,
  Share2,
  Maximize2,
  Minimize2,
  Sparkles,
  Trophy,
  CheckCircle2,
  Clock,
  ShieldCheck,
  Video,
  X,
} from 'lucide-react';
import { Qurah, Cycle, Member } from '../../types';
import { soundEffects } from '../../lib/audio';

interface AlQurahDrawRevealVideoProps {
  qurah: Qurah;
  cycle: Cycle;
  winnerName?: string;
  onClose?: () => void;
  autoPlay?: boolean;
}

export const AlQurahDrawRevealVideo: React.FC<AlQurahDrawRevealVideoProps> = ({
  qurah,
  cycle,
  winnerName: propWinnerName,
  onClose,
  autoPlay = true,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Determine winner name
  const effectiveWinnerName =
    propWinnerName ||
    cycle.winner?.memberName ||
    qurah.members[0]?.name ||
    'Honorable Member';

  // Video duration strictly set to 14.0 seconds (within user's requested 13 - 15 seconds)
  const TOTAL_DURATION = 14.0;

  // Formatted date when the video was generated
  const formattedGenDate = new Intl.DateTimeFormat('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  }).format(new Date());

  // Component state
  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);

  // References for animation loop
  const animFrameIdRef = useRef<number | null>(null);
  const lastTimestampRef = useRef<number | null>(null);
  const soundPlayedRef = useRef<{
    intro: boolean;
    handShuffle: boolean;
    flare: boolean;
    unfold: boolean;
    chime: boolean;
    roster: boolean;
  }>({
    intro: false,
    handShuffle: false,
    flare: false,
    unfold: false,
    chime: false,
    roster: false,
  });

  // Calculate past winners map: memberId -> cycleNumber
  const winnerMap = new Map<string, number>();
  qurah.cycles.forEach((c) => {
    if (c.winner && c.cycleNumber < cycle.cycleNumber) {
      winnerMap.set(c.winner.memberId, c.cycleNumber);
    }
  });

  // Find the winning member id if available
  const winningMember =
    qurah.members.find((m) => m.name.toLowerCase() === effectiveWinnerName.toLowerCase()) ||
    qurah.members.find((m) => m.id === cycle.winner?.memberId);
  const winningMemberId = winningMember ? winningMember.id : null;

  // Sound triggering logic based on playback time
  const handleSoundTriggers = useCallback((time: number) => {
    if (isMuted) return;

    if (time >= 0.1 && time < 1.0 && !soundPlayedRef.current.intro) {
      soundPlayedRef.current.intro = true;
      soundEffects.playGlassPing();
    }
    if (time >= 3.2 && time < 4.2 && !soundPlayedRef.current.handShuffle) {
      soundPlayedRef.current.handShuffle = true;
      soundEffects.playShuffle();
    }
    if (time >= 6.4 && time < 7.4 && !soundPlayedRef.current.flare) {
      soundPlayedRef.current.flare = true;
      soundEffects.playFlare();
      soundEffects.playSuspenseRiser();
    }
    if (time >= 7.3 && time < 8.0 && !soundPlayedRef.current.unfold) {
      soundPlayedRef.current.unfold = true;
      soundEffects.playUnfold();
    }
    if (time >= 7.8 && time < 8.8 && !soundPlayedRef.current.chime) {
      soundPlayedRef.current.chime = true;
      soundEffects.playChime();
    }
    if (time >= 9.8 && time < 10.8 && !soundPlayedRef.current.roster) {
      soundPlayedRef.current.roster = true;
      soundEffects.playRosterFanfare();
    }
  }, [isMuted]);

  // Reset audio flags when rewinding
  const resetAudioTriggers = () => {
    soundPlayedRef.current = {
      intro: false,
      handShuffle: false,
      flare: false,
      unfold: false,
      chime: false,
      roster: false,
    };
  };

  // Master Canvas Frame Drawing function at exact time 't' (0 to 14 seconds)
  const renderFrame = useCallback(
    (ctx: CanvasRenderingContext2D, t: number, targetWidth = 1920, targetHeight = 1080) => {
      // 1080p Full HD scaling matrix (enables pristine 1920x1080 density with precision layout)
      ctx.save();
      const scaleX = targetWidth / 1280;
      const scaleY = targetHeight / 720;
      ctx.scale(scaleX, scaleY);
      const width = 1280;
      const height = 720;

      // 1. CLEAR & LUXURY PURPLE / OBSIDIAN BACKGROUND (Matching user reference video)
      ctx.save();
      const bgGrad = ctx.createLinearGradient(0, 0, width, height);
      bgGrad.addColorStop(0, '#100720'); // Deep royal dark purple
      bgGrad.addColorStop(0.45, '#1b0933'); // Amethyst velvet
      bgGrad.addColorStop(1, '#270c48'); // Rich royal purple
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, width, height);

      // Subtle radial highlight
      const radGlow = ctx.createRadialGradient(
        width * 0.65,
        height * 0.45,
        20,
        width * 0.65,
        height * 0.45,
        width * 0.6
      );
      radGlow.addColorStop(0, 'rgba(216, 180, 254, 0.12)');
      radGlow.addColorStop(0.5, 'rgba(147, 51, 234, 0.05)');
      radGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = radGlow;
      ctx.fillRect(0, 0, width, height);

      // 2. FLOWING GOLDEN CURVED RIBBONS (Exact visual signature of user's video)
      ctx.save();
      ctx.lineWidth = 1.6;
      ctx.strokeStyle = 'rgba(255, 215, 120, 0.35)';
      ctx.shadowColor = 'rgba(255, 215, 120, 0.6)';
      ctx.shadowBlur = 8;

      // Ribbon 1
      const waveOffset1 = Math.sin(t * 0.8) * 15;
      ctx.beginPath();
      ctx.moveTo(-50, height * 0.2 + waveOffset1);
      ctx.bezierCurveTo(
        width * 0.3,
        height * 0.05 - waveOffset1,
        width * 0.5,
        height * 0.6 + waveOffset1,
        width + 50,
        height * 0.35
      );
      ctx.stroke();

      // Ribbon 2 (thinner)
      ctx.lineWidth = 1.0;
      ctx.strokeStyle = 'rgba(255, 228, 160, 0.25)';
      ctx.beginPath();
      ctx.moveTo(-30, height * 0.7 - waveOffset1);
      ctx.bezierCurveTo(
        width * 0.4,
        height * 0.9 + waveOffset1,
        width * 0.65,
        height * 0.25,
        width + 50,
        height * 0.85
      );
      ctx.stroke();

      // Ribbon 3 (subtle accent ribbon)
      ctx.lineWidth = 2.0;
      ctx.strokeStyle = 'rgba(245, 190, 75, 0.3)';
      ctx.beginPath();
      ctx.moveTo(width * 0.4, -20);
      ctx.bezierCurveTo(
        width * 0.55,
        height * 0.3,
        width * 0.85,
        height * 0.7,
        width * 0.7,
        height + 40
      );
      ctx.stroke();
      ctx.restore();

      // 3. FLOATING GOLDEN BOKEH ORBS
      ctx.save();
      for (let i = 0; i < 18; i++) {
        const seedX = ((i * 137.5) % width);
        const seedY = ((i * 211.3 + t * 25) % (height + 60)) - 30;
        const radius = 2 + (i % 5) * 2;
        const pulse = 0.2 + 0.35 * Math.sin(t * 1.5 + i);

        ctx.fillStyle = `rgba(255, 220, 140, ${pulse})`;
        ctx.beginPath();
        ctx.arc(seedX, height - seedY, radius, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();

      // ==========================================
      // TIMELINE / SCENE MANAGEMENT (0s to 14s)
      // Scene 1: 0.0s - 3.0s (Intro Title & Glass Bowl with chits)
      // Scene 2: 3.0s - 6.2s (Golden Hand reaches in and picks chit)
      // Scene 3: 6.2s - 9.8s (Chit zooms in, radiant light flare, unfolds & reveals Winner)
      // Scene 4: 9.8s - 14.0s (Complete Member Roster: Highlighted winner & all pending/completed members)
      // ==========================================

      if (t < 9.8) {
        // SCENES 1, 2, 3: Glass Bowl, Hand & Winner Parchment Reveal

        // Fade-out transition when moving to Scene 4 (around 9.4s - 9.8s)
        let sceneAlpha = 1;
        if (t >= 9.2) {
          sceneAlpha = Math.max(0, 1 - (t - 9.2) / 0.6);
        }
        ctx.globalAlpha = sceneAlpha;

        // Camera Pan & Zoom: Starts wide, zooms in gently toward bowl during Scene 2
        let cameraZoom = 1;
        let camShiftX = 0;
        let camShiftY = 0;

        if (t > 2.8 && t < 6.5) {
          const p = Math.min(1, (t - 2.8) / 2.5);
          const easeP = p * p * (3 - 2 * p);
          cameraZoom = 1 + easeP * 0.18;
          camShiftX = -width * 0.08 * easeP;
          camShiftY = -height * 0.04 * easeP;
        }

        ctx.save();
        ctx.translate(width / 2 + camShiftX, height / 2 + camShiftY);
        ctx.scale(cameraZoom, cameraZoom);
        ctx.translate(-width / 2, -height / 2);

        // --- LEFT COLUMN: ELEGANT TITLE CARD (As seen in 00:00 of reference video) ---
        if (t < 6.4) {
          const titleFade = t < 0.6 ? t / 0.6 : t > 5.8 ? Math.max(0, 1 - (t - 5.8) / 0.5) : 1;
          ctx.save();
          ctx.globalAlpha = sceneAlpha * titleFade;

          const titleX = width * 0.09;
          const titleBaseY = height * 0.36;

          // "Al Qurah" Top sub-title
          ctx.font = '700 36px "Plus Jakarta Sans", sans-serif';
          ctx.fillStyle = '#ffffff';
          ctx.fillText('Al Qurah', titleX, titleBaseY);

          // "Draw Reveal" Big Title
          ctx.font = '800 52px "Plus Jakarta Sans", sans-serif';
          ctx.fillStyle = '#ffffff';
          ctx.shadowColor = 'rgba(255, 255, 255, 0.4)';
          ctx.shadowBlur = 12;
          ctx.fillText('Draw Reveal', titleX, titleBaseY + 62);
          ctx.shadowBlur = 0;

          // Bullet 1: Qurah Name
          ctx.font = '600 24px "Plus Jakarta Sans", sans-serif';
          ctx.fillStyle = '#e2e8f0';
          ctx.fillText(`• ${qurah.name} •`, titleX, titleBaseY + 122);

          // Bullet 2: Qurah / Cycle Number
          ctx.font = '600 22px "Plus Jakarta Sans", sans-serif';
          ctx.fillStyle = '#cbd5e1';
          ctx.fillText(`• Cycle ${cycle.cycleNumber} •`, titleX, titleBaseY + 162);

          // Date when video was generated (User request: "Date jis din ya video genrate howa hai")
          ctx.font = '500 16px "Plus Jakarta Sans", monospace';
          ctx.fillStyle = '#fde68a';
          ctx.fillText(`Date: ${formattedGenDate}`, titleX, titleBaseY + 205);

          // Sharia Guarantee Tag
          ctx.font = '500 13px "Plus Jakarta Sans", sans-serif';
          ctx.fillStyle = '#34d399';
          ctx.fillText('✓ 100% Sharia Certified Interest-Free Committee', titleX, titleBaseY + 235);

          ctx.restore();
        }

        // --- RIGHT COLUMN: 3D GLASS BOWL WITH CHITS ---
        const bowlCenterX = width * 0.72;
        const bowlCenterY = height * 0.58;
        const bowlRadius = width * 0.17;

        // Base Pedestal / Glass Stand
        ctx.save();
        ctx.fillStyle = 'rgba(15, 7, 30, 0.85)';
        ctx.beginPath();
        ctx.ellipse(bowlCenterX, bowlCenterY + bowlRadius * 0.88, bowlRadius * 0.9, bowlRadius * 0.22, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = 'rgba(255, 215, 120, 0.3)';
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.restore();

        // Glass Back Reflections / Depth
        ctx.save();
        const glassDepthGrad = ctx.createRadialGradient(
          bowlCenterX - bowlRadius * 0.3,
          bowlCenterY - bowlRadius * 0.2,
          10,
          bowlCenterX,
          bowlCenterY,
          bowlRadius
        );
        glassDepthGrad.addColorStop(0, 'rgba(255, 255, 255, 0.1)');
        glassDepthGrad.addColorStop(0.6, 'rgba(147, 51, 234, 0.06)');
        glassDepthGrad.addColorStop(1, 'rgba(25, 10, 48, 0.35)');
        ctx.fillStyle = glassDepthGrad;
        ctx.beginPath();
        ctx.arc(bowlCenterX, bowlCenterY, bowlRadius, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        // --- MULTIPLE FOLDED WHITE PAPER CHITS INSIDE BOWL ---
        ctx.save();
        // Clip inside lower hemisphere of glass bowl
        ctx.beginPath();
        ctx.arc(bowlCenterX, bowlCenterY, bowlRadius - 6, 0, Math.PI * 2);
        ctx.clip();

        // 18 folded paper slips scattered inside the bowl
        const chitOffsets = [
          { x: -55, y: 35, r: -0.25, w: 42, h: 26 },
          { x: 20, y: 50, r: 0.35, w: 46, h: 28 },
          { x: -15, y: 65, r: 0.1, w: 48, h: 25 },
          { x: 55, y: 40, r: -0.4, w: 40, h: 26 },
          { x: -70, y: 45, r: 0.5, w: 44, h: 27 },
          { x: -30, y: 30, r: -0.15, w: 42, h: 25 },
          { x: 35, y: 32, r: 0.22, w: 46, h: 27 },
          { x: 0, y: 45, r: -0.05, w: 50, h: 28 },
          { x: -45, y: 55, r: 0.3, w: 44, h: 26 },
          { x: 45, y: 58, r: -0.3, w: 42, h: 27 },
          { x: -10, y: 22, r: 0.18, w: 45, h: 26 },
          { x: 15, y: 20, r: -0.22, w: 43, h: 25 },
          { x: -60, y: 25, r: 0.45, w: 40, h: 24 },
          { x: 60, y: 25, r: -0.5, w: 38, h: 24 },
        ];

        // Draw background chits
        chitOffsets.forEach((chit, idx) => {
          // Slight flutter movement when hand stirs chits (at t ~ 3.6s to 4.8s)
          let flutterX = 0;
          let flutterY = 0;
          if (t >= 3.4 && t <= 5.0) {
            flutterX = Math.sin(t * 12 + idx) * 3;
            flutterY = Math.cos(t * 10 + idx) * 2;
          }

          ctx.save();
          ctx.translate(bowlCenterX + chit.x + flutterX, bowlCenterY + chit.y + flutterY);
          ctx.rotate(chit.r);

          // Paper slip shadow
          ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
          ctx.fillRect(-chit.w / 2 + 2, -chit.h / 2 + 3, chit.w, chit.h);

          // Paper slip body (white folded card)
          const paperGrad = ctx.createLinearGradient(-chit.w / 2, -chit.h / 2, chit.w / 2, chit.h / 2);
          paperGrad.addColorStop(0, '#f8fafc');
          paperGrad.addColorStop(0.5, '#e2e8f0');
          paperGrad.addColorStop(1, '#cbd5e1');
          ctx.fillStyle = paperGrad;
          ctx.beginPath();
          ctx.roundRect(-chit.w / 2, -chit.h / 2, chit.w, chit.h, 3);
          ctx.fill();

          // Crease line down middle
          ctx.strokeStyle = 'rgba(100, 116, 139, 0.4)';
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(-chit.w * 0.1, -chit.h / 2);
          ctx.lineTo(-chit.w * 0.1, chit.h / 2);
          ctx.stroke();

          ctx.restore();
        });

        ctx.restore(); // end clip

        // --- GLASS BOWL FOREGROUND HIGHLIGHTS & RIM ---
        ctx.save();
        // Thick top rim
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.65)';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.ellipse(bowlCenterX, bowlCenterY - bowlRadius * 0.45, bowlRadius * 0.72, bowlRadius * 0.22, 0, 0, Math.PI * 2);
        ctx.stroke();

        // Inner rim lip
        ctx.strokeStyle = 'rgba(255, 215, 120, 0.35)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.ellipse(bowlCenterX, bowlCenterY - bowlRadius * 0.45, bowlRadius * 0.68, bowlRadius * 0.2, 0, 0, Math.PI * 2);
        ctx.stroke();

        // Main glass sphere outline
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(bowlCenterX, bowlCenterY, bowlRadius, 0, Math.PI * 2);
        ctx.stroke();

        // Specular curved reflections on the glass (Left curved crescent)
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.75)';
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.arc(bowlCenterX, bowlCenterY, bowlRadius - 10, -Math.PI * 0.85, -Math.PI * 0.45);
        ctx.stroke();

        // Bottom right soft reflection
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
        ctx.lineWidth = 3.5;
        ctx.beginPath();
        ctx.arc(bowlCenterX, bowlCenterY, bowlRadius - 10, Math.PI * 0.15, Math.PI * 0.4);
        ctx.stroke();
        ctx.restore();

        // --- SCENE 2: GOLDEN GLOWING HAND ANIMATION (3.0s to 6.2s) ---
        // Exactly matching the golden outline hand from user's video at 00:02 - 00:04
        if (t >= 2.8 && t <= 6.5) {
          ctx.save();
          // Hand kinematics
          // Enter: 3.0s -> 4.0s (descends from top into bowl)
          // Stir / Grasp: 4.0s -> 4.8s (holds chit)
          // Lift: 4.8s -> 6.2s (moves up with chit in fingers)
          let handY = 0;
          let handRot = 0;
          let chitPicked = false;

          if (t < 4.0) {
            const p = (t - 3.0) / 1.0;
            const easeP = p * p * (3 - 2 * p);
            handY = (bowlCenterY - bowlRadius * 1.5) + easeP * (bowlRadius * 1.35);
            handRot = -0.1 + easeP * 0.1;
          } else if (t < 4.8) {
            handY = bowlCenterY - bowlRadius * 0.15 + Math.sin((t - 4.0) * 8) * 4;
            handRot = 0;
            chitPicked = true;
          } else {
            const p = Math.min(1, (t - 4.8) / 1.3);
            const easeP = p * p * (3 - 2 * p);
            handY = (bowlCenterY - bowlRadius * 0.15) - easeP * (bowlRadius * 1.6);
            handRot = 0.08 * easeP;
            chitPicked = true;
          }

          const handX = bowlCenterX - 10;

          // Stylized Golden Glowing Line-Art Hand (As in user's video)
          ctx.translate(handX, handY);
          ctx.rotate(handRot);

          ctx.shadowColor = '#ffd700';
          ctx.shadowBlur = 18;
          ctx.strokeStyle = '#ffe57f';
          ctx.lineWidth = 3.5;
          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';

          // Wrist and Forearm descending
          ctx.beginPath();
          ctx.moveTo(-16, -160);
          ctx.bezierCurveTo(-16, -100, -22, -60, -20, -20); // left wrist
          ctx.bezierCurveTo(-26, 0, -32, 20, -26, 38); // thumb base
          // Thumb curved downward/inward
          ctx.bezierCurveTo(-20, 52, -10, 58, 2, 48);
          // Index Finger reaching down to grasp chit
          ctx.moveTo(-10, -20);
          ctx.bezierCurveTo(-8, 5, -6, 35, 10, 56);
          ctx.bezierCurveTo(15, 60, 20, 52, 16, 40);
          // Middle Finger
          ctx.moveTo(-4, -18);
          ctx.bezierCurveTo(4, 5, 8, 32, 22, 48);
          ctx.bezierCurveTo(28, 50, 32, 42, 26, 32);
          // Ring Finger & Pinky curled
          ctx.moveTo(4, -16);
          ctx.bezierCurveTo(14, 5, 20, 24, 30, 30);
          ctx.bezierCurveTo(34, 32, 38, 25, 30, 16);
          // Right wrist border
          ctx.moveTo(14, -160);
          ctx.bezierCurveTo(14, -100, 20, -60, 16, -18);
          ctx.stroke();

          // Soft golden internal glow aura
          ctx.fillStyle = 'rgba(255, 215, 0, 0.08)';
          ctx.fill();

          // Folded paper chit held between fingers when chitPicked is true
          if (chitPicked) {
            ctx.save();
            ctx.translate(6, 52);
            ctx.rotate(0.35);

            // Paper slip in fingers
            ctx.shadowColor = 'rgba(0, 0, 0, 0.4)';
            ctx.shadowBlur = 8;
            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.roundRect(-22, -14, 44, 28, 3);
            ctx.fill();

            // Crease
            ctx.strokeStyle = '#94a3b8';
            ctx.lineWidth = 1.2;
            ctx.beginPath();
            ctx.moveTo(0, -14);
            ctx.lineTo(0, 14);
            ctx.stroke();
            ctx.restore();
          }

          ctx.restore();
        }

        ctx.restore(); // end camera zoom/pan

        // --- SCENE 3: PAPER CHIT ZOOMS IN, RADIANT LENS FLARE & WINNER PARCHMENT REVEAL ---
        // (6.0s to 9.8s)
        if (t >= 6.0 && t < 9.8) {
          ctx.save();

          // Zoom Progress: from small at (6.0s) to full prominent center card (7.5s onwards)
          let cardProgress = Math.min(1, (t - 6.0) / 1.5);
          const easeZoom = cardProgress * cardProgress * (3 - 2 * cardProgress);

          const cardX = width / 2;
          const cardY = height / 2;

          // RADIANT LENS FLARE BURST (At 6.6s to 8.2s - matching 00:05 in user video)
          if (t >= 6.6 && t <= 8.4) {
            const flareProg = (t - 6.6) / 1.8;
            // Flare peaks at ~7.2s
            const flareIntensity = Math.sin(flareProg * Math.PI);

            ctx.save();
            // Blinding Anamorphic Horizontal Light Flare Beam
            const beamGrad = ctx.createLinearGradient(0, cardY, width, cardY);
            beamGrad.addColorStop(0, 'rgba(255, 240, 200, 0)');
            beamGrad.addColorStop(0.35, `rgba(255, 245, 220, ${flareIntensity * 0.7})`);
            beamGrad.addColorStop(0.5, `rgba(255, 255, 255, ${flareIntensity * 0.95})`);
            beamGrad.addColorStop(0.65, `rgba(255, 245, 220, ${flareIntensity * 0.7})`);
            beamGrad.addColorStop(1, 'rgba(255, 240, 200, 0)');
            ctx.fillStyle = beamGrad;
            ctx.fillRect(0, cardY - 40 * flareIntensity, width, 80 * flareIntensity);

            // Radial Sunburst Halo
            const sunburst = ctx.createRadialGradient(cardX, cardY, 10, cardX, cardY, width * 0.45);
            sunburst.addColorStop(0, `rgba(255, 255, 255, ${flareIntensity * 0.95})`);
            sunburst.addColorStop(0.25, `rgba(255, 230, 150, ${flareIntensity * 0.65})`);
            sunburst.addColorStop(0.6, `rgba(168, 85, 247, ${flareIntensity * 0.3})`);
            sunburst.addColorStop(1, 'rgba(0, 0, 0, 0)');
            ctx.fillStyle = sunburst;
            ctx.fillRect(0, 0, width, height);

            ctx.restore();
          }

          // Unfolding Parchment / Winner Card (Matches 00:06 - 00:07 in user's video)
          if (t >= 6.8) {
            const unfoldT = Math.min(1, (t - 6.8) / 0.8);
            const easeUnfold = unfoldT * unfoldT * (3 - 2 * unfoldT);

            const cardW = 680 * easeZoom;
            const cardH = 340 * easeZoom;

            ctx.save();
            ctx.translate(cardX, cardY);
            // Slight natural card tilt that straightens out
            const cardRot = (1 - easeUnfold) * 0.12;
            ctx.rotate(cardRot);

            // Card Deep Luxury Shadow
            ctx.shadowColor = 'rgba(0, 0, 0, 0.65)';
            ctx.shadowBlur = 32;
            ctx.shadowOffsetY = 16;

            // Crisp Parchment Background with Folded bottom-left corner (Just like user's video!)
            ctx.fillStyle = '#f8fafc';
            ctx.beginPath();
            const cornerFoldSize = 48 * easeUnfold;
            // Draw polygon with folded corner
            ctx.moveTo(-cardW / 2 + cornerFoldSize, cardH / 2);
            ctx.lineTo(-cardW / 2, cardH / 2 - cornerFoldSize);
            ctx.lineTo(-cardW / 2, -cardH / 2 + 12);
            ctx.quadraticCurveTo(-cardW / 2, -cardH / 2, -cardW / 2 + 12, -cardH / 2);
            ctx.lineTo(cardW / 2 - 12, -cardH / 2);
            ctx.quadraticCurveTo(cardW / 2, -cardH / 2, cardW / 2, -cardH / 2 + 12);
            ctx.lineTo(cardW / 2, cardH / 2 - 12);
            ctx.quadraticCurveTo(cardW / 2, cardH / 2, cardW / 2 - 12, cardH / 2);
            ctx.closePath();
            ctx.fill();

            // Folded paper corner triangle shadow
            ctx.fillStyle = '#e2e8f0';
            ctx.beginPath();
            ctx.moveTo(-cardW / 2, cardH / 2 - cornerFoldSize);
            ctx.lineTo(-cardW / 2 + cornerFoldSize, cardH / 2 - cornerFoldSize);
            ctx.lineTo(-cardW / 2 + cornerFoldSize, cardH / 2);
            ctx.closePath();
            ctx.fill();

            // Subtle paper border
            ctx.strokeStyle = 'rgba(203, 213, 225, 0.8)';
            ctx.lineWidth = 1.5;
            ctx.stroke();

            // WINNER CONTENT ON PARCHMENT
            if (t >= 7.2) {
              const textAlpha = Math.min(1, (t - 7.2) / 0.5);
              ctx.globalAlpha = textAlpha;

              // Top Label: "AL QURAH DRAW WINNER"
              ctx.fillStyle = '#64748b';
              ctx.font = '700 16px "Plus Jakarta Sans", sans-serif';
              ctx.textAlign = 'center';
              ctx.fillText('AL QURAH DRAW WINNER', 0, -cardH * 0.28);

              // WINNER NAME (Bold, elegant navy lettering like in user's video)
              ctx.fillStyle = '#0f172a';
              ctx.font = '800 48px "Plus Jakarta Sans", serif';
              ctx.shadowColor = 'rgba(0, 0, 0, 0.15)';
              ctx.shadowBlur = 4;
              ctx.shadowOffsetY = 2;
              ctx.fillText(effectiveWinnerName.toUpperCase(), 0, -cardH * 0.04);
              ctx.shadowBlur = 0;

              // Green "Verified ✓" Badge (Matching 00:06 in user's video)
              const badgeY = cardH * 0.24;
              const badgeW = 160;
              const badgeH = 40;

              ctx.fillStyle = '#10b981';
              ctx.beginPath();
              ctx.roundRect(-badgeW / 2, badgeY - badgeH / 2, badgeW, badgeH, 20);
              ctx.fill();

              // White Checkmark & "Verified" text
              ctx.fillStyle = '#ffffff';
              ctx.font = '700 16px "Plus Jakarta Sans", sans-serif';
              ctx.textAlign = 'center';
              ctx.fillText('✓ Verified', 0, badgeY + 5);

              // Qurah Name & Cycle Sub-tag
              ctx.fillStyle = '#475569';
              ctx.font = '600 14px "Plus Jakarta Sans", sans-serif';
              ctx.fillText(`${qurah.name} • Cycle ${cycle.cycleNumber}`, 0, cardH * 0.42);
            }

            ctx.restore();

            // GOLDEN CONFETTI & SPARKLES BURST AROUND THE CARD
            if (t >= 7.5) {
              ctx.save();
              const confettiTime = t - 7.5;
              for (let c = 0; c < 36; c++) {
                const angle = (c * Math.PI * 2) / 36;
                const speed = 120 + (c % 6) * 45;
                const dist = speed * confettiTime;
                const gravity = 70 * confettiTime * confettiTime;
                const cx = cardX + Math.cos(angle) * dist;
                const cy = cardY + Math.sin(angle) * dist * 0.7 + gravity;

                const cColors = ['#f59e0b', '#fbbf24', '#fde68a', '#10b981', '#ffffff'];
                ctx.fillStyle = cColors[c % cColors.length];
                ctx.save();
                ctx.translate(cx, cy);
                ctx.rotate(confettiTime * (c % 2 === 0 ? 5 : -5));
                ctx.fillRect(-4, -2, 8, 4);
                ctx.restore();
              }
              ctx.restore();
            }
          }

          ctx.restore();
        }
      }

      // ==========================================
      // SCENE 4: COMPLETE MEMBER STATUS ROSTER (9.8s to 14.0s)
      // "aur last ma tamam members ka naam ho jis ka hogaya ho is ka saat nishan laga howa ho
      //  jis ka nahi howa hai is ka saat pending ka nashan laga howa hooo
      //  Aur jis ka naam utta hai us ka naam highlight hoo
      //  Ya puri video 13 - 15 sec ki hoooooo"
      // ==========================================
      if (t >= 9.2) {
        const rosterAlpha = Math.min(1, (t - 9.2) / 0.6);
        ctx.save();
        ctx.globalAlpha = rosterAlpha;

        // Background dark luxury overlay for roster
        const darkGrad = ctx.createLinearGradient(0, 0, 0, height);
        darkGrad.addColorStop(0, 'rgba(10, 5, 20, 0.94)');
        darkGrad.addColorStop(1, 'rgba(18, 7, 34, 0.98)');
        ctx.fillStyle = darkGrad;
        ctx.fillRect(0, 0, width, height);

        // Gold subtle accent border
        ctx.strokeStyle = 'rgba(255, 215, 120, 0.25)';
        ctx.lineWidth = 1.5;
        ctx.strokeRect(28, 24, width - 56, height - 48);

        // Header Section
        const headerY = 70;
        ctx.textAlign = 'center';

        // Subtitle badge
        ctx.fillStyle = '#fde68a';
        ctx.font = '700 13px "Plus Jakarta Sans", sans-serif';
        ctx.fillText('AL QURAH OFFICIAL DRAW RESULTS & ROSTER', width / 2, headerY - 14);

        // Main Title
        ctx.fillStyle = '#ffffff';
        ctx.font = '800 28px "Plus Jakarta Sans", sans-serif';
        ctx.shadowColor = 'rgba(255, 215, 120, 0.4)';
        ctx.shadowBlur = 8;
        ctx.fillText(`${qurah.name} • Cycle ${cycle.cycleNumber} Draw`, width / 2, headerY + 18);
        ctx.shadowBlur = 0;

        // Meta Bar: Date & Sharia Guarantee
        ctx.fillStyle = '#94a3b8';
        ctx.font = '500 13px "Plus Jakarta Sans", sans-serif';
        const totalPool = `${qurah.currencySymbol || 'Rs'} ${qurah.totalAmount.toLocaleString()}`;
        ctx.fillText(
          `Video Generated: ${formattedGenDate}  |  Draw Pool: ${totalPool}  |  Total Members: ${qurah.members.length}`,
          width / 2,
          headerY + 44
        );

        // --- GRID / ROSTER OF ALL MEMBERS ("tamam members ka naam ho") ---
        const members = qurah.members;
        const total = members.length;

        // Dynamic column layout based on member count
        const cols = total <= 6 ? 2 : total <= 12 ? 3 : 4;
        const rows = Math.ceil(total / cols);

        const gridLeft = 60;
        const gridTop = 150;
        const gridWidth = width - 120;
        const gridHeight = height - 235;

        const cellW = (gridWidth - (cols - 1) * 16) / cols;
        const cellH = Math.min(68, (gridHeight - (rows - 1) * 12) / rows);

        members.forEach((member, idx) => {
          const colIdx = idx % cols;
          const rowIdx = Math.floor(idx / cols);

          const x = gridLeft + colIdx * (cellW + 16);
          const y = gridTop + rowIdx * (cellH + 12);

          const isCurrentWinner =
            member.id === winningMemberId ||
            member.name.toLowerCase() === effectiveWinnerName.toLowerCase();
          const pastCycleWon = winnerMap.get(member.id);
          const hasWonPast = pastCycleWon !== undefined;
          const isPending = !isCurrentWinner && !hasWonPast;

          ctx.save();

          if (isCurrentWinner) {
            // ==========================================
            // "Aur jis ka naam utta hai us ka naam highlight hoo"
            // Prominent Radiant Golden Highlight for Newly Drawn Winner
            // ==========================================
            const pulse = 0.8 + 0.2 * Math.sin(t * 8);

            // Shimmering Golden Gradient Background
            const winGrad = ctx.createLinearGradient(x, y, x + cellW, y + cellH);
            winGrad.addColorStop(0, 'rgba(251, 191, 36, 0.35)');
            winGrad.addColorStop(0.5, 'rgba(245, 158, 11, 0.45)');
            winGrad.addColorStop(1, 'rgba(217, 119, 6, 0.35)');
            ctx.fillStyle = winGrad;
            ctx.beginPath();
            ctx.roundRect(x, y, cellW, cellH, 12);
            ctx.fill();

            // Pulsing Radiant Golden Glowing Border
            ctx.shadowColor = '#ffd700';
            ctx.shadowBlur = 16 * pulse;
            ctx.strokeStyle = `rgba(255, 230, 100, ${pulse})`;
            ctx.lineWidth = 3;
            ctx.stroke();
            ctx.shadowBlur = 0;

            // Crown / Star Icon + Member Name
            ctx.textAlign = 'left';
            ctx.fillStyle = '#ffffff';
            ctx.font = '800 17px "Plus Jakarta Sans", sans-serif';
            ctx.fillText(`👑 ${member.name}`, x + 16, y + cellH * 0.45);

            // Highlight Badge: "⭐ WINNER THIS DRAW"
            const badgeW = 145;
            const badgeH = 22;
            const badgeX = x + cellW - badgeW - 12;
            const badgeY = y + (cellH - badgeH) / 2;

            ctx.fillStyle = '#fbbf24';
            ctx.beginPath();
            ctx.roundRect(badgeX, badgeY, badgeW, badgeH, 11);
            ctx.fill();

            ctx.fillStyle = '#0f172a';
            ctx.font = '800 11px "Plus Jakarta Sans", sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText('⭐ DRAW WINNER!', badgeX + badgeW / 2, badgeY + 15);
          } else if (hasWonPast) {
            // ==========================================
            // "jis ka hogaya ho is ka saat nishan laga howa ho"
            // Completed Winner mark (Green Checkmark badge)
            // ==========================================
            ctx.fillStyle = 'rgba(16, 185, 129, 0.08)';
            ctx.beginPath();
            ctx.roundRect(x, y, cellW, cellH, 10);
            ctx.fill();

            ctx.strokeStyle = 'rgba(16, 185, 129, 0.35)';
            ctx.lineWidth = 1.2;
            ctx.stroke();

            // Member Name
            ctx.textAlign = 'left';
            ctx.fillStyle = '#e2e8f0';
            ctx.font = '600 15px "Plus Jakarta Sans", sans-serif';
            ctx.fillText(`${idx + 1}. ${member.name}`, x + 14, y + cellH * 0.58);

            // Completed Nishan / Badge: "✓ Won Cycle X"
            const badgeW = 100;
            const badgeH = 22;
            const badgeX = x + cellW - badgeW - 10;
            const badgeY = y + (cellH - badgeH) / 2;

            ctx.fillStyle = 'rgba(16, 185, 129, 0.2)';
            ctx.beginPath();
            ctx.roundRect(badgeX, badgeY, badgeW, badgeH, 11);
            ctx.fill();

            ctx.fillStyle = '#34d399';
            ctx.font = '700 11px "Plus Jakarta Sans", sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(`✓ Won C${pastCycleWon}`, badgeX + badgeW / 2, badgeY + 15);
          } else {
            // ==========================================
            // "jis ka nahi howa hai is ka saat pending ka nashan laga howa hooo"
            // Pending Member mark (Clock / Pending badge)
            // ==========================================
            ctx.fillStyle = 'rgba(255, 255, 255, 0.04)';
            ctx.beginPath();
            ctx.roundRect(x, y, cellW, cellH, 10);
            ctx.fill();

            ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
            ctx.lineWidth = 1;
            ctx.stroke();

            // Member Name
            ctx.textAlign = 'left';
            ctx.fillStyle = '#cbd5e1';
            ctx.font = '500 14px "Plus Jakarta Sans", sans-serif';
            ctx.fillText(`${idx + 1}. ${member.name}`, x + 14, y + cellH * 0.58);

            // Pending Nishan / Badge: "⏳ Pending"
            const badgeW = 85;
            const badgeH = 22;
            const badgeX = x + cellW - badgeW - 10;
            const badgeY = y + (cellH - badgeH) / 2;

            ctx.fillStyle = 'rgba(245, 158, 11, 0.15)';
            ctx.beginPath();
            ctx.roundRect(badgeX, badgeY, badgeW, badgeH, 11);
            ctx.fill();

            ctx.fillStyle = '#fbbf24';
            ctx.font = '600 11px "Plus Jakarta Sans", sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText('⏳ Pending', badgeX + badgeW / 2, badgeY + 15);
          }

          ctx.restore();
        });

        // Footer Section
        const footerY = height - 42;
        ctx.textAlign = 'center';
        ctx.font = '600 12px "Plus Jakarta Sans", sans-serif';
        ctx.fillStyle = '#34d399';
        ctx.fillText(
          '100% Interest-Free Sharia Committee • Transparent Chit Draw Executed • All Members Recorded',
          width / 2,
          footerY
        );

        ctx.restore();
      }

      ctx.restore(); // end master canvas restore
      ctx.restore(); // end 1080p scale restore
    },
    [qurah, cycle, effectiveWinnerName, winningMemberId, winnerMap, formattedGenDate]
  );

  // Animation Frame Loop
  const tick = useCallback(
    (timestamp: number) => {
      if (!lastTimestampRef.current) {
        lastTimestampRef.current = timestamp;
      }
      const deltaSec = (timestamp - lastTimestampRef.current) / 1000;
      lastTimestampRef.current = timestamp;

      setCurrentTime((prevTime) => {
        const nextTime = prevTime + deltaSec;

        // Check if finished
        if (nextTime >= TOTAL_DURATION) {
          setIsPlaying(false);
          lastTimestampRef.current = null;
          return TOTAL_DURATION;
        }

        handleSoundTriggers(nextTime);
        return nextTime;
      });

      animFrameIdRef.current = requestAnimationFrame(tick);
    },
    [TOTAL_DURATION, handleSoundTriggers]
  );

  // Render canvas whenever currentTime changes
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    renderFrame(ctx, currentTime, 1920, 1080);
  }, [currentTime, renderFrame]);

  // Handle Play/Pause
  useEffect(() => {
    if (isPlaying) {
      soundEffects.initCtx();
      lastTimestampRef.current = null;
      animFrameIdRef.current = requestAnimationFrame(tick);
    } else {
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
        animFrameIdRef.current = null;
      }
    }

    return () => {
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
        animFrameIdRef.current = null;
      }
    };
  }, [isPlaying, tick]);

  // Autoplay on mount
  useEffect(() => {
    if (autoPlay) {
      const timer = setTimeout(() => {
        setIsPlaying(true);
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [autoPlay]);

  const handlePlayPause = () => {
    if (currentTime >= TOTAL_DURATION) {
      // Replay from beginning
      resetAudioTriggers();
      setCurrentTime(0);
      setIsPlaying(true);
    } else {
      setIsPlaying(!isPlaying);
    }
  };

  const handleReplay = () => {
    resetAudioTriggers();
    setCurrentTime(0);
    setIsPlaying(true);
  };

  const handleScrubberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = parseFloat(e.target.value);
    resetAudioTriggers();
    setCurrentTime(newTime);
  };

  // Toggle Fullscreen
  const handleToggleFullscreen = () => {
    const elem = containerRef.current;
    if (!elem) return;

    if (!document.fullscreenElement) {
      elem.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  // WhatsApp Share Message
  const handleShareWhatsApp = () => {
    const text = encodeURIComponent(
      `🎉 *Al Qurah Official Draw Reveal Video* 🎉\n` +
      `📌 *Qurah:* ${qurah.name}\n` +
      `🔢 *Cycle:* Cycle #${cycle.cycleNumber}\n` +
      `📅 *Date:* ${formattedGenDate}\n` +
      `🏆 *Drawn Winner:* *${effectiveWinnerName}*\n` +
      `💰 *Total Pool:* ${qurah.currencySymbol || 'Rs'} ${qurah.totalAmount.toLocaleString()}\n` +
      `✅ *All Member Statuses Recorded & Verified 100% Sharia Interest-Free!*\n\n` +
      `Watch full 14s Video Reveal with chit draw animation!`
    );
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  // REAL VIDEO RECORDER & EXPORTER: Records canvas into real MP4 / WebM video file
  const handleDownloadVideo = async () => {
    if (isExporting) return;
    setIsExporting(true);
    setExportProgress(0);

    const canvas = canvasRef.current;
    if (!canvas) {
      setIsExporting(false);
      return;
    }

    try {
      // Pause active playback during export
      setIsPlaying(false);
      resetAudioTriggers();

      // Create an offscreen canvas at full HD 1920x1080 for pristine recording
      const exportCanvas = document.createElement('canvas');
      exportCanvas.width = 1920;
      exportCanvas.height = 1080;
      const exportCtx = exportCanvas.getContext('2d');
      if (!exportCtx) throw new Error('Could not get canvas context');

      // Setup audio destination if Web Audio is available
      const audioCtx = soundEffects.getContext();
      let audioStreamNode: MediaStreamAudioDestinationNode | null = null;
      let combinedStream: MediaStream;

      const videoStream = exportCanvas.captureStream(30);

      if (audioCtx) {
        audioStreamNode = audioCtx.createMediaStreamDestination();
        soundEffects.setRecordingDestination(audioStreamNode);
        const tracks = [
          ...videoStream.getVideoTracks(),
          ...audioStreamNode.stream.getAudioTracks(),
        ];
        combinedStream = new MediaStream(tracks);
      } else {
        combinedStream = videoStream;
      }

      // Check supported MIME type
      const mimeTypes = [
        'video/mp4;codecs=avc1,mp4a.40.2',
        'video/mp4',
        'video/webm;codecs=vp9,opus',
        'video/webm;codecs=vp8,opus',
        'video/webm',
      ];
      let selectedMime = 'video/webm';
      for (const m of mimeTypes) {
        if (MediaRecorder.isTypeSupported(m)) {
          selectedMime = m;
          break;
        }
      }

      const recorder = new MediaRecorder(combinedStream, {
        mimeType: selectedMime,
        videoBitsPerSecond: 8000000, // 8 Mbps high-bitrate Full HD 1080p stream
      });

      const chunks: Blob[] = [];
      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) chunks.push(e.data);
      };

      const recordPromise = new Promise<Blob>((resolve, reject) => {
        recorder.onstop = () => {
          const blob = new Blob(chunks, { type: selectedMime });
          resolve(blob);
        };
        recorder.onerror = (e) => reject(e);
      });

      recorder.start();

      // Render frames sequentially from 0.0 to 14.0 seconds at 30fps
      const fps = 30;
      const totalFrames = Math.ceil(TOTAL_DURATION * fps);

      for (let f = 0; f <= totalFrames; f++) {
        const frameTime = (f / totalFrames) * TOTAL_DURATION;
        renderFrame(exportCtx, frameTime, 1920, 1080);
        handleSoundTriggers(frameTime);
        setExportProgress(Math.round((f / totalFrames) * 100));

        // Sleep 33ms to allow MediaRecorder to record at smooth natural pace
        await new Promise((r) => setTimeout(r, 33));
      }

      recorder.stop();
      soundEffects.setRecordingDestination(null);

      const videoBlob = await recordPromise;

      // Trigger instant file download
      const ext = selectedMime.includes('mp4') ? 'mp4' : 'webm';
      const filename = `alqurah-${qurah.name.toLowerCase().replace(/\s+/g, '-')}-cycle-${cycle.cycleNumber}-1080p-draw-video.${ext}`;
      const url = URL.createObjectURL(videoBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Video generation error:', err);
    } finally {
      setIsExporting(false);
      setExportProgress(0);
    }
  };

  const formatSec = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = Math.floor(s % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full rounded-2xl bg-[#0d0718] border border-amber-500/30 overflow-hidden shadow-2xl flex flex-col text-white select-none"
    >
      {/* Top Header Bar */}
      <div className="px-5 py-3.5 bg-gradient-to-r from-[#170a2c] via-[#210c3d] to-[#170a2c] border-b border-amber-500/20 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-amber-400/10 border border-amber-400/30 flex items-center justify-center text-amber-400">
            <Video className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-extrabold text-white tracking-wide">
                Al Qurah Draw Reveal Video
              </h3>
              <span className="text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1 shadow-sm">
                <Sparkles className="w-3 h-3 text-emerald-400" />
                <span>1080p Full HD</span>
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30">
                14-Sec Reveal
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              {qurah.name} &bull; Cycle {cycle.cycleNumber} &bull; {formattedGenDate}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Main Video Canvas Screen (16:9 Aspect Ratio - Native 1080p) */}
      <div className="relative w-full aspect-video bg-black flex items-center justify-center overflow-hidden">
        <canvas
          ref={canvasRef}
          width={1920}
          height={1080}
          onClick={handlePlayPause}
          className="w-full h-full object-contain cursor-pointer block"
        />

        {/* Center Play Button Overlay when Paused */}
        {!isPlaying && currentTime < TOTAL_DURATION && (
          <button
            type="button"
            onClick={handlePlayPause}
            className="absolute inset-0 m-auto w-16 h-16 rounded-full bg-amber-400/90 hover:bg-amber-300 text-slate-950 flex items-center justify-center shadow-2xl transition-all transform hover:scale-110 cursor-pointer"
          >
            <Play className="w-7 h-7 ml-1 fill-current" />
          </button>
        )}

        {/* Center Replay Button Overlay when Ended */}
        {currentTime >= TOTAL_DURATION && !isPlaying && (
          <button
            type="button"
            onClick={handleReplay}
            className="absolute inset-0 m-auto w-16 h-16 rounded-full bg-white text-slate-950 flex items-center justify-center shadow-2xl transition-all transform hover:scale-110 cursor-pointer"
          >
            <RotateCcw className="w-7 h-7" />
          </button>
        )}

        {/* Exporting Progress Overlay */}
        {isExporting && (
          <div className="absolute inset-0 bg-black/85 backdrop-blur-sm flex flex-col items-center justify-center gap-3 z-30">
            <div className="w-12 h-12 rounded-full border-4 border-emerald-400/30 border-t-emerald-400 animate-spin" />
            <div className="text-center">
              <h4 className="text-sm font-bold text-white">Rendering 1080p Full HD Video...</h4>
              <p className="text-xs text-emerald-300 font-mono mt-1">{exportProgress}% Completed (1920 &times; 1080)</p>
              <p className="text-[11px] text-slate-400 mt-1 max-w-xs">
                Generating 1080p crystal-clear golden chit reveal, light flare and complete member roster.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Interactive Controls & Timeline Bar */}
      <div className="p-4 bg-[#120822] border-t border-amber-500/20 space-y-3">
        {/* Timeline Scrubber */}
        <div className="space-y-1">
          <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
            <span className="text-amber-400 font-bold">{formatSec(currentTime)}</span>
            <div className="flex items-center gap-3 text-[10px]">
              <span className={currentTime < 3.0 ? 'text-amber-300 font-bold' : 'text-slate-500'}>
                1. Intro &amp; Bowl
              </span>
              <span>&bull;</span>
              <span className={currentTime >= 3.0 && currentTime < 6.2 ? 'text-amber-300 font-bold' : 'text-slate-500'}>
                2. Golden Hand
              </span>
              <span>&bull;</span>
              <span className={currentTime >= 6.2 && currentTime < 9.8 ? 'text-amber-300 font-bold' : 'text-slate-500'}>
                3. Winner Flare
              </span>
              <span>&bull;</span>
              <span className={currentTime >= 9.8 ? 'text-amber-300 font-bold' : 'text-slate-500'}>
                4. Full Roster
              </span>
            </div>
            <span>{formatSec(TOTAL_DURATION)}</span>
          </div>

          <input
            type="range"
            min={0}
            max={TOTAL_DURATION}
            step={0.05}
            value={currentTime}
            onChange={handleScrubberChange}
            className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer accent-amber-400"
          />
        </div>

        {/* Buttons Row */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          {/* Playback Controls */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePlayPause}
              className="p-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold transition-all cursor-pointer"
              title={isPlaying ? 'Pause' : 'Play'}
            >
              {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
            </button>

            <button
              type="button"
              onClick={handleReplay}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer"
              title="Replay from start"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() => setIsMuted(!isMuted)}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer"
              title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-slate-400" /> : <Volume2 className="w-4 h-4 text-amber-400" />}
            </button>

            <button
              type="button"
              onClick={handleToggleFullscreen}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer hidden sm:flex"
              title="Toggle Fullscreen"
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
          </div>

          {/* Action Export Buttons */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleShareWhatsApp}
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>Share to WhatsApp</span>
            </button>

            <button
              type="button"
              onClick={handleDownloadVideo}
              disabled={isExporting}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 disabled:opacity-50 text-slate-950 text-xs font-extrabold flex items-center gap-2 transition-all shadow-lg cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isExporting ? 'Exporting 1080p...' : 'Download 1080p Video (HD)'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
