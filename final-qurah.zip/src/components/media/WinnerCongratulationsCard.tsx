import React, { useRef, useEffect } from 'react';
import { Download, Trophy, CheckCircle2, ShieldCheck, Share2 } from 'lucide-react';
import { Qurah, Cycle } from '../../types';

interface WinnerCongratulationsCardProps {
  qurah: Qurah;
  cycle: Cycle;
  winnerName: string;
}

export const WinnerCongratulationsCard: React.FC<WinnerCongratulationsCardProps> = ({
  qurah,
  cycle,
  winnerName,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    drawWinnerCard();
  }, [qurah, cycle, winnerName]);

  const drawWinnerCard = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Specified dimensions: 1200x750px (matching screenshot)
    const w = 1200;
    const h = 750;
    canvas.width = w;
    canvas.height = h;

    // Background Gradient: Luxury Obsidian/Charcoal with subtle lighting
    const grad = ctx.createLinearGradient(0, 0, w, h);
    grad.addColorStop(0, '#0a0d14');
    grad.addColorStop(0.5, '#141824');
    grad.addColorStop(1, '#090b10');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);

    // Sleek border
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
    ctx.lineWidth = 2;
    ctx.strokeRect(36, 36, w - 72, h - 72);

    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 1;
    ctx.strokeRect(48, 48, w - 96, h - 96);

    // Islamic Bismillah at Top
    ctx.fillStyle = '#fde68a';
    ctx.font = '24px "Amiri", serif';
    ctx.textAlign = 'center';
    ctx.fillText('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', w / 2, 95);

    // Brand "AL QURA"
    ctx.fillStyle = '#ffffff';
    ctx.font = '800 24px "Plus Jakarta Sans", sans-serif';
    ctx.letterSpacing = '4px';
    ctx.fillText('AL QURA', w / 2, 140);

    // CONGRATULATIONS Heading (Matching screenshot)
    ctx.fillStyle = '#94a3b8';
    ctx.font = '800 28px "Plus Jakarta Sans", sans-serif';
    ctx.letterSpacing = '6px';
    ctx.fillText('CONGRATULATIONS', w / 2, 190);

    // Circle Avatar with initial (Matching screenshot)
    const avatarR = 48;
    const avatarX = w / 2;
    const avatarY = 270;

    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(avatarX, avatarY, avatarR, 0, Math.PI * 2);
    ctx.fill();

    const initial = (winnerName || 'W').charAt(0).toUpperCase();
    ctx.fillStyle = '#0a0d14';
    ctx.font = '800 48px "Plus Jakarta Sans", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(initial, avatarX, avatarY + 16);

    // Winner's Full Name (Large display)
    ctx.fillStyle = '#ffffff';
    ctx.font = '800 44px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(winnerName, w / 2, 380);

    // Qura Name and Cycle
    ctx.fillStyle = '#cbd5e1';
    ctx.font = '600 20px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(`${qurah.name} • Cycle ${cycle.cycleNumber}`, w / 2, 420);

    // Lump-Sum Pool Payout Pill
    const pillW = 560;
    const pillH = 72;
    const pillX = (w - pillW) / 2;
    const pillY = 460;

    ctx.fillStyle = 'rgba(255, 255, 255, 0.06)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(pillX, pillY, pillW, pillH, 36);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.font = '800 26px "Plus Jakarta Sans", monospace';
    const sym = qurah.currencySymbol || 'Rs';
    ctx.fillText(`Received Pool: ${sym} ${qurah.totalAmount.toLocaleString()}`, w / 2, pillY + 45);

    // Verified Seal
    ctx.fillStyle = '#34d399';
    ctx.font = '700 16px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(`✓ Verified Automated Draw • Draw Date: ${cycle.drawDate}`, w / 2, 580);

    // Ethical No Sood Guarantee
    ctx.fillStyle = '#94a3b8';
    ctx.font = '500 14px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(
      'Islamic Interest-Free (0% Sood) Rotating Savings Committee — Verified & Distributed',
      w / 2,
      640
    );

    // Footer
    ctx.fillStyle = '#64748b';
    ctx.font = '500 12px "Plus Jakarta Sans", sans-serif';
    ctx.fillText('Together We Grow • We Share We Win', w / 2, 690);
  };

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `${qurah.name.toLowerCase().replace(/\s+/g, '-')}-cycle-${cycle.cycleNumber}-winner-${winnerName.toLowerCase().replace(/\s+/g, '-')}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  return (
    <div className="bg-[#121620] rounded-2xl border border-white/10 p-5 shadow-lg space-y-4 text-white">
      <div className="flex items-center justify-between">
        <div>
          <span className="text-xs font-bold text-white block">Winner Card (1200 &times; 750)</span>
          <span className="text-[11px] text-slate-400">
            Awarded to {winnerName} for Cycle {cycle.cycleNumber}
          </span>
        </div>

        <button
          type="button"
          onClick={handleDownload}
          className="px-4 py-1.5 rounded-full bg-white hover:bg-slate-200 text-slate-950 text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Download 1200&times;750</span>
        </button>
      </div>

      <div className="w-full rounded-xl overflow-hidden border border-white/10 bg-[#0a0d14] shadow-inner flex items-center justify-center">
        <canvas ref={canvasRef} className="w-full h-auto max-h-[460px] object-contain block" />
      </div>
    </div>
  );
};
