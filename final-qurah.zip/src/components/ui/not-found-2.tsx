export * from "../../../components/ui/not-found-2";
