import React, { useState, useEffect } from 'react';
import {
  Trophy,
  ShieldCheck,
  Image as ImageIcon,
  Layers,
  Sparkles,
  Download,
  Calendar,
  Clock,
  CheckCircle2,
  Lock,
  Dice5,
  UserCheck,
  ChevronRight,
  AlertCircle,
  Video,
  Play,
  X,
} from 'lucide-react';
import { Qurah, Cycle, Member } from '../../types';
import { WinnerCongratulationsCard } from '../media/WinnerCongratulationsCard';
import { QurahReminderVariants } from '../media/QurahReminderVariants';
import { AlQurahDrawRevealVideo } from '../media/AlQurahDrawRevealVideo';
import { soundEffects } from '../../lib/audio';

interface DocumentTabProps {
  qurah: Qurah;
  activeCycleNumber?: number;
  initialCycleNumber?: number;
  onSelectCycle?: (cycleNumber: number) => void;
  onRecordWinner: (cycleNumber: number, winner: { memberId: string; memberName: string }) => void;
}

export const DocumentTab: React.FC<DocumentTabProps> = ({
  qurah,
  activeCycleNumber,
  initialCycleNumber,
  onSelectCycle,
  onRecordWinner,
}) => {
  const [internalCycleNumber, setInternalCycleNumber] = useState<number>(
    initialCycleNumber || activeCycleNumber || qurah.currentCycleNumber || 1
  );

  useEffect(() => {
    if (initialCycleNumber) setInternalCycleNumber(initialCycleNumber);
  }, [initialCycleNumber]);

  useEffect(() => {
    if (activeCycleNumber) setInternalCycleNumber(activeCycleNumber);
  }, [activeCycleNumber]);

  const [documentFilter, setDocumentFilter] = useState<'all' | 'video' | 'certificate' | 'reminders'>('all');
  const [manualMemberId, setManualMemberId] = useState<string>('');
  const [isDrawing, setIsDrawing] = useState(false);
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);
  const [videoModalWinnerName, setVideoModalWinnerName] = useState<string | undefined>(undefined);

  // Selected Cycle
  const currentNum = activeCycleNumber || internalCycleNumber;
  const selectedCycle =
    qurah.cycles.find((c) => c.cycleNumber === currentNum) || qurah.cycles[0];

  const handleSelect = (cNum: number) => {
    setInternalCycleNumber(cNum);
    if (onSelectCycle) onSelectCycle(cNum);
  };

  // Past winners
  const pastWinnerMemberIds = new Set<string>();
  qurah.cycles.forEach((c) => {
    if (c.winner && c.cycleNumber !== selectedCycle.cycleNumber) {
      pastWinnerMemberIds.add(c.winner.memberId);
    }
  });

  // Remaining eligible members
  const eligibleMembers = qurah.members.filter((m) => !pastWinnerMemberIds.has(m.id));

  // All members paid check
  const cyclePaidCount = qurah.members.filter((m) => !!selectedCycle.payments[m.id]).length;
  const isAllPaid = cyclePaidCount === qurah.members.length;

  // Conduct random draw and launch cinematic reveal video
  const handleConductRandomDraw = () => {
    if (!isAllPaid || eligibleMembers.length === 0 || isDrawing) return;

    setIsDrawing(true);
    soundEffects.playShuffle();

    setTimeout(() => {
      // Pick random eligible member
      const randomIndex = Math.floor(Math.random() * eligibleMembers.length);
      const chosen = eligibleMembers[randomIndex];

      soundEffects.playChime();
      onRecordWinner(selectedCycle.cycleNumber, {
        memberId: chosen.id,
        memberName: chosen.name,
      });

      setVideoModalWinnerName(chosen.name);
      setIsDrawing(false);
      // Auto open 14s cinematic reveal video matching user requirement
      setIsVideoModalOpen(true);
    }, 700);
  };

  // Conduct manual selection
  const handleConfirmManualWinner = () => {
    if (!manualMemberId) return;
    const member = qurah.members.find((m) => m.id === manualMemberId);
    if (!member) return;

    soundEffects.playChime();
    onRecordWinner(selectedCycle.cycleNumber, {
      memberId: member.id,
      memberName: member.name,
    });
    setVideoModalWinnerName(member.name);
    setManualMemberId('');
    setIsVideoModalOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-[#11141c] border border-white/10 rounded-2xl p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <span>Committee Documents &amp; Certificates</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Official draw execution, winner certificates, and cycle reminder media suite.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-emerald-400 font-semibold bg-emerald-500/10 px-3 py-1.5 rounded-full border border-emerald-500/20 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>0% Sood Official Media</span>
          </span>
        </div>
      </div>

      {/* Cycle Selection Cards */}
      <div className="bg-[#11141c] border border-white/10 rounded-2xl p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Select Cycle Box ({qurah.cycles.length} Total Cycles)
          </h3>
          <span className="text-xs text-slate-400 font-mono">
            Selected: Cycle {selectedCycle.cycleNumber}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {qurah.cycles.map((c) => {
            const isSelected = c.cycleNumber === selectedCycle.cycleNumber;
            const cyclePaid = qurah.members.filter((m) => !!c.payments[m.id]).length;
            const cycleAllPaid = cyclePaid === qurah.members.length;

            let borderStyle = 'border-white/10 bg-[#161a24] hover:border-white/20';
            let badgeBg = 'bg-white/5 text-slate-400';
            let statusText = 'Upcoming';

            if (c.status === 'completed') {
              borderStyle = 'border-emerald-500/30 bg-emerald-950/20 hover:border-emerald-500/50';
              badgeBg = 'bg-emerald-500/20 text-emerald-400 font-bold';
              statusText = 'Completed';
            } else if (c.status === 'current') {
              borderStyle = 'border-white/40 bg-[#1e2533] hover:border-white/60';
              badgeBg = 'bg-white text-slate-950 font-bold';
              statusText = 'Active Now';
            }

            if (isSelected) {
              borderStyle += ' ring-2 ring-white shadow-md';
            }

            return (
              <div
                key={c.cycleNumber}
                onClick={() => handleSelect(c.cycleNumber)}
                className={`p-3.5 rounded-xl border cursor-pointer transition-all duration-150 flex flex-col justify-between ${borderStyle}`}
              >
                <div>
                  <div className="flex items-center justify-between gap-1 mb-1.5">
                    <span className="text-xs font-extrabold font-mono text-white">
                      Cycle {c.cycleNumber}
                    </span>
                    <span className={`text-[9px] px-2 py-0.5 rounded-full ${badgeBg}`}>
                      {statusText}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono">{c.drawDate}</div>
                </div>

                <div className="mt-3 pt-2 border-t border-white/5 flex items-center justify-between text-[11px]">
                  {c.winner ? (
                    <span className="text-emerald-400 font-bold flex items-center gap-1 truncate text-[11px]">
                      <CheckCircle2 className="w-3 h-3 shrink-0" />
                      <span className="truncate">{c.winner.memberName}</span>
                    </span>
                  ) : cycleAllPaid ? (
                    <span className="text-amber-400 font-semibold text-[11px]">
                      Ready to Draw
                    </span>
                  ) : (
                    <span className="text-slate-400 text-[11px]">
                      {cyclePaid}/{qurah.members.length} Paid
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* DRAW EXECUTION / WINNER SUMMARY CARD */}
      <div className="bg-[#11141c] border border-white/10 rounded-2xl p-6">
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-white/10">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Trophy className="w-4 h-4 text-amber-400" />
              <span>Cycle {selectedCycle.cycleNumber} Draw Status</span>
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Scheduled Date: {selectedCycle.drawDate} &bull; Pool: {qurah.currencySymbol || 'Rs'} {qurah.totalAmount.toLocaleString()}
            </p>
          </div>

          <span
            className={`text-xs px-3 py-1 rounded-full font-bold flex items-center gap-1.5 ${
              selectedCycle.winner
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : isAllPaid
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                : 'bg-white/5 text-slate-400 border border-white/10'
            }`}
          >
            {selectedCycle.winner ? (
              <>
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Winner Drawn</span>
              </>
            ) : isAllPaid ? (
              <>
                <Sparkles className="w-3.5 h-3.5" />
                <span>Ready for Draw</span>
              </>
            ) : (
              <>
                <Lock className="w-3.5 h-3.5" />
                <span>{cyclePaidCount}/{qurah.members.length} Paid</span>
              </>
            )}
          </span>
        </div>

        {selectedCycle.winner ? (
          /* WINNER IS DRAWN */
          <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-950/40 via-[#111a24] to-[#121620] border border-emerald-500/30 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0">
                <Trophy className="w-7 h-7" />
              </div>
              <div>
                <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider block">
                  Official Cycle {selectedCycle.cycleNumber} Recipient
                </span>
                <h4 className="text-xl font-black text-white mt-0.5">
                  {selectedCycle.winner.memberName}
                </h4>
                <p className="text-xs text-slate-400 mt-1">
                  Payout Amount: <span className="font-bold text-white font-mono">{qurah.currencySymbol || 'Rs'} {qurah.totalAmount.toLocaleString()}</span> &bull; 0% Interest Free Committee
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  setVideoModalWinnerName(selectedCycle.winner?.memberName);
                  setIsVideoModalOpen(true);
                }}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
              >
                <Video className="w-3.5 h-3.5" />
                <span>Watch Draw Video (14s)</span>
              </button>

              <span className="text-xs bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-3.5 py-1.5 rounded-full font-semibold flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Verified Sharia Draw</span>
              </span>
            </div>
          </div>
        ) : isAllPaid ? (
          /* ALL PAID - READY TO CONDUCT DRAW */
          <div className="space-y-4">
            <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-950/30 via-[#1e1b12] to-[#14171d] border border-amber-500/30">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <div className="inline-flex items-center gap-1.5 text-xs text-amber-400 font-bold bg-amber-500/10 px-2.5 py-0.5 rounded-full border border-amber-500/20 mb-2">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>All {qurah.members.length} Members Have Deposited</span>
                  </div>
                  <h4 className="text-lg font-bold text-white">
                    Conduct Draw for Cycle {selectedCycle.cycleNumber}
                  </h4>
                  <p className="text-xs text-slate-400 mt-1 max-w-xl">
                    There are {eligibleMembers.length} remaining eligible member{eligibleMembers.length === 1 ? '' : 's'} who have not yet received the pool. Conduct a transparent random draw or select the recipient below.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleConductRandomDraw}
                  disabled={isDrawing}
                  className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 transition-all shadow-lg cursor-pointer shrink-0 disabled:opacity-50"
                >
                  <Dice5 className={`w-4 h-4 ${isDrawing ? 'animate-spin' : ''}`} />
                  <span>{isDrawing ? 'Drawing Winner...' : 'Conduct Transparent Draw'}</span>
                </button>
              </div>

              {/* Eligible Members Chips */}
              <div className="mt-4 pt-3 border-t border-amber-500/10">
                <span className="text-[11px] text-slate-400 block mb-2 font-medium">
                  Eligible Members in Chit Pool ({eligibleMembers.length}):
                </span>
                <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
                  {eligibleMembers.map((m) => (
                    <span
                      key={m.id}
                      className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-slate-200 text-xs font-medium"
                    >
                      {m.name}
                    </span>
                  ))}
                </div>
              </div>

              {/* Manual Winner Selection Alternative */}
              <div className="mt-4 pt-3 border-t border-amber-500/10 flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                <span className="text-xs text-slate-400 shrink-0">Or record offline chit draw:</span>
                <select
                  value={manualMemberId}
                  onChange={(e) => setManualMemberId(e.target.value)}
                  className="bg-[#0e1218] border border-white/15 text-white text-xs rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-amber-400 grow"
                >
                  <option value="">-- Choose winning member manually --</option>
                  {eligibleMembers.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} ({m.phone})
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={handleConfirmManualWinner}
                  disabled={!manualMemberId}
                  className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 disabled:opacity-30 disabled:cursor-not-allowed text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>Confirm Winner</span>
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* NOT ALL MEMBERS PAID YET */
          <div className="p-5 rounded-2xl bg-[#161a24] border border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-slate-400 shrink-0 mt-0.5">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">
                  Payment Collection in Progress ({cyclePaidCount} of {qurah.members.length} Paid)
                </h4>
                <p className="text-xs text-slate-400 mt-1">
                  All {qurah.members.length} members must confirm their deposits before the official Cycle {selectedCycle.cycleNumber} draw can be conducted.
                </p>
              </div>
            </div>

            <div className="text-xs text-slate-400 font-mono bg-white/5 px-3 py-1.5 rounded-lg border border-white/5">
              {qurah.members.length - cyclePaidCount} Pending
            </div>
          </div>
        )}
      </div>

      {/* CERTIFICATES & REMINDERS SUITE */}
      <div id="photos-and-documents-section" className="bg-[#11141c] border border-white/10 rounded-2xl p-6 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
              <span>Official Media &amp; Certificates</span>
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Cycle {selectedCycle.cycleNumber} verification documents and member notification suite.
            </p>
          </div>

          {/* Filter Buttons */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={() => setDocumentFilter('all')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                documentFilter === 'all'
                  ? 'bg-white text-slate-950 shadow-md'
                  : 'bg-[#161a24] hover:bg-white/10 text-slate-300 border border-white/10'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>All</span>
            </button>

            <button
              type="button"
              onClick={() => setDocumentFilter('video')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                documentFilter === 'video'
                  ? 'bg-amber-400 text-slate-950 shadow-md'
                  : 'bg-[#161a24] hover:bg-white/10 text-amber-300 border border-amber-500/20'
              }`}
            >
              <Video className="w-3.5 h-3.5" />
              <span>Draw Reveal Video (1080p, 14s)</span>
            </button>

            <button
              type="button"
              onClick={() => setDocumentFilter('certificate')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                documentFilter === 'certificate'
                  ? 'bg-white text-slate-950 shadow-md'
                  : 'bg-[#161a24] hover:bg-white/10 text-slate-300 border border-white/10'
              }`}
            >
              <Trophy className="w-3.5 h-3.5" />
              <span>Certificate</span>
            </button>

            <button
              type="button"
              onClick={() => setDocumentFilter('reminders')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                documentFilter === 'reminders'
                  ? 'bg-white text-slate-950 shadow-md'
                  : 'bg-[#161a24] hover:bg-white/10 text-slate-300 border border-white/10'
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>Reminders</span>
            </button>
          </div>
        </div>

        <div className="space-y-6 pt-2">
          {/* Al Qurah 14-Second Draw Reveal Video (Chit draw, light flare, winner parchment & member roster) */}
          {(documentFilter === 'all' || documentFilter === 'video') && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Video className="w-4 h-4 text-amber-400" />
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-300">
                    Official Draw Reveal Video (13 - 15 Sec) &bull; Chit Draw &amp; Complete Member Roster
                  </h4>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">
                  1920 &times; 1080 Full HD &bull; With Sound &bull; WhatsApp Ready
                </span>
              </div>

              <AlQurahDrawRevealVideo
                qurah={qurah}
                cycle={selectedCycle}
                winnerName={
                  selectedCycle.winner?.memberName ||
                  (eligibleMembers[0]?.name ?? 'Cycle Winner')
                }
                autoPlay={false}
              />
            </div>
          )}

          {/* Winner Congratulations Certificate */}
          {(documentFilter === 'all' || documentFilter === 'certificate') && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Trophy className="w-4 h-4 text-amber-400" />
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                    Official Winner Certificate &bull; Cycle {selectedCycle.cycleNumber}
                  </h4>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">
                  1200 &times; 750 PNG &bull; WhatsApp Ready
                </span>
              </div>

              <WinnerCongratulationsCard
                qurah={qurah}
                cycle={selectedCycle}
                winnerName={
                  selectedCycle.winner?.memberName ||
                  (eligibleMembers[0]?.name ?? 'Cycle Recipient')
                }
              />
            </div>
          )}

          {/* 3-Variant Cycle Draw Reminder Suite (7d, 3d, 1d) */}
          {(documentFilter === 'all' || documentFilter === 'reminders') && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-emerald-400" />
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                    Cycle Reminder Posters &bull; 7 Days, 3 Days &amp; Urgent 1 Day
                  </h4>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">
                  1:1 Square &bull; Vault Stored &bull; WhatsApp Ready
                </span>
              </div>

              <QurahReminderVariants
                qurah={qurah}
                cycle={selectedCycle}
              />
            </div>
          )}
        </div>
      </div>

      {/* 14-Sec Al Qurah Draw Reveal Video Modal */}
      {isVideoModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
          <div className="relative w-full max-w-4xl my-auto">
            <AlQurahDrawRevealVideo
              qurah={qurah}
              cycle={selectedCycle}
              winnerName={videoModalWinnerName || selectedCycle.winner?.memberName}
              onClose={() => setIsVideoModalOpen(false)}
              autoPlay={true}
            />
          </div>
        </div>
      )}
    </div>
  );
};
