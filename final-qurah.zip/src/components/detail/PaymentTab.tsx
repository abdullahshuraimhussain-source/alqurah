import React, { useState } from 'react';
import {
  CheckCircle2,
  Clock,
  Calendar,
  Award,
  Lock,
  ArrowRight,
  ShieldCheck,
  Check,
  CircleDot,
  Video,
} from 'lucide-react';
import { Qurah, Cycle, Member } from '../../types';
import { AlQurahDrawRevealVideo } from '../media/AlQurahDrawRevealVideo';

interface PaymentTabProps {
  qurah: Qurah;
  onTogglePayment: (cycleNumber: number, memberId: string) => void;
  onNavigateToDocumentCycle: (cycleNumber: number) => void;
}

export const PaymentTab: React.FC<PaymentTabProps> = ({
  qurah,
  onTogglePayment,
  onNavigateToDocumentCycle,
}) => {
  const [selectedCycleNumber, setSelectedCycleNumber] = useState<number>(
    qurah.currentCycleNumber || 1
  );
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);

  const selectedCycle =
    qurah.cycles.find((c) => c.cycleNumber === selectedCycleNumber) || qurah.cycles[0];

  const paidCount = qurah.members.filter((m) => !!selectedCycle.payments[m.id]).length;
  const isAllPaid = paidCount === qurah.members.length;
  const progressPct = Math.round((paidCount / qurah.members.length) * 100);

  return (
    <div className="space-y-6">
      {/* Top Detail Card with 5 Metrics (Matching Screenshot) */}
      <div className="bg-[#11141c] border border-white/10 rounded-2xl p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-full bg-[#1b2230] border border-white/10 flex items-center justify-center text-white font-bold text-lg shrink-0">
              {qurah.name.charAt(0)}
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">{qurah.name}</h2>
              <p className="text-xs text-slate-400 mt-1">{qurah.description}</p>
            </div>
          </div>

          {/* Cycle Selector Pills */}
          <div className="flex items-center gap-1.5 flex-wrap">
            {qurah.cycles.map((c) => (
              <button
                key={c.cycleNumber}
                type="button"
                onClick={() => setSelectedCycleNumber(c.cycleNumber)}
                className={`px-3 py-1.5 rounded-full text-xs font-mono font-bold transition-all ${
                  c.cycleNumber === selectedCycleNumber
                    ? 'bg-white text-slate-950 shadow-xs'
                    : 'bg-[#171c26] text-slate-400 hover:text-white border border-white/5'
                }`}
              >
                C{c.cycleNumber}
              </button>
            ))}
          </div>
        </div>

        {/* 5 Stats Row horizontally (Matching Screenshot) */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 p-4 rounded-xl bg-[#0c0f15] border border-white/5 text-xs">
          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">
              Members
            </span>
            <span className="font-extrabold text-white text-sm mt-0.5 block">
              {qurah.memberCount} Members
            </span>
          </div>

          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">
              Per Member
            </span>
            <span className="font-extrabold font-mono text-white text-sm mt-0.5 block">
              {qurah.currencySymbol || 'Rs'} {qurah.amountPerMember.toLocaleString()}
            </span>
          </div>

          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">
              Total Amount
            </span>
            <span className="font-extrabold font-mono text-white text-sm mt-0.5 block">
              {qurah.currencySymbol || 'Rs'} {qurah.totalAmount.toLocaleString()}
            </span>
          </div>

          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">
              Start Date
            </span>
            <span className="font-medium text-slate-300 text-xs mt-0.5 block font-mono">
              {qurah.startDate}
            </span>
          </div>

          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">
              End Date
            </span>
            <span className="font-medium text-slate-300 text-xs mt-0.5 block font-mono">
              {qurah.endDate}
            </span>
          </div>
        </div>

        {/* Current Cycle Progress Banner (Matching Screenshot) */}
        <div className="mt-6 pt-4 border-t border-white/5">
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="font-bold text-white">
              Cycle {selectedCycle.cycleNumber} of {qurah.memberCount} Progress
            </span>
            <span className="font-mono text-slate-400">
              {paidCount}/{qurah.members.length} Paid ({progressPct}%)
            </span>
          </div>
          <div className="w-full h-1.5 bg-[#1b2230] rounded-full overflow-hidden">
            <div
              className="h-full bg-white rounded-full transition-all duration-300"
              style={{ width: `${Math.max(5, progressPct)}%` }}
            />
          </div>
        </div>
      </div>

      {/* SELECT CYCLE BOX (X TOTAL CYCLES) - MATCHING DOCUMENT TAB */}
      <div className="bg-[#11141c] border border-white/10 rounded-2xl p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Select Cycle Box ({qurah.cycles.length} Total Cycles)
          </h3>
          <span className="text-xs text-slate-400 font-mono">
            Selected: Cycle {selectedCycle.cycleNumber}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {qurah.cycles.map((c) => {
            const isSelected = c.cycleNumber === selectedCycle.cycleNumber;
            const cyclePaid = qurah.members.filter((m) => !!c.payments[m.id]).length;
            const cycleAllPaid = cyclePaid === qurah.members.length;

            let borderStyle = 'border-white/10 bg-[#161a24] hover:border-white/20';
            let badgeBg = 'bg-white/5 text-slate-400';
            let statusText = 'Upcoming';

            if (c.status === 'completed') {
              borderStyle = 'border-emerald-500/30 bg-emerald-950/20 hover:border-emerald-500/50';
              badgeBg = 'bg-emerald-500/20 text-emerald-400 font-bold';
              statusText = 'Completed';
            } else if (c.status === 'current') {
              borderStyle = 'border-white/40 bg-[#1e2533] hover:border-white/60';
              badgeBg = 'bg-white text-slate-950 font-bold';
              statusText = 'Active Now';
            }

            if (isSelected) {
              borderStyle += ' ring-2 ring-white shadow-md';
            }

            return (
              <div
                key={c.cycleNumber}
                onClick={() => setSelectedCycleNumber(c.cycleNumber)}
                className={`p-3.5 rounded-xl border cursor-pointer transition-all duration-150 flex flex-col justify-between ${borderStyle}`}
              >
                <div>
                  <div className="flex items-center justify-between gap-1 mb-1.5">
                    <span className="text-xs font-extrabold font-mono text-white">
                      Cycle {c.cycleNumber}
                    </span>
                    <span className={`text-[9px] px-2 py-0.5 rounded-full ${badgeBg}`}>
                      {statusText}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono">{c.drawDate}</div>
                </div>

                <div className="mt-3 pt-2 border-t border-white/5 flex items-center justify-between text-[11px]">
                  <span className="text-slate-500">Deposit:</span>
                  <span
                    className={`font-semibold ${
                      c.winner
                        ? 'text-emerald-400'
                        : cycleAllPaid
                        ? 'text-emerald-400'
                        : cyclePaid > 0
                        ? 'text-white'
                        : 'text-slate-500'
                    }`}
                  >
                    {c.winner
                      ? 'Drawn ✓'
                      : `${cyclePaid}/${qurah.members.length} Paid`}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Members (A - Z) Table (Matching Screenshot) */}
      <div className="bg-[#11141c] border border-white/10 rounded-2xl p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4 pb-3 border-b border-white/10">
          <div>
            <h3 className="text-sm font-bold text-white">Members (A - Z)</h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Click status button to toggle member payment for Cycle {selectedCycle.cycleNumber}.
            </p>
          </div>

          {/* "Draw & Documents" and "Draw Video" Buttons */}
          <div className="flex items-center gap-2 flex-wrap">
            {(selectedCycle.winner || isAllPaid) && (
              <button
                type="button"
                onClick={() => setIsVideoModalOpen(true)}
                className="px-4 py-2 rounded-full text-xs font-bold flex items-center gap-1.5 transition-all bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 shadow-md cursor-pointer"
              >
                <Video className="w-3.5 h-3.5" />
                <span>Draw Video (14s)</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => onNavigateToDocumentCycle(selectedCycle.cycleNumber)}
              disabled={!isAllPaid}
              className={`px-5 py-2 rounded-full text-xs font-bold flex items-center gap-2 transition-all ${
                isAllPaid
                  ? 'bg-white text-slate-950 hover:bg-slate-200 cursor-pointer shadow-md'
                  : 'bg-[#171c26] text-slate-500 border border-white/5 cursor-not-allowed'
              }`}
              title={
                isAllPaid
                  ? 'All paid! Navigates to Documents page to conduct draw and view certificates'
                  : `Locked: ${paidCount}/${qurah.members.length} members paid.`
              }
            >
              {isAllPaid ? <Award className="w-3.5 h-3.5 text-amber-500" /> : <Lock className="w-3.5 h-3.5" />}
              <span>Draw &amp; Documents</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Member Table Rows matching screenshot */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-white/5 text-slate-500 font-semibold uppercase text-[10px]">
                <th className="py-2.5 px-3 w-12">#</th>
                <th className="py-2.5 px-3">Name</th>
                <th className="py-2.5 px-3">Phone</th>
                <th className="py-2.5 px-3 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 font-medium">
              {qurah.members.map((member, idx) => {
                const isPaid = !!selectedCycle.payments[member.id];

                return (
                  <tr
                    key={member.id}
                    onClick={() => onTogglePayment(selectedCycle.cycleNumber, member.id)}
                    className="hover:bg-white/[0.03] transition-colors cursor-pointer group select-none"
                  >
                    <td className="py-3 px-3 font-mono text-slate-500">{idx + 1}</td>
                    <td className="py-3 px-3 font-bold text-white group-hover:text-slate-200">
                      {member.name}
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-400">{member.phone}</td>
                    <td className="py-3 px-3 text-right">
                      {isPaid ? (
                        <span className="inline-flex items-center gap-1.5 text-emerald-400 font-bold text-xs">
                          <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                          <span>Paid</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 text-slate-400 text-xs">
                          <span className="w-2 h-2 rounded-full border border-slate-500 inline-block" />
                          <span>Pending</span>
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* 14-Sec Al Qurah Draw Reveal Video Modal */}
      {isVideoModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
          <div className="relative w-full max-w-4xl my-auto">
            <AlQurahDrawRevealVideo
              qurah={qurah}
              cycle={selectedCycle}
              winnerName={selectedCycle.winner?.memberName}
              onClose={() => setIsVideoModalOpen(false)}
              autoPlay={true}
            />
          </div>
        </div>
      )}
    </div>
  );
};
