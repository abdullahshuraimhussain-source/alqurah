import React, { useState } from 'react';
import {
  ArrowLeft,
  LayoutDashboard,
  CreditCard,
  FileText,
  Users,
  ChevronRight,
  LogOut,
} from 'lucide-react';
import { Qurah, Cycle } from '../../types';
import { DashboardTab } from './DashboardTab';
import { PaymentTab } from './PaymentTab';
import { DocumentTab } from './DocumentTab';
import { MosqueSilhouette } from '../common/MosqueSilhouette';
import { Footer } from '../Footer';

interface QurahDetailPageProps {
  qurah: Qurah;
  onBack: () => void;
  onUpdateQurah: (updated: Qurah) => void;
  initialTab?: 'dashboard' | 'payment' | 'document';
  onNavigate?: (page: 'home' | 'workspace') => void;
  onLogout?: () => void;
}

export const QurahDetailPage: React.FC<QurahDetailPageProps> = ({
  qurah,
  onBack,
  onUpdateQurah,
  initialTab = 'payment',
  onNavigate,
  onLogout,
}) => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'payment' | 'document'>(initialTab);
  const [targetDocumentCycle, setTargetDocumentCycle] = useState<number | null>(null);

  // Toggle member payment for a cycle
  const handleTogglePayment = (cycleNumber: number, memberId: string) => {
    const updatedCycles = qurah.cycles.map((cycle) => {
      if (cycle.cycleNumber === cycleNumber) {
        const current = !!cycle.payments[memberId];
        return {
          ...cycle,
          payments: {
            ...cycle.payments,
            [memberId]: !current,
          },
        };
      }
      return cycle;
    });

    onUpdateQurah({
      ...qurah,
      cycles: updatedCycles,
    });
  };

  // Record winner and transition cycle
  const handleRecordWinner = (
    cycleNumber: number,
    winner: { memberId: string; memberName: string }
  ) => {
    let nextCycleFound = false;

    const updatedCycles = qurah.cycles.map((cycle) => {
      if (cycle.cycleNumber === cycleNumber) {
        return {
          ...cycle,
          status: 'completed' as const,
          winner: {
            ...winner,
            drawnAt: new Date().toISOString(),
            videoGenerated: true,
          },
        };
      }
      if (cycle.cycleNumber === cycleNumber + 1 && cycle.status === 'upcoming') {
        nextCycleFound = true;
        return {
          ...cycle,
          status: 'current' as const,
        };
      }
      return cycle;
    });

    const nextCycleNum = nextCycleFound ? cycleNumber + 1 : qurah.currentCycleNumber;
    const isFinished = !nextCycleFound && cycleNumber === qurah.memberCount;

    onUpdateQurah({
      ...qurah,
      currentCycleNumber: nextCycleNum,
      status: isFinished ? 'completed' : qurah.status,
      cycles: updatedCycles,
    });
  };

  // Navigate from payment tab to document tab focusing on that cycle
  const handleNavigateToDocumentCycle = (cycleNumber: number) => {
    setTargetDocumentCycle(cycleNumber);
    setActiveTab('document');
  };

  const getBreadcrumbLabel = () => {
    switch (activeTab) {
      case 'dashboard':
        return 'Dashboard';
      case 'payment':
        return 'Al Qurah Payment';
      case 'document':
        return 'Document';
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#050608] text-white">
      <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1 flex flex-col lg:flex-row gap-8">
        {/* SIDEBAR (Desktop: vertical sidebar; Mobile: compact top bar) */}
        <aside className="w-full lg:w-56 shrink-0 flex flex-col justify-between bg-[#0b0e14] border border-white/10 rounded-2xl p-3.5 sm:p-4 lg:min-h-[500px]">
          <div className="space-y-3 sm:space-y-4 lg:space-y-6">
            {/* Sidebar Brand & Active Qurah Indicator */}
            <div className="flex items-center justify-between lg:justify-start gap-2.5 px-1">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-lg bg-white/10 flex items-center justify-center text-white border border-white/15">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" className="w-3.5 h-3.5 sm:w-4 sm:h-4">
                    <path d="M4 21V10C4 6 7.5 3 12 3C16.5 3 20 6 20 10V21" />
                    <path d="M9 21V13C9 11.5 10.5 10 12 10C13.5 10 15 11.5 15 13V21" />
                  </svg>
                </div>
                <span className="text-xs sm:text-sm font-extrabold tracking-wider text-white">AL QURA</span>
              </div>
              <span className="lg:hidden text-[11px] text-slate-400 font-medium truncate max-w-[130px]">
                {qurah.name}
              </span>
            </div>

            {/* Nav Options: Grid on mobile, stack on desktop */}
            <nav className="grid grid-cols-3 lg:grid-cols-1 gap-1.5">
              <button
                type="button"
                onClick={() => setActiveTab('dashboard')}
                className={`w-full flex items-center justify-center lg:justify-start gap-2 lg:gap-3 px-2 sm:px-3.5 py-2 sm:py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'dashboard'
                    ? 'bg-white text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <LayoutDashboard className="w-4 h-4 shrink-0" />
                <span className="truncate">Dashboard</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('payment')}
                className={`w-full flex items-center justify-center lg:justify-start gap-2 lg:gap-3 px-2 sm:px-3.5 py-2 sm:py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'payment'
                    ? 'bg-white text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <CreditCard className="w-4 h-4 shrink-0" />
                <span className="truncate">Al Qurah Payment</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('document')}
                className={`w-full flex items-center justify-center lg:justify-start gap-2 lg:gap-3 px-2 sm:px-3.5 py-2 sm:py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'document'
                    ? 'bg-white text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <FileText className="w-4 h-4 shrink-0" />
                <span className="truncate">Document</span>
              </button>

              {onLogout && (
                <button
                  type="button"
                  onClick={onLogout}
                  className="w-full flex items-center justify-center lg:justify-start gap-2 lg:gap-3 px-2 sm:px-3.5 py-2 sm:py-2.5 rounded-xl text-xs font-bold transition-all text-slate-400 hover:text-rose-300 hover:bg-rose-500/10"
                >
                  <LogOut className="w-4 h-4 shrink-0" />
                  <span className="truncate">Logout</span>
                </button>
              )}
            </nav>
          </div>

          {/* Bottom Mosque Silhouette Watermark (visible on desktop) */}
          <div className="hidden lg:flex pt-6 pb-2 border-t border-white/5 flex-col items-center">
            <MosqueSilhouette className="w-24 h-14 text-slate-600 opacity-60" showText={true} />
          </div>
        </aside>

        {/* RIGHT MAIN DETAIL CONTENT */}
        <main className="flex-1 min-w-0">
          {/* Breadcrumb Row (Matching Screenshot: e.g. "Al Qurah Payment > Blessings Circle") */}
          <div className="flex items-center justify-between gap-4 mb-5">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-400">
              <button
                onClick={onBack}
                className="hover:text-white flex items-center gap-1.5 transition-colors"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>All Qurahs</span>
              </button>
              <span>&gt;</span>
              <span className="text-slate-300">{getBreadcrumbLabel()}</span>
              <span>&gt;</span>
              <span className="text-white font-bold">{qurah.name}</span>
            </div>
          </div>

          {/* Active Tab View */}
          {activeTab === 'dashboard' && <DashboardTab qurah={qurah} />}

          {activeTab === 'payment' && (
            <PaymentTab
              qurah={qurah}
              onTogglePayment={handleTogglePayment}
              onNavigateToDocumentCycle={handleNavigateToDocumentCycle}
            />
          )}

          {activeTab === 'document' && (
            <DocumentTab
              qurah={qurah}
              onRecordWinner={handleRecordWinner}
              initialCycleNumber={targetDocumentCycle || undefined}
            />
          )}
        </main>
      </div>

      <Footer onNavigate={onNavigate} />
    </div>
  );
};
