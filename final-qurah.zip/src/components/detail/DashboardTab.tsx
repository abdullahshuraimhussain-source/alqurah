import React, { useState } from 'react';
import {
  Users,
  DollarSign,
  Calendar,
  Clock,
  ShieldCheck,
  CheckCircle2,
  Trophy,
  Phone,
  Video,
} from 'lucide-react';
import { Qurah, Member } from '../../types';
import { AlQurahDrawRevealVideo } from '../media/AlQurahDrawRevealVideo';

interface DashboardTabProps {
  qurah: Qurah;
}

export const DashboardTab: React.FC<DashboardTabProps> = ({ qurah }) => {
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);
  const sortedMembers = [...qurah.members].sort((a, b) => a.order - b.order);
  const completedCycles = qurah.cycles.filter((c) => c.status === 'completed').length;
  const progressPct = Math.round((completedCycles / qurah.memberCount) * 100);

  const winnerMap = new Map<string, number>();
  qurah.cycles.forEach((c) => {
    if (c.winner) winnerMap.set(c.winner.memberId, c.cycleNumber);
  });

  // Find latest cycle with a winner or current cycle
  const latestDrawnCycle =
    [...qurah.cycles].reverse().find((c) => c.winner) ||
    qurah.cycles.find((c) => c.cycleNumber === qurah.currentCycleNumber) ||
    qurah.cycles[0];

  return (
    <div className="space-y-6">
      {/* Detail Header Card (Matching Screenshot) */}
      <div className="bg-[#11141c] border border-white/10 rounded-2xl p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-full bg-[#1b2230] border border-white/10 flex items-center justify-center text-white font-bold text-lg shrink-0">
              {qurah.name.charAt(0)}
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">{qurah.name}</h2>
              <p className="text-xs text-slate-400 mt-1">{qurah.description}</p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsVideoModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-extrabold text-xs flex items-center gap-1.5 transition-all shadow-md shrink-0 cursor-pointer"
          >
            <Video className="w-4 h-4" />
            <span>Al Qurah Draw Video (14s)</span>
          </button>
        </div>

        {/* 5 Stats Row horizontally (Matching Screenshot) */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 p-4 rounded-xl bg-[#0c0f15] border border-white/5 text-xs">
          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">
              Members
            </span>
            <span className="font-extrabold text-white text-sm mt-0.5 block">
              {qurah.memberCount} Members
            </span>
          </div>

          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">
              Per Member
            </span>
            <span className="font-extrabold font-mono text-white text-sm mt-0.5 block">
              {qurah.currencySymbol || 'Rs'} {qurah.amountPerMember.toLocaleString()}
            </span>
          </div>

          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">
              Total Amount
            </span>
            <span className="font-extrabold font-mono text-white text-sm mt-0.5 block">
              {qurah.currencySymbol || 'Rs'} {qurah.totalAmount.toLocaleString()}
            </span>
          </div>

          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">
              Start Date
            </span>
            <span className="font-medium text-slate-300 text-xs mt-0.5 block font-mono">
              {qurah.startDate}
            </span>
          </div>

          <div>
            <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">
              End Date
            </span>
            <span className="font-medium text-slate-300 text-xs mt-0.5 block font-mono">
              {qurah.endDate}
            </span>
          </div>
        </div>

        {/* Current Cycle Progress Banner */}
        <div className="mt-6 pt-4 border-t border-white/5">
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="font-bold text-white">
              Current Cycle: {qurah.currentCycleNumber} of {qurah.memberCount}
            </span>
            <span className="font-mono text-slate-400">{progressPct}%</span>
          </div>
          <div className="w-full h-1.5 bg-[#1b2230] rounded-full overflow-hidden">
            <div
              className="h-full bg-white rounded-full transition-all duration-300"
              style={{ width: `${Math.max(5, progressPct)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Member Roster Table (Matching Screenshot "Members (A - Z)") */}
      <div className="bg-[#11141c] border border-white/10 rounded-2xl p-6">
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-white/10">
          <h3 className="text-sm font-bold text-white">Members (A - Z)</h3>
          <span className="text-xs text-slate-400 font-mono">
            {qurah.memberCount} Registered Members
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-white/5 text-slate-500 font-semibold uppercase text-[10px]">
                <th className="py-2.5 px-3 w-12">#</th>
                <th className="py-2.5 px-3">Name</th>
                <th className="py-2.5 px-3">Phone</th>
                <th className="py-2.5 px-3 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 font-medium">
              {sortedMembers.map((member, idx) => {
                const wonCycleNumber = winnerMap.get(member.id);

                return (
                  <tr key={member.id} className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-3 px-3 font-mono text-slate-500">{idx + 1}</td>
                    <td className="py-3 px-3 font-bold text-white">{member.name}</td>
                    <td className="py-3 px-3 font-mono text-slate-400">{member.phone}</td>
                    <td className="py-3 px-3 text-right">
                      {wonCycleNumber ? (
                        <span className="inline-flex items-center gap-1.5 text-amber-400 font-semibold text-xs">
                          <Trophy className="w-3.5 h-3.5" />
                          <span>Won Cycle {wonCycleNumber}</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 text-slate-400 text-xs">
                          <span>Upcoming Draw</span>
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* 14-Sec Al Qurah Draw Reveal Video Modal */}
      {isVideoModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
          <div className="relative w-full max-w-4xl my-auto">
            <AlQurahDrawRevealVideo
              qurah={qurah}
              cycle={latestDrawnCycle}
              winnerName={latestDrawnCycle.winner?.memberName}
              onClose={() => setIsVideoModalOpen(false)}
              autoPlay={true}
            />
          </div>
        </div>
      )}
    </div>
  );
};
