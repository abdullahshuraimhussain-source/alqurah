import React from 'react';
import { Plus, LogIn, LogOut, User as UserIcon } from 'lucide-react';
import { User } from '../types';

interface NavbarProps {
  currentPage: 'home' | 'workspace' | 'detail' | 'login' | 'signup' | 'forgot-password' | '404';
  onNavigate: (page: 'home' | 'workspace' | 'login' | 'signup' | '404') => void;
  onCreateQurahClick: () => void;
  currentUser: User | null;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentPage,
  onNavigate,
  onCreateQurahClick,
  currentUser,
  onLogout,
}) => {
  return (
    <header className="sticky top-0 z-50 bg-[#0a0c10]/95 backdrop-blur-md border-b border-white/10 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand Logo & Name */}
        <div
          className="flex items-center gap-2.5 cursor-pointer select-none"
          onClick={() => onNavigate('home')}
        >
          <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center text-white border border-white/15">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" className="w-5 h-5">
              <path d="M4 21V10C4 6 7.5 3 12 3C16.5 3 20 6 20 10V21" />
              <path d="M9 21V13C9 11.5 10.5 10 12 10C13.5 10 15 11.5 15 13V21" />
            </svg>
          </div>
          <span className="text-base font-extrabold tracking-wider text-white">AL QURA</span>
        </div>

        {/* Center Navigation Links */}
        <nav className="flex items-center gap-1.5 sm:gap-2 text-xs font-medium text-slate-300">
          <button
            type="button"
            onClick={() => onNavigate('home')}
            className={`px-3 sm:px-4 py-1.5 rounded-full transition-all ${
              currentPage === 'home'
                ? 'bg-white text-slate-950 font-bold shadow-xs'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            Home
          </button>

          <button
            type="button"
            onClick={() => onNavigate('workspace')}
            className={`px-3 sm:px-4 py-1.5 rounded-full transition-all ${
              currentPage === 'workspace' || currentPage === 'detail'
                ? 'bg-white text-slate-950 font-bold shadow-xs'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            Your Qurahs
          </button>
        </nav>

        {/* Right Section: Auth & Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {currentUser ? (
            <>
              {/* User Identity Pill */}
              <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs">
                <div className="w-5 h-5 rounded-full bg-white/10 flex items-center justify-center text-slate-300">
                  <UserIcon className="w-3 h-3" />
                </div>
                <span className="font-semibold text-slate-200 max-w-[120px] truncate">
                  {currentUser.name || currentUser.email.split('@')[0]}
                </span>
              </div>

              {/* Logout Button */}
              <button
                type="button"
                onClick={onLogout}
                title="Logout"
                className="p-1.5 sm:px-3 sm:py-1.5 rounded-full text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 border border-transparent hover:border-rose-500/20 text-xs font-medium flex items-center gap-1.5 transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Logout</span>
              </button>

              {/* Create Qurah CTA */}
              <button
                type="button"
                onClick={onCreateQurahClick}
                className="px-3.5 sm:px-4 py-1.5 rounded-full bg-white text-slate-950 hover:bg-slate-200 text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                <span className="hidden xs:inline sm:inline">Create Qurah</span>
              </button>
            </>
          ) : (
            <>
              {/* Unauthenticated State */}
              <button
                type="button"
                onClick={() => onNavigate('login')}
                className={`px-3.5 py-1.5 rounded-full border border-white/20 hover:border-white/40 text-xs font-semibold text-slate-200 hover:text-white transition-all ${
                  currentPage === 'login' ? 'bg-white/10 text-white border-white/40' : 'bg-transparent'
                }`}
              >
                Log In
              </button>

              <button
                type="button"
                onClick={() => onNavigate('signup')}
                className="px-4 py-1.5 rounded-full bg-white text-slate-950 hover:bg-slate-200 text-xs font-bold transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                Sign Up
              </button>
            </>
          )}
        </div>
      </div>
    </header>
  );
};
