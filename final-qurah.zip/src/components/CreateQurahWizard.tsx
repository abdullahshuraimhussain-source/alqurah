import React, { useState, useEffect } from 'react';
import {
  X,
  Plus,
  Minus,
  Users,
  Coins,
  Calendar,
  Clock,
  CheckCircle2,
  Phone,
  User as UserIcon,
  ShieldCheck,
  Check,
  Globe,
} from 'lucide-react';
import { Qurah, Member, CycleDurationOption, Cycle } from '../types';

interface CreateQurahWizardProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  onQurahCreated: (qurah: Qurah) => void;
}

export const CURRENCY_OPTIONS = [
  { code: 'PKR', symbol: 'Rs', name: 'Pakistani Rupee (PKR - Rs)' },
  { code: 'INR', symbol: '₹', name: 'Indian Rupee (INR - ₹)' },
  { code: 'USD', symbol: '$', name: 'US Dollar (USD - $)' },
  { code: 'SAR', symbol: '﷼', name: 'Saudi Riyal (SAR - ﷼)' },
  { code: 'AED', symbol: 'د.إ', name: 'UAE Dirham (AED - د.إ)' },
  { code: 'EUR', symbol: '€', name: 'Euro (EUR - €)' },
  { code: 'GBP', symbol: '£', name: 'British Pound (GBP - £)' },
];

export const CreateQurahWizard: React.FC<CreateQurahWizardProps> = ({
  isOpen,
  onClose,
  userId,
  onQurahCreated,
}) => {
  const [step, setStep] = useState<1 | 2 | 3>(1);

  // Step 1: Basic Details
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [memberCount, setMemberCount] = useState<number>(10);

  // Step 2: Amount, Currency & Duration
  const [currency, setCurrency] = useState<string>('PKR');
  const [currencySymbol, setCurrencySymbol] = useState<string>('Rs');
  const [amountPerMember, setAmountPerMember] = useState<number>(5000);
  const [durationOption, setDurationOption] = useState<CycleDurationOption>(15);
  const [customDays, setCustomDays] = useState<number>(10);
  const todayStr = new Date().toISOString().split('T')[0];
  const [startDate, setStartDate] = useState<string>(todayStr);
  const [endDate, setEndDate] = useState<string>('');

  // Step 3: Members Roster (Initialized with empty name & phone - no pre-filled names!)
  const [members, setMembers] = useState<{ name: string; phone: string }[]>([]);

  const activeCycleDurationDays =
    durationOption === 'custom'
      ? customDays
      : durationOption === 30
      ? 30
      : durationOption;

  const totalAmount = memberCount * amountPerMember;

  // Auto-calculate End Date
  useEffect(() => {
    if (!startDate) return;
    try {
      const d = new Date(startDate);
      const totalDays = memberCount * activeCycleDurationDays;
      d.setDate(d.getDate() + totalDays);
      setEndDate(d.toISOString().split('T')[0]);
    } catch {
      // safe
    }
  }, [startDate, memberCount, activeCycleDurationDays]);

  // Keep member count within [2, 20]
  const handleMemberCountChange = (val: number) => {
    if (isNaN(val)) {
      setMemberCount(2);
      return;
    }
    const clamped = Math.min(20, Math.max(2, val));
    setMemberCount(clamped);
  };

  // Sync member list with memberCount - Clean empty inputs, no mock names!
  useEffect(() => {
    setMembers((prev) => {
      const next = [...prev];
      if (next.length < memberCount) {
        while (next.length < memberCount) {
          next.push({ name: '', phone: '' });
        }
      } else if (next.length > memberCount) {
        return next.slice(0, memberCount);
      }
      return next;
    });
  }, [memberCount]);

  if (!isOpen) return null;

  const handleCurrencySelect = (code: string) => {
    const found = CURRENCY_OPTIONS.find((c) => c.code === code);
    if (found) {
      setCurrency(found.code);
      setCurrencySymbol(found.symbol);
    }
  };

  const handleMemberChange = (index: number, field: 'name' | 'phone', value: string) => {
    setMembers((prev) => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: value };
      return updated;
    });
  };

  const handleFinish = () => {
    const formattedMembers: Member[] = members.map((m, idx) => ({
      id: `m-${Date.now()}-${idx + 1}`,
      name: m.name.trim() || `Member ${idx + 1}`,
      phone: m.phone.trim() || '',
      order: idx + 1,
    }));

    const generatedCycles: Cycle[] = Array.from({ length: memberCount }, (_, i) => {
      const cNum = i + 1;
      const cStart = new Date(startDate);
      cStart.setDate(cStart.getDate() + i * activeCycleDurationDays);

      const cDraw = new Date(cStart);
      cDraw.setDate(cDraw.getDate() + activeCycleDurationDays);

      const initialPayments: Record<string, boolean> = {};
      formattedMembers.forEach((mem) => {
        initialPayments[mem.id] = false;
      });

      return {
        cycleNumber: cNum,
        startDate: cStart.toISOString().split('T')[0],
        drawDate: cDraw.toISOString().split('T')[0],
        status: cNum === 1 ? 'current' : 'upcoming',
        payments: initialPayments,
      };
    });

    const newQurah: Qurah = {
      id: `qura-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      userId,
      name: name.trim() || 'Blessings Circle',
      description: description.trim() || 'A simple and blessed interest-free committee.',
      memberCount,
      amountPerMember,
      currency,
      currencySymbol,
      totalAmount,
      cycleDurationDays: activeCycleDurationDays,
      durationOption,
      startDate,
      endDate: endDate || startDate,
      currentCycleNumber: 1,
      status: 'active',
      createdAt: new Date().toISOString(),
      members: formattedMembers,
      cycles: generatedCycles,
    };

    onQurahCreated(newQurah);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-150">
      <div className="relative w-full max-w-xl bg-[#11141c] rounded-3xl shadow-2xl border border-white/15 overflow-hidden flex flex-col max-h-[92vh] text-white">
        {/* Top Header */}
        <div className="p-5 sm:p-6 border-b border-white/10 flex items-center justify-between">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">Create Qurah</h2>
            <p className="text-[11px] text-slate-400 mt-0.5">Interest-Free Islamic Committee</p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* 3 Step Indicator */}
        <div className="px-6 py-3.5 border-b border-white/5 flex items-center justify-between text-xs bg-[#0b0e14]/50">
          <div className="flex items-center gap-2">
            <span
              className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                step === 1 ? 'bg-white text-slate-950' : 'bg-white/10 text-slate-400'
              }`}
            >
              1
            </span>
            <span className={step === 1 ? 'text-white font-bold' : 'text-slate-500'}>
              Basic Details
            </span>
          </div>

          <div className="w-8 h-px bg-white/10" />

          <div className="flex items-center gap-2">
            <span
              className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                step === 2 ? 'bg-white text-slate-950' : 'bg-white/10 text-slate-400'
              }`}
            >
              2
            </span>
            <span className={step === 2 ? 'text-white font-bold' : 'text-slate-500'}>
              Amount &amp; Duration
            </span>
          </div>

          <div className="w-8 h-px bg-white/10" />

          <div className="flex items-center gap-2">
            <span
              className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                step === 3 ? 'bg-white text-slate-950' : 'bg-white/10 text-slate-400'
              }`}
            >
              3
            </span>
            <span className={step === 3 ? 'text-white font-bold' : 'text-slate-500'}>Members</span>
          </div>
        </div>

        {/* Wizard Slide Body */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-4 text-xs">
          {/* STEP 1: Basic Details */}
          {step === 1 && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div>
                <label className="block font-bold text-slate-300 mb-1.5">Qurah Name *</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Family Qurah, Friends Circle"
                  className="w-full bg-[#161a24] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-white/40"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1.5">Description</label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Purpose or rules of this committee..."
                  className="w-full bg-[#161a24] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-white/40"
                />
              </div>

              {/* Number of Members: Manual Input (Min 2, Max 20) */}
              <div className="pt-1">
                <div className="flex items-center justify-between mb-1.5">
                  <label className="font-bold text-slate-300">Number of Members *</label>
                  <span className="text-[11px] text-emerald-400 font-mono">Max 20 Members</span>
                </div>

                <div className="flex items-center gap-3">
                  {/* Stepper Buttons and Manual Number Input */}
                  <div className="flex items-center bg-[#161a24] border border-white/15 rounded-xl overflow-hidden p-1">
                    <button
                      type="button"
                      onClick={() => handleMemberCountChange(memberCount - 1)}
                      disabled={memberCount <= 2}
                      className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/15 disabled:opacity-40 flex items-center justify-center text-white transition-colors"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <input
                      type="number"
                      min={2}
                      max={20}
                      value={memberCount}
                      onChange={(e) => handleMemberCountChange(parseInt(e.target.value) || 2)}
                      className="w-16 text-center bg-transparent text-white font-mono font-bold text-sm focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => handleMemberCountChange(memberCount + 1)}
                      disabled={memberCount >= 20}
                      className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/15 disabled:opacity-40 flex items-center justify-center text-white transition-colors"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Quick Select Presets */}
                  <div className="flex-1 flex flex-wrap gap-1.5">
                    {[5, 8, 10, 12, 15, 20].map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => handleMemberCountChange(preset)}
                        className={`px-2.5 py-1.5 rounded-lg text-[11px] font-mono font-bold transition-all border ${
                          memberCount === preset
                            ? 'bg-white text-slate-950 border-white'
                            : 'bg-[#161a24] text-slate-400 border-white/10 hover:border-white/25 hover:text-white'
                        }`}
                      >
                        {preset}
                      </button>
                    ))}
                  </div>
                </div>
                <p className="text-[11px] text-slate-500 mt-1.5">
                  Enter any number between 2 and 20. Total cycles will match the number of members ({memberCount} cycles).
                </p>
              </div>
            </div>
          )}

          {/* STEP 2: Amount, Currency & Duration */}
          {step === 2 && (
            <div className="space-y-4 animate-in fade-in duration-150">
              {/* Currency Selector (Rupees Default) */}
              <div>
                <label className="block font-bold text-slate-300 mb-1.5 flex items-center justify-between">
                  <span>Currency *</span>
                  <span className="text-[11px] text-slate-400 font-normal">Default: Rupees (PKR)</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {CURRENCY_OPTIONS.map((c) => (
                    <button
                      key={c.code}
                      type="button"
                      onClick={() => handleCurrencySelect(c.code)}
                      className={`p-2 rounded-xl text-left transition-all border flex items-center justify-between ${
                        currency === c.code
                          ? 'bg-white text-slate-950 border-white font-bold shadow-sm'
                          : 'bg-[#161a24] text-slate-300 border-white/10 hover:border-white/20'
                      }`}
                    >
                      <span className="font-mono text-xs">{c.code}</span>
                      <span className="font-mono font-bold text-xs opacity-90">{c.symbol}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Amount per Member */}
              <div>
                <label className="block font-bold text-slate-300 mb-1.5">
                  Amount per Member ({currencySymbol}) *
                </label>
                <div className="relative">
                  <div className="absolute left-3.5 top-2.5 text-slate-400 font-mono font-bold text-xs">
                    {currencySymbol}
                  </div>
                  <input
                    type="number"
                    min={100}
                    step={100}
                    value={amountPerMember}
                    onChange={(e) => setAmountPerMember(Math.max(10, parseInt(e.target.value) || 0))}
                    className="w-full bg-[#161a24] border border-white/10 rounded-xl pl-11 pr-4 py-2.5 text-xs text-white font-mono font-bold focus:outline-none focus:border-white/40"
                    placeholder="Enter installment amount"
                  />
                </div>
              </div>

              {/* Auto-calculated Total Pool Card */}
              <div className="p-4 rounded-xl bg-[#171c26] border border-white/10 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                    Total Pooled per Cycle
                  </span>
                  <span className="text-[11px] text-slate-400 font-medium">
                    {memberCount} members &times; {currencySymbol} {amountPerMember.toLocaleString()}
                  </span>
                </div>
                <div className="text-xl font-extrabold font-mono text-white">
                  {currencySymbol} {totalAmount.toLocaleString()}
                </div>
              </div>

              {/* Duration per Cycle: 7 Days, 15 Days, 1 Month, Custom */}
              <div>
                <label className="block font-bold text-slate-300 mb-1.5">
                  Qurah Duration per Cycle *
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => setDurationOption(7)}
                    className={`py-2.5 rounded-xl text-xs font-bold transition-all border ${
                      durationOption === 7
                        ? 'bg-white text-slate-950 border-white'
                        : 'bg-[#161a24] text-slate-300 border-white/10 hover:border-white/20'
                    }`}
                  >
                    7 Days
                  </button>

                  <button
                    type="button"
                    onClick={() => setDurationOption(15)}
                    className={`py-2.5 rounded-xl text-xs font-bold transition-all border ${
                      durationOption === 15
                        ? 'bg-white text-slate-950 border-white'
                        : 'bg-[#161a24] text-slate-300 border-white/10 hover:border-white/20'
                    }`}
                  >
                    15 Days
                  </button>

                  <button
                    type="button"
                    onClick={() => setDurationOption(30)}
                    className={`py-2.5 rounded-xl text-xs font-bold transition-all border ${
                      durationOption === 30
                        ? 'bg-white text-slate-950 border-white'
                        : 'bg-[#161a24] text-slate-300 border-white/10 hover:border-white/20'
                    }`}
                  >
                    1 Month
                  </button>

                  <button
                    type="button"
                    onClick={() => setDurationOption('custom')}
                    className={`py-2.5 rounded-xl text-xs font-bold transition-all border ${
                      durationOption === 'custom'
                        ? 'bg-white text-slate-950 border-white'
                        : 'bg-[#161a24] text-slate-300 border-white/10 hover:border-white/20'
                    }`}
                  >
                    Custom
                  </button>
                </div>

                {/* If Custom Duration selected, show days input */}
                {durationOption === 'custom' && (
                  <div className="mt-2.5 p-3 rounded-xl bg-[#161a24] border border-white/10 flex items-center justify-between gap-3 animate-in fade-in duration-100">
                    <span className="text-slate-300 font-medium">Custom Cycle Days:</span>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        min={1}
                        max={365}
                        value={customDays}
                        onChange={(e) => setCustomDays(Math.max(1, parseInt(e.target.value) || 1))}
                        className="w-20 bg-[#0d1017] border border-white/15 rounded-lg px-3 py-1.5 text-center text-xs font-mono font-bold text-white focus:outline-none"
                      />
                      <span className="text-slate-400 font-medium">Days</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Start & End Dates */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Start Date</label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full bg-[#161a24] border border-white/10 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Calculated End Date</label>
                  <input
                    type="date"
                    value={endDate}
                    readOnly
                    className="w-full bg-[#161a24]/60 border border-white/5 rounded-xl px-3 py-2 text-xs text-slate-400 cursor-not-allowed"
                  />
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: Members Roster - Two Separate Columns (Name & Number), No Auto-filled Names! */}
          {step === 3 && (
            <div className="space-y-3 animate-in fade-in duration-150">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-bold text-white">Enter Member Details</span>
                  <span className="text-slate-400 ml-2">({memberCount} Members)</span>
                </div>
                <span className="text-[11px] text-emerald-400 font-mono font-semibold">
                  0% Interest Islamic Committee
                </span>
              </div>

              {/* Two Column Headers: Name Column & Phone Number Column */}
              <div className="grid grid-cols-12 gap-2 text-slate-400 font-bold px-3 py-2 bg-[#0c0f15] border border-white/10 rounded-xl text-[11px]">
                <div className="col-span-1 text-center text-slate-500">#</div>
                <div className="col-span-6 text-slate-300">Member Name *</div>
                <div className="col-span-5 text-slate-300">Phone / WhatsApp Number</div>
              </div>

              {/* Member Rows with Empty Inputs (No pre-filled dummy names) */}
              <div className="max-h-72 overflow-y-auto space-y-2 pr-1">
                {members.map((member, idx) => (
                  <div
                    key={idx}
                    className="p-2 bg-[#161a24] border border-white/10 hover:border-white/20 rounded-xl grid grid-cols-12 gap-2 items-center text-xs transition-colors"
                  >
                    {/* Index Badge */}
                    <div className="col-span-1 flex justify-center">
                      <span className="w-5 h-5 rounded-full bg-white/10 text-slate-300 font-mono font-bold flex items-center justify-center text-[10px]">
                        {idx + 1}
                      </span>
                    </div>

                    {/* Column 1: Member Name (Empty input, placeholder only) */}
                    <div className="col-span-6">
                      <input
                        type="text"
                        value={member.name}
                        onChange={(e) => handleMemberChange(idx, 'name', e.target.value)}
                        placeholder={`Member ${idx + 1} Name`}
                        className="w-full bg-[#0e121a] border border-white/10 focus:border-white/30 rounded-lg px-2.5 py-1.5 text-white text-xs focus:outline-none placeholder-slate-500 font-medium"
                      />
                    </div>

                    {/* Column 2: Phone Number (Empty input, placeholder only) */}
                    <div className="col-span-5">
                      <input
                        type="text"
                        value={member.phone}
                        onChange={(e) => handleMemberChange(idx, 'phone', e.target.value)}
                        placeholder="e.g. 0300-1234567"
                        className="w-full bg-[#0e121a] border border-white/10 focus:border-white/30 rounded-lg px-2.5 py-1.5 text-slate-200 font-mono text-xs focus:outline-none placeholder-slate-500"
                      />
                    </div>
                  </div>
                ))}
              </div>

              <p className="text-[11px] text-slate-500 italic pt-1">
                * Names and phone numbers are entered manually. Leave blank to default to &quot;Member #&quot;.
              </p>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-5 border-t border-white/10 flex items-center justify-between bg-[#0b0e14]/50">
          <button
            type="button"
            onClick={step === 1 ? onClose : () => setStep((s) => (s - 1) as 1 | 2 | 3)}
            className="px-5 py-2.5 rounded-full border border-white/20 hover:border-white/40 text-slate-300 hover:text-white text-xs font-semibold transition-colors"
          >
            {step === 1 ? 'Cancel' : 'Back'}
          </button>

          {step < 3 ? (
            <button
              type="button"
              onClick={() => setStep((s) => (s + 1) as 1 | 2 | 3)}
              className="px-7 py-2.5 rounded-full bg-white text-slate-950 hover:bg-slate-200 text-xs font-bold transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              Next
            </button>
          ) : (
            <button
              type="button"
              onClick={handleFinish}
              className="px-7 py-2.5 rounded-full bg-white text-slate-950 hover:bg-slate-200 text-xs font-bold transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              Finish &amp; Create Qurah
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
