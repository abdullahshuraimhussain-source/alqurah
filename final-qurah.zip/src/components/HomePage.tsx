import React from 'react';
import { User } from '../types';
import { Footer } from './Footer';
import { IslamicVaultHeroGraphic } from './home/IslamicVaultHeroGraphic';

interface HomePageProps {
  currentUser: User | null;
  onNavigateToWorkspace: () => void;
  onCreateQurahClick: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onNavigateToWorkspace,
  onCreateQurahClick,
}) => {
  return (
    <div className="min-h-screen flex flex-col bg-[#050608] text-white">
      {/* HERO SECTION */}
      <section className="relative overflow-hidden flex-1 flex items-center py-10 sm:py-16">
        {/* Subtle dark ambient glow */}
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[250px] bg-slate-800/15 blur-[140px] rounded-full pointer-events-none" />

        <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-center">
            {/* Left Content (7 cols on lg) */}
            <div className="lg:col-span-7 space-y-6 text-left">
              {/* Pill badge: Interest-Free Islamic Committee Drow */}
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs font-semibold text-slate-300">
                <span>Interest-Free Islamic Committee Drow</span>
              </div>

              {/* Headline */}
              <h1 className="text-4xl sm:text-5xl lg:text-[54px] font-black tracking-tight text-white leading-[1.08]">
                Together We Grow
                <br />
                <span className="text-white">We Share We Win</span>
              </h1>

              {/* Paragraph description */}
              <p className="text-slate-400 text-xs sm:text-sm max-w-lg leading-relaxed">
                Al Qura is an Islamic committee-draw platform where members pool money, and each cycle a member receives the total amount. No interest. Just mutual help and blessings.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-3.5 pt-2">
                <button
                  type="button"
                  onClick={onCreateQurahClick}
                  className="px-6 py-2.5 rounded-full bg-white text-slate-950 hover:bg-slate-200 text-xs sm:text-sm font-bold shadow-md shadow-white/10 transition-all hover:scale-[1.02] active:scale-[0.98]"
                >
                  Create a Qurah
                </button>

                <button
                  type="button"
                  onClick={onNavigateToWorkspace}
                  className="px-6 py-2.5 rounded-full border border-white/20 hover:border-white/40 text-white hover:bg-white/5 text-xs sm:text-sm font-medium transition-all"
                >
                  Your Qurahs
                </button>
              </div>
            </div>

            {/* Center/Right 3D Islamic Mihrab Vault Graphic (5 cols on lg) */}
            <div className="lg:col-span-5 flex items-center justify-center my-4 lg:my-0">
              <IslamicVaultHeroGraphic />
            </div>
          </div>
        </div>
      </section>

      {/* COMPACT FOOTER */}
      <Footer onNavigate={onNavigateToWorkspace} />
    </div>
  );
};
