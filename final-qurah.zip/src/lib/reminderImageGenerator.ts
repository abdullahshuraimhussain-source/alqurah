import { Qurah, Cycle, StoredReminderImage } from '../types';

export const REMINDER_VARIANTS: (7 | 3 | 1)[] = [7, 3, 1];

/**
 * Calculates the cycle's total duration in days.
 * Checks start and draw dates, falling back to qurah.cycleDurationDays.
 */
export const getCycleTotalDuration = (qurah: Qurah, cycle: Cycle): number => {
  if (cycle.startDate && cycle.drawDate) {
    const start = new Date(cycle.startDate).getTime();
    const end = new Date(cycle.drawDate).getTime();
    const diffDays = Math.round((end - start) / (1000 * 60 * 60 * 24));
    if (diffDays > 0) return diffDays;
  }
  return qurah.cycleDurationDays || 15;
};

/**
 * Requirement:
 * "only generate a variant if the cycle's total duration is longer than that many days"
 */
export const isVariantEligible = (variantDays: 7 | 3 | 1, cycleTotalDuration: number): boolean => {
  return cycleTotalDuration > variantDays;
};

/**
 * Formats a date string (YYYY-MM-DD) into a clean, human-readable format.
 */
export const formatDrawDate = (dateStr: string): string => {
  try {
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return dateStr;
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return dateStr;
  }
};

/**
 * Draws the vector Mosque Silhouette logo on canvas context.
 */
function drawMosqueIcon(ctx: CanvasRenderingContext2D, centerX: number, topY: number, isUrgent: boolean) {
  ctx.save();
  ctx.translate(centerX - 45, topY);
  const scale = 0.75;
  ctx.scale(scale, scale);

  ctx.fillStyle = isUrgent ? '#ef4444' : '#ffffff';
  ctx.strokeStyle = isUrgent ? '#ef4444' : '#ffffff';

  // Left Minaret
  ctx.fillRect(14, 24, 5, 42);
  ctx.beginPath();
  ctx.moveTo(16.5, 12);
  ctx.lineTo(13, 24);
  ctx.lineTo(20, 24);
  ctx.closePath();
  ctx.fill();
  ctx.beginPath();
  ctx.arc(16.5, 11, 1.5, 0, Math.PI * 2);
  ctx.fill();

  // Left-center small dome
  ctx.beginPath();
  ctx.moveTo(24, 66);
  ctx.lineTo(24, 38);
  ctx.quadraticCurveTo(33, 24, 42, 38);
  ctx.lineTo(42, 66);
  ctx.closePath();
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(33, 21);
  ctx.lineTo(31.5, 24);
  ctx.lineTo(34.5, 24);
  ctx.closePath();
  ctx.fill();

  // Central Grand Dome
  ctx.beginPath();
  ctx.moveTo(40, 66);
  ctx.lineTo(40, 34);
  ctx.quadraticCurveTo(60, 12, 80, 34);
  ctx.lineTo(80, 66);
  ctx.closePath();
  ctx.fill();

  // Central Dome Finial & Crescent
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(60, 12);
  ctx.lineTo(60, 4);
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(60, 5, 2.5, 0, Math.PI * 2);
  ctx.fill();

  // Right-center small dome
  ctx.beginPath();
  ctx.moveTo(78, 66);
  ctx.lineTo(78, 38);
  ctx.quadraticCurveTo(87, 24, 96, 38);
  ctx.lineTo(96, 66);
  ctx.closePath();
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(87, 21);
  ctx.lineTo(85.5, 24);
  ctx.lineTo(88.5, 24);
  ctx.closePath();
  ctx.fill();

  // Right Minaret
  ctx.fillRect(101, 24, 5, 42);
  ctx.beginPath();
  ctx.moveTo(103.5, 12);
  ctx.lineTo(100, 24);
  ctx.lineTo(107, 24);
  ctx.closePath();
  ctx.fill();
  ctx.beginPath();
  ctx.arc(103.5, 11, 1.5, 0, Math.PI * 2);
  ctx.fill();

  // Base line
  ctx.fillRect(8, 66, 104, 2.5);

  ctx.restore();
}

/**
 * Helper to draw rounded rectangle on canvas
 */
function drawRoundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
  fill = false,
  stroke = true
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
  if (fill) ctx.fill();
  if (stroke) ctx.stroke();
}

/**
 * Generates an ultra-crisp 1:1 square (1080x1080) reminder image on an HTML5 canvas.
 * Strict specifications:
 * - 7 Days: Square (1:1), dark/black monochrome background, bold large centered '7' with 'DAYS REMAINING'
 * - 3 Days: Identical layout/structure/fields, bold large centered '3' with 'DAYS REMAINING', dark/black monochrome
 * - 1 Day: Same exact layout and fields, reddish urgent tint instead of plain black background, large centered '1' in red/red-white with 'DAY REMAINING' below it
 * - Fields: Qurah name, Qurah cycle number, exact draw date, total members count, small AL QURA logo (mosque-silhouette icon + wordmark) at top.
 * - No photos of living beings.
 */
export const renderReminderCanvas = (
  canvas: HTMLCanvasElement,
  variantDays: 7 | 3 | 1,
  qurah: Qurah,
  cycle: Cycle
): string => {
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  const size = 1080;
  canvas.width = size;
  canvas.height = size;

  const isUrgent = variantDays === 1;
  const qurahName = qurah.name || 'Blessings Circle';
  const cycleNumber = cycle.cycleNumber || 1;
  const totalCycles = qurah.cycles.length || qurah.memberCount;
  const formattedDate = formatDrawDate(cycle.drawDate);
  const memberCount = qurah.memberCount || qurah.members.length;

  // 1. BACKGROUND
  if (isUrgent) {
    // Reddish urgent tint (deep red to red-black gradient)
    const bgGrad = ctx.createLinearGradient(0, 0, size, size);
    bgGrad.addColorStop(0, '#1c0407');
    bgGrad.addColorStop(0.35, '#0e0204');
    bgGrad.addColorStop(0.7, '#190306');
    bgGrad.addColorStop(1, '#090102');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, size, size);

    // Urgent Center Radial Glow
    const glow = ctx.createRadialGradient(size / 2, 450, 40, size / 2, 450, 420);
    glow.addColorStop(0, 'rgba(239, 68, 68, 0.22)');
    glow.addColorStop(0.6, 'rgba(185, 28, 28, 0.08)');
    glow.addColorStop(1, 'transparent');
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, size, size);

    // Top subtle warning ambient beam
    const topBeam = ctx.createLinearGradient(size / 2, 0, size / 2, 220);
    topBeam.addColorStop(0, 'rgba(239, 68, 68, 0.16)');
    topBeam.addColorStop(1, 'transparent');
    ctx.fillStyle = topBeam;
    ctx.fillRect(0, 0, size, 220);
  } else {
    // Dark/black monochrome background (matching site's global black theme)
    const bgGrad = ctx.createLinearGradient(0, 0, size, size);
    bgGrad.addColorStop(0, '#06080d');
    bgGrad.addColorStop(0.4, '#0e121a');
    bgGrad.addColorStop(0.75, '#090c12');
    bgGrad.addColorStop(1, '#040508');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, size, size);

    // Subtle monochrome center radial accent
    const centerGlow = ctx.createRadialGradient(size / 2, 450, 30, size / 2, 450, 380);
    centerGlow.addColorStop(0, 'rgba(255, 255, 255, 0.04)');
    centerGlow.addColorStop(1, 'transparent');
    ctx.fillStyle = centerGlow;
    ctx.fillRect(0, 0, size, size);
  }

  // 2. OUTER & INNER ARCHITECTURAL FRAMES
  ctx.save();
  if (isUrgent) {
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.35)';
    ctx.lineWidth = 1.5;
    drawRoundRect(ctx, 40, 40, size - 80, size - 80, 24, false, true);

    ctx.strokeStyle = 'rgba(239, 68, 68, 0.12)';
    ctx.lineWidth = 1;
    drawRoundRect(ctx, 52, 52, size - 104, size - 104, 18, false, true);
  } else {
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
    ctx.lineWidth = 1.5;
    drawRoundRect(ctx, 40, 40, size - 80, size - 80, 24, false, true);

    ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
    ctx.lineWidth = 1;
    drawRoundRect(ctx, 52, 52, size - 104, size - 104, 18, false, true);
  }

  // Corner decorative dots
  const corners = [
    [64, 64],
    [size - 64, 64],
    [64, size - 64],
    [size - 64, size - 64],
  ];
  ctx.fillStyle = isUrgent ? 'rgba(239, 68, 68, 0.6)' : 'rgba(255, 255, 255, 0.25)';
  corners.forEach(([cx, cy]) => {
    ctx.beginPath();
    ctx.arc(cx, cy, 3, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.restore();

  // 3. TOP SECTION: AL QURA LOGO (MOSQUE SILHOUETTE + WORDMARK)
  drawMosqueIcon(ctx, size / 2, 75, isUrgent);

  // Wordmark "AL QURA"
  ctx.fillStyle = '#ffffff';
  ctx.font = '800 24px "Plus Jakarta Sans", "Montserrat", sans-serif';
  ctx.textAlign = 'center';
  ctx.letterSpacing = '5px';
  ctx.fillText('AL QURA', size / 2, 160);

  // Subtle Brand Subtitle / Sharia Verification
  if (isUrgent) {
    ctx.fillStyle = '#f87171';
    ctx.font = '700 11px "Plus Jakarta Sans", sans-serif';
    ctx.letterSpacing = '3px';
    ctx.fillText('URGENT DRAW NOTICE • 0% SOOD MUTUAL SAVINGS', size / 2, 182);
  } else {
    ctx.fillStyle = '#94a3b8';
    ctx.font = '600 11px "Plus Jakarta Sans", sans-serif';
    ctx.letterSpacing = '3px';
    ctx.fillText('ISLAMIC INTEREST-FREE MUTUAL SAVINGS', size / 2, 182);
  }

  // 4. QURAH NAME & CYCLE NUMBER HEADER
  // Qurah Name
  ctx.fillStyle = '#ffffff';
  ctx.font = '700 30px "Plus Jakarta Sans", "Montserrat", sans-serif';
  ctx.letterSpacing = '0.5px';
  ctx.fillText(qurahName, size / 2, 230);

  // Cycle Pill
  const pillW = 260;
  const pillH = 34;
  const pillX = (size - pillW) / 2;
  const pillY = 248;

  ctx.save();
  if (isUrgent) {
    ctx.fillStyle = 'rgba(239, 68, 68, 0.15)';
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.35)';
  } else {
    ctx.fillStyle = 'rgba(255, 255, 255, 0.06)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.14)';
  }
  ctx.lineWidth = 1;
  drawRoundRect(ctx, pillX, pillY, pillW, pillH, 17, true, true);

  ctx.fillStyle = isUrgent ? '#fca5a5' : '#cbd5e1';
  ctx.font = '700 13px "Plus Jakarta Sans", "Montserrat", monospace';
  ctx.letterSpacing = '2px';
  ctx.fillText(`CYCLE ${cycleNumber} OF ${totalCycles}`, size / 2, pillY + 22);
  ctx.restore();

  // 5. CENTER COUNTDOWN NUMBER & LABEL
  // Large centered number
  ctx.textAlign = 'center';
  ctx.letterSpacing = '0px';

  if (isUrgent) {
    // Reddish urgent number
    ctx.save();
    ctx.shadowColor = 'rgba(239, 68, 68, 0.6)';
    ctx.shadowBlur = 30;
    const numGrad = ctx.createLinearGradient(size / 2, 300, size / 2, 510);
    numGrad.addColorStop(0, '#ffffff');
    numGrad.addColorStop(0.3, '#fca5a5');
    numGrad.addColorStop(1, '#ef4444');
    ctx.fillStyle = numGrad;
    ctx.font = '900 230px "Plus Jakarta Sans", "Montserrat", sans-serif';
    ctx.fillText(`${variantDays}`, size / 2, 485);
    ctx.restore();

    // Urgent Label: "DAY REMAINING" (singular)
    ctx.fillStyle = '#f87171';
    ctx.font = '800 34px "Plus Jakarta Sans", "Montserrat", sans-serif';
    ctx.letterSpacing = '6px';
    ctx.fillText('DAY REMAINING', size / 2, 545);
  } else {
    // Bold white monochrome number
    ctx.save();
    ctx.shadowColor = 'rgba(0, 0, 0, 0.8)';
    ctx.shadowBlur = 20;
    const numGrad = ctx.createLinearGradient(size / 2, 300, size / 2, 510);
    numGrad.addColorStop(0, '#ffffff');
    numGrad.addColorStop(0.85, '#e2e8f0');
    numGrad.addColorStop(1, '#cbd5e1');
    ctx.fillStyle = numGrad;
    ctx.font = '900 230px "Plus Jakarta Sans", "Montserrat", sans-serif';
    ctx.fillText(`${variantDays}`, size / 2, 485);
    ctx.restore();

    // "DAYS REMAINING"
    ctx.fillStyle = '#f1f5f9';
    ctx.font = '800 34px "Plus Jakarta Sans", "Montserrat", sans-serif';
    ctx.letterSpacing = '6px';
    ctx.fillText('DAYS REMAINING', size / 2, 545);
  }

  // 6. FIELDS CONTAINER (Qurah name, cycle number, exact draw date, total members count)
  const boxW = 880;
  const boxH = 190;
  const boxX = (size - boxW) / 2;
  const boxY = 620;

  ctx.save();
  if (isUrgent) {
    ctx.fillStyle = 'rgba(239, 68, 68, 0.06)';
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.25)';
  } else {
    ctx.fillStyle = 'rgba(255, 255, 255, 0.03)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.10)';
  }
  ctx.lineWidth = 1.5;
  drawRoundRect(ctx, boxX, boxY, boxW, boxH, 20, true, true);

  // Divide into 3 columns for balanced information layout
  const colW = boxW / 3;

  // Column Dividers
  ctx.strokeStyle = isUrgent ? 'rgba(239, 68, 68, 0.15)' : 'rgba(255, 255, 255, 0.08)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(boxX + colW, boxY + 25);
  ctx.lineTo(boxX + colW, boxY + boxH - 25);
  ctx.moveTo(boxX + colW * 2, boxY + 25);
  ctx.lineTo(boxX + colW * 2, boxY + boxH - 25);
  ctx.stroke();

  // Column 1: EXACT DRAW DATE
  const col1Center = boxX + colW * 0.5;
  ctx.textAlign = 'center';
  ctx.letterSpacing = '2px';
  ctx.font = '700 12px "Plus Jakarta Sans", sans-serif';
  ctx.fillStyle = isUrgent ? '#fca5a5' : '#94a3b8';
  ctx.fillText('EXACT DRAW DATE', col1Center, boxY + 55);

  ctx.letterSpacing = '0px';
  ctx.font = '800 20px "Plus Jakarta Sans", "Montserrat", sans-serif';
  ctx.fillStyle = '#ffffff';
  ctx.fillText(formattedDate, col1Center, boxY + 95);

  ctx.font = '600 12px "Plus Jakarta Sans", sans-serif';
  ctx.fillStyle = isUrgent ? 'rgba(252, 165, 165, 0.8)' : '#64748b';
  ctx.fillText('Scheduled Draw Day', col1Center, boxY + 125);

  // Column 2: TOTAL MEMBERS
  const col2Center = boxX + colW * 1.5;
  ctx.letterSpacing = '2px';
  ctx.font = '700 12px "Plus Jakarta Sans", sans-serif';
  ctx.fillStyle = isUrgent ? '#fca5a5' : '#94a3b8';
  ctx.fillText('TOTAL MEMBERS', col2Center, boxY + 55);

  ctx.letterSpacing = '0px';
  ctx.font = '800 24px "Plus Jakarta Sans", "Montserrat", monospace';
  ctx.fillStyle = '#ffffff';
  ctx.fillText(`${memberCount} Members`, col2Center, boxY + 95);

  ctx.font = '600 12px "Plus Jakarta Sans", sans-serif';
  ctx.fillStyle = isUrgent ? 'rgba(252, 165, 165, 0.8)' : '#64748b';
  ctx.fillText('Active Participants', col2Center, boxY + 125);

  // Column 3: QURAH & CYCLE
  const col3Center = boxX + colW * 2.5;
  ctx.letterSpacing = '2px';
  ctx.font = '700 12px "Plus Jakarta Sans", sans-serif';
  ctx.fillStyle = isUrgent ? '#fca5a5' : '#94a3b8';
  ctx.fillText('CYCLE NUMBER', col3Center, boxY + 55);

  ctx.letterSpacing = '0px';
  ctx.font = '800 22px "Plus Jakarta Sans", "Montserrat", monospace';
  ctx.fillStyle = '#ffffff';
  ctx.fillText(`Cycle ${cycleNumber}`, col3Center, boxY + 95);

  ctx.font = '600 12px "Plus Jakarta Sans", sans-serif';
  ctx.fillStyle = isUrgent ? 'rgba(252, 165, 165, 0.8)' : '#64748b';
  ctx.fillText('Official Draw Turn', col3Center, boxY + 125);

  ctx.restore();

  // 7. BOTTOM BANNER & COMPLIANCE
  const bottomY = 880;

  // Urgent Notice or Sharia Seal Banner
  ctx.save();
  const bannerW = 680;
  const bannerH = 46;
  const bannerX = (size - bannerW) / 2;

  if (isUrgent) {
    ctx.fillStyle = 'rgba(239, 68, 68, 0.12)';
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.35)';
  } else {
    ctx.fillStyle = 'rgba(255, 255, 255, 0.04)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
  }
  ctx.lineWidth = 1;
  drawRoundRect(ctx, bannerX, bottomY, bannerW, bannerH, 23, true, true);

  ctx.textAlign = 'center';
  ctx.font = '700 12px "Plus Jakarta Sans", sans-serif';
  ctx.letterSpacing = '2.5px';
  ctx.fillStyle = isUrgent ? '#ef4444' : '#34d399';
  const bannerText = isUrgent
    ? 'FINAL CALL • ENSURE CONTRIBUTIONS ARE COMPLETED'
    : '100% INTEREST-FREE • ZERO RIBA (0% SOOD)';
  ctx.fillText(bannerText, size / 2, bottomY + 28);
  ctx.restore();

  // Bottom Tagline
  ctx.fillStyle = '#475569';
  ctx.font = '600 11px "Plus Jakarta Sans", sans-serif';
  ctx.letterSpacing = '2px';
  ctx.fillText('AL QURA VAULT RECORD • TOGETHER WE GROW • WE SHARE WE WIN', size / 2, 975);

  return canvas.toDataURL('image/png');
};

/**
 * Generates all eligible reminder image variants for a given Qurah cycle,
 * creating StoredReminderImage objects.
 */
export const generateEligibleReminderImages = (
  qurah: Qurah,
  cycle: Cycle
): Record<number, StoredReminderImage> => {
  const duration = getCycleTotalDuration(qurah, cycle);
  const eligibleVariants = REMINDER_VARIANTS.filter((v) => isVariantEligible(v, duration));

  // Use an offscreen canvas
  const canvas = document.createElement('canvas');
  const results: Record<number, StoredReminderImage> = {};
  const now = new Date().toISOString();

  eligibleVariants.forEach((variant) => {
    try {
      const dataUrl = renderReminderCanvas(canvas, variant, qurah, cycle);
      results[variant] = {
        variantDays: variant,
        cycleNumber: cycle.cycleNumber,
        qurahId: qurah.id,
        qurahName: qurah.name,
        drawDate: cycle.drawDate,
        memberCount: qurah.memberCount,
        dataUrl,
        generatedAt: now,
      };
    } catch (err) {
      console.error(`Failed to generate ${variant}-day reminder:`, err);
    }
  });

  return results;
};
