// Web Audio API sound synthesizer for Cinematic Draw Reveal Video
export class SoundEffects {
  private ctx: AudioContext | null = null;
  public enabled: boolean = true;
  private destinationNode: AudioNode | null = null;

  public initCtx(): AudioContext | null {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public getContext(): AudioContext | null {
    return this.initCtx();
  }

  public setRecordingDestination(node: AudioNode | null) {
    this.destinationNode = node;
  }

  private connect(node: AudioNode) {
    if (!this.ctx) return;
    try {
      node.connect(this.ctx.destination);
      if (this.destinationNode) {
        node.connect(this.destinationNode);
      }
    } catch {
      // safe
    }
  }

  // Gentle realistic paper shuffle in a ceramic/glass bowl
  public playShuffle() {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const bufferSize = Math.floor(this.ctx.sampleRate * 0.6);
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);

      // Filtered granular noise for paper chits
      for (let i = 0; i < bufferSize; i++) {
        const envelope = Math.sin((Math.PI * i) / bufferSize);
        data[i] = (Math.random() * 2 - 1) * envelope * 0.7;
      }

      const noise = this.ctx.createBufferSource();
      noise.buffer = buffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1100, now);
      filter.frequency.exponentialRampToValueAtTime(750, now + 0.6);
      filter.Q.setValueAtTime(2.2, now);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);

      noise.connect(filter);
      filter.connect(gain);
      this.connect(gain);

      noise.start(now);
    } catch {
      // safe
    }
  }

  // Glass ting / resonance when hand enters bowl
  public playGlassPing() {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const freqs = [1760, 2637];
      freqs.forEach((freq) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.9);
        osc.connect(gain);
        this.connect(gain);
        osc.start(now);
        osc.stop(now + 0.95);
      });
    } catch {
      // safe
    }
  }

  // Realistic crisp paper crease unfold sound
  public playUnfold() {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;

      // Part 1: high friction paper snap
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(280, now);
      osc.frequency.exponentialRampToValueAtTime(540, now + 0.12);

      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);

      osc.connect(gain);
      this.connect(gain);

      osc.start(now);
      osc.stop(now + 0.2);

      // Part 2: subtle paper flutter
      const bufferSize = Math.floor(this.ctx.sampleRate * 0.2);
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.25));
      }
      const noise = this.ctx.createBufferSource();
      noise.buffer = buffer;
      const noiseGain = this.ctx.createGain();
      noiseGain.gain.setValueAtTime(0.12, now);
      noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
      noise.connect(noiseGain);
      this.connect(noiseGain);
      noise.start(now);
    } catch {
      // safe
    }
  }

  // Premium, resonant, minimalist chime for verified winner
  public playChime() {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      // High-end minimalist glass/bell chime (A5, C#6, E6)
      const freqs = [880, 1108.73, 1318.51, 1760];
      freqs.forEach((freq, idx) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.04);

        gain.gain.setValueAtTime(0.16, now + idx * 0.04);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.04 + 1.8);

        osc.connect(gain);
        this.connect(gain);

        osc.start(now + idx * 0.04);
        osc.stop(now + idx * 0.04 + 1.9);
      });
    } catch {
      // safe
    }
  }

  // Radiant whoosh / shimmer for the bright light flare reveal
  public playFlare() {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const freqs = [523.25, 659.25, 783.99, 1046.5, 1318.51, 1567.98, 2093.0];
      freqs.forEach((freq, idx) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.03);
        osc.frequency.exponentialRampToValueAtTime(freq * 1.6, now + 0.9);

        gain.gain.setValueAtTime(0.12, now + idx * 0.03);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 1.5);

        osc.connect(gain);
        this.connect(gain);

        osc.start(now + idx * 0.03);
        osc.stop(now + 1.6);
      });
    } catch {
      // safe
    }
  }

  // Suspense riser for the countdown to chit reveal
  public playSuspenseRiser() {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(120, now);
      osc.frequency.exponentialRampToValueAtTime(440, now + 2.0);

      gain.gain.setValueAtTime(0.02, now);
      gain.gain.linearRampToValueAtTime(0.18, now + 1.9);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 2.1);

      osc.connect(gain);
      this.connect(gain);
      osc.start(now);
      osc.stop(now + 2.2);
    } catch {
      // safe
    }
  }

  // Triumphant Roster chords when the full member list appears
  public playRosterFanfare() {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const chords = [
        [523.25, 659.25, 783.99], // C major
        [587.33, 739.99, 880.0],  // D major
        [659.25, 830.61, 987.77], // E major
        [783.99, 987.77, 1174.66, 1567.98], // G major high
      ];

      chords.forEach((chord, chordIdx) => {
        if (!this.ctx) return;
        const time = now + chordIdx * 0.22;
        chord.forEach((freq) => {
          if (!this.ctx) return;
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(freq, time);
          gain.gain.setValueAtTime(0.07, time);
          gain.gain.exponentialRampToValueAtTime(0.0001, time + 1.2);
          osc.connect(gain);
          this.connect(gain);
          osc.start(time);
          osc.stop(time + 1.3);
        });
      });
    } catch {
      // safe
    }
  }
}

export const soundEffects = new SoundEffects();
