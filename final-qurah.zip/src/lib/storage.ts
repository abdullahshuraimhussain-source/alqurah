import { Qurah, User, StoredReminderImage } from '../types';

const USERS_KEY = 'alqura_users_v2';
const CURRENT_USER_KEY = 'alqura_current_user_v2';
const QURAS_KEY = 'alqura_items_v5';

export const DEFAULT_USER: User = {
  id: 'user-tariq-001',
  email: 'tariq@example.com',
  name: 'Tariq Al-Mansoor',
  createdAt: '2026-01-15T10:00:00Z',
};

export const SECOND_USER: User = {
  id: 'user-fatima-002',
  email: 'fatima@example.com',
  name: 'Fatima Zahra',
  createdAt: '2026-02-01T10:00:00Z',
};

export const StorageService = {
  // Clear any legacy test data from earlier sessions
  cleanLegacyData(): void {
    try {
      localStorage.removeItem('alqura_items_v1');
      localStorage.removeItem('alqura_items_v2');
      localStorage.removeItem('alqura_items_v3');
      localStorage.removeItem('alqura_items_v4');
    } catch {
      // ignore
    }
  },

  // User management
  getUsers(): User[] {
    try {
      const raw = localStorage.getItem(USERS_KEY);
      if (!raw) {
        const initial = [DEFAULT_USER, SECOND_USER];
        localStorage.setItem(USERS_KEY, JSON.stringify(initial));
        return initial;
      }
      return JSON.parse(raw);
    } catch {
      return [DEFAULT_USER, SECOND_USER];
    }
  },

  getCurrentUser(): User {
    try {
      const raw = localStorage.getItem(CURRENT_USER_KEY);
      if (raw) return JSON.parse(raw);
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(DEFAULT_USER));
      return DEFAULT_USER;
    } catch {
      return DEFAULT_USER;
    }
  },

  setCurrentUser(user: User): void {
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
  },

  registerUser(name: string, email: string): User {
    const users = this.getUsers();
    const newUser: User = {
      id: `user-${Date.now()}`,
      name,
      email,
      createdAt: new Date().toISOString(),
    };
    users.push(newUser);
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    this.setCurrentUser(newUser);
    return newUser;
  },

  loginUser(email: string): User {
    const users = this.getUsers();
    const existing = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (existing) {
      this.setCurrentUser(existing);
      return existing;
    }
    // Auto-create if new
    const name = email.split('@')[0].replace(/[._]/g, ' ');
    const formattedName = name.charAt(0).toUpperCase() + name.slice(1);
    return this.registerUser(formattedName, email);
  },

  logoutUser(): void {
    localStorage.removeItem(CURRENT_USER_KEY);
  },

  // Qura persistence (clean slate: user starts with 0 Qurahs and creates their own!)
  getAllQuras(): Qurah[] {
    try {
      this.cleanLegacyData();
      const raw = localStorage.getItem(QURAS_KEY);
      if (!raw) {
        localStorage.setItem(QURAS_KEY, JSON.stringify([]));
        return [];
      }
      return JSON.parse(raw);
    } catch {
      return [];
    }
  },

  getUserQuras(userId: string): Qurah[] {
    const all = this.getAllQuras();
    const userQuras = all.filter((q) => q.userId === userId);
    if (userQuras.length > 0) return userQuras;

    // Provide default starter Qurah with 15-day cycle duration so Document tab is instantly testable
    const starterQura: Qurah = {
      id: `qura-starter-${userId || 'default'}`,
      userId: userId || 'default',
      name: 'Al-Barakah Prosperity Circle',
      description: '100% Interest-free community mutual savings committee.',
      memberCount: 5,
      amountPerMember: 25000,
      currency: 'PKR',
      currencySymbol: 'Rs',
      totalAmount: 125000,
      cycleDurationDays: 15,
      durationOption: 15,
      startDate: '2026-04-01',
      endDate: '2026-06-15',
      currentCycleNumber: 1,
      status: 'active',
      createdAt: new Date().toISOString(),
      members: [
        { id: `m-1`, name: 'Tariq Al-Mansoor', phone: '+92 300 1234567', order: 1 },
        { id: `m-2`, name: 'Zubair Ahmed', phone: '+92 321 7654321', order: 2 },
        { id: `m-3`, name: 'Bilal Khan', phone: '+92 333 9876543', order: 3 },
        { id: `m-4`, name: 'Hamza Farooq', phone: '+92 345 5556677', order: 4 },
        { id: `m-5`, name: 'Usman Ghani', phone: '+92 312 8889900', order: 5 },
      ],
      cycles: [
        {
          cycleNumber: 1,
          startDate: '2026-04-01',
          drawDate: '2026-04-15',
          status: 'current',
          payments: { 'm-1': true, 'm-2': true, 'm-3': false, 'm-4': false, 'm-5': false },
        },
        {
          cycleNumber: 2,
          startDate: '2026-04-16',
          drawDate: '2026-04-30',
          status: 'upcoming',
          payments: { 'm-1': false, 'm-2': false, 'm-3': false, 'm-4': false, 'm-5': false },
        },
        {
          cycleNumber: 3,
          startDate: '2026-05-01',
          drawDate: '2026-05-15',
          status: 'upcoming',
          payments: { 'm-1': false, 'm-2': false, 'm-3': false, 'm-4': false, 'm-5': false },
        },
        {
          cycleNumber: 4,
          startDate: '2026-05-16',
          drawDate: '2026-05-31',
          status: 'upcoming',
          payments: { 'm-1': false, 'm-2': false, 'm-3': false, 'm-4': false, 'm-5': false },
        },
        {
          cycleNumber: 5,
          startDate: '2026-06-01',
          drawDate: '2026-06-15',
          status: 'upcoming',
          payments: { 'm-1': false, 'm-2': false, 'm-3': false, 'm-4': false, 'm-5': false },
        },
      ],
    };
    this.saveQura(starterQura);
    return [starterQura];
  },

  getQuraById(id: string): Qurah | null {
    const all = this.getAllQuras();
    return all.find((q) => q.id === id) || null;
  },

  saveQura(qurah: Qurah): void {
    const all = this.getAllQuras();
    const index = all.findIndex((q) => q.id === qurah.id);
    if (index >= 0) {
      all[index] = qurah;
    } else {
      all.unshift(qurah);
    }
    localStorage.setItem(QURAS_KEY, JSON.stringify(all));
  },

  deleteQura(id: string): void {
    const all = this.getAllQuras().filter((q) => q.id !== id);
    localStorage.setItem(QURAS_KEY, JSON.stringify(all));
  },

  clearAllQuras(): void {
    localStorage.setItem(QURAS_KEY, JSON.stringify([]));
  },

  toggleMemberPayment(quraId: string, cycleNumber: number, memberId: string): Qurah | null {
    const qura = this.getQuraById(quraId);
    if (!qura) return null;

    const cycle = qura.cycles.find((c) => c.cycleNumber === cycleNumber);
    if (!cycle) return null;

    const currentStatus = !!cycle.payments[memberId];
    cycle.payments[memberId] = !currentStatus;

    this.saveQura(qura);
    return qura;
  },

  recordWinner(
    quraId: string,
    cycleNumber: number,
    winner: { memberId: string; memberName: string }
  ): Qurah | null {
    const qura = this.getQuraById(quraId);
    if (!qura) return null;

    const cycle = qura.cycles.find((c) => c.cycleNumber === cycleNumber);
    if (!cycle) return null;

    cycle.winner = {
      memberId: winner.memberId,
      memberName: winner.memberName,
      drawnAt: new Date().toISOString(),
      videoGenerated: true,
    };
    cycle.status = 'completed';

    // If next cycle exists, set it to current if it's upcoming
    const nextCycle = qura.cycles.find((c) => c.cycleNumber === cycleNumber + 1);
    if (nextCycle && nextCycle.status === 'upcoming') {
      nextCycle.status = 'current';
      qura.currentCycleNumber = cycleNumber + 1;
    } else if (!nextCycle) {
      qura.status = 'completed';
    }

    this.saveQura(qura);
    return qura;
  },

  // Reminder Images persistence for permanent retrieval
  getStoredReminderImages(
    quraId: string,
    cycleNumber: number
  ): Record<number, StoredReminderImage> {
    try {
      const key = `alqura_reminders_${quraId}_cycle_${cycleNumber}`;
      const raw = localStorage.getItem(key);
      if (raw) {
        return JSON.parse(raw);
      }
      // Also check if stored in cycle directly
      const qura = this.getQuraById(quraId);
      const cycle = qura?.cycles.find((c) => c.cycleNumber === cycleNumber);
      if (cycle && cycle.reminderImages) {
        return cycle.reminderImages;
      }
      return {};
    } catch {
      return {};
    }
  },

  saveStoredReminderImages(
    quraId: string,
    cycleNumber: number,
    images: Record<number, StoredReminderImage>
  ): void {
    try {
      const key = `alqura_reminders_${quraId}_cycle_${cycleNumber}`;
      localStorage.setItem(key, JSON.stringify(images));

      // Also persist on Qurah cycle
      const qura = this.getQuraById(quraId);
      if (qura) {
        const cycle = qura.cycles.find((c) => c.cycleNumber === cycleNumber);
        if (cycle) {
          cycle.reminderImages = {
            ...(cycle.reminderImages || {}),
            ...images,
          };
          this.saveQura(qura);
        }
      }
    } catch (err) {
      console.warn('Failed to save reminder images to storage:', err);
    }
  },
};
