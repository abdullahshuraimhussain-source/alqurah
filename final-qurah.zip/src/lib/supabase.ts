import { createClient, SupabaseClient, User as SupabaseUser, Session } from '@supabase/supabase-js';
// @ts-ignore
import { supabase as clientFromConfig } from '../supabaseClient';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Prefer client from supabaseClient.js, fallback to env variables if defined
let realClient: SupabaseClient | null = clientFromConfig || null;

export const isSupabaseConfigured = Boolean(
  realClient || (
    supabaseUrl &&
    supabaseAnonKey &&
    typeof supabaseUrl === 'string' &&
    supabaseUrl.startsWith('https://')
  )
);

if (!realClient && isSupabaseConfigured) {
  try {
    realClient = createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
      },
    });
  } catch (err) {
    console.warn('Failed to initialize Supabase client:', err);
  }
}

// Fallback Mock Auth Store for seamless preview testing when credentials are not yet entered
const LOCAL_AUTH_KEY = 'alqura_supabase_mock_session_v1';
const LOCAL_USERS_KEY = 'alqura_supabase_mock_users_v1';

type AuthListener = (event: string, session: Session | null) => void;
const listeners: Set<AuthListener> = new Set();

function getStoredMockUsers(): Record<string, { id: string; email: string; name: string; phone: string; password?: string }> {
  try {
    const raw = localStorage.getItem(LOCAL_USERS_KEY);
    return raw ? JSON.parse(raw) : {
      'tariq@example.com': {
        id: 'user-tariq-001',
        email: 'tariq@example.com',
        name: 'Tariq Al-Mansoor',
        phone: '+92 300 1234567',
        password: 'password123',
      },
    };
  } catch {
    return {};
  }
}

function saveStoredMockUsers(users: Record<string, { id: string; email: string; name: string; phone: string; password?: string }>) {
  try {
    localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify(users));
  } catch {
    // ignore
  }
}

function getStoredMockSession(): Session | null {
  try {
    const raw = localStorage.getItem(LOCAL_AUTH_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function setStoredMockSession(session: Session | null) {
  try {
    if (session) {
      localStorage.setItem(LOCAL_AUTH_KEY, JSON.stringify(session));
    } else {
      localStorage.removeItem(LOCAL_AUTH_KEY);
    }
    listeners.forEach((listener) => listener(session ? 'SIGNED_IN' : 'SIGNED_OUT', session));
  } catch {
    // ignore
  }
}

// Resilient wrapper interface for Supabase Auth
export const authService = {
  isConfigured(): boolean {
    return isSupabaseConfigured && realClient !== null;
  },

  async getSession(): Promise<{ session: Session | null; user: SupabaseUser | null }> {
    if (this.isConfigured() && realClient) {
      const { data, error } = await realClient.auth.getSession();
      if (error) {
        console.warn('Error fetching Supabase session:', error);
        return { session: null, user: null };
      }
      return { session: data.session, user: data.session?.user || null };
    }

    const session = getStoredMockSession();
    return { session, user: session?.user || null };
  },

  onAuthStateChange(callback: (event: string, session: Session | null) => void) {
    if (this.isConfigured() && realClient) {
      const { data } = realClient.auth.onAuthStateChange(callback);
      return {
        unsubscribe: () => data.subscription.unsubscribe(),
      };
    }

    listeners.add(callback);
    // Trigger initial callback
    const session = getStoredMockSession();
    callback(session ? 'INITIAL_SESSION' : 'SIGNED_OUT', session);

    return {
      unsubscribe: () => {
        listeners.delete(callback);
      },
    };
  },

  async signUp(params: {
    email: string;
    password: string;
    name: string;
    phone?: string;
  }): Promise<{ user: SupabaseUser | null; session: Session | null; error: string | null }> {
    const { email, password, name, phone } = params;

    if (this.isConfigured() && realClient) {
      const { data, error } = await realClient.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: name,
            name: name,
            phone: phone || '',
          },
        },
      });

      if (error) {
        return { user: null, session: null, error: error.message };
      }
      return { user: data.user, session: data.session, error: null };
    }

    // Local Fallback simulation
    const users = getStoredMockUsers();
    if (users[email.toLowerCase()]) {
      return { user: null, session: null, error: 'User with this email already exists.' };
    }

    const userId = `usr_${Date.now()}`;
    const newMockUser = {
      id: userId,
      email: email.toLowerCase(),
      name,
      phone: phone || '',
      password,
    };
    users[email.toLowerCase()] = newMockUser;
    saveStoredMockUsers(users);

    const mockSupabaseUser: SupabaseUser = {
      id: userId,
      app_metadata: {},
      user_metadata: { full_name: name, name, phone: phone || '' },
      aud: 'authenticated',
      created_at: new Date().toISOString(),
      email: email.toLowerCase(),
    };

    const mockSession: Session = {
      access_token: 'mock_token_' + Date.now(),
      token_type: 'bearer',
      expires_in: 3600,
      refresh_token: 'mock_refresh_' + Date.now(),
      user: mockSupabaseUser,
    };

    setStoredMockSession(mockSession);
    return { user: mockSupabaseUser, session: mockSession, error: null };
  },

  async signInWithPassword(params: {
    email: string;
    password: string;
  }): Promise<{ user: SupabaseUser | null; session: Session | null; error: string | null }> {
    const { email, password } = params;

    if (this.isConfigured() && realClient) {
      const { data, error } = await realClient.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        return { user: null, session: null, error: error.message };
      }
      return { user: data.user, session: data.session, error: null };
    }

    // Local Fallback simulation
    const users = getStoredMockUsers();
    const existing = users[email.toLowerCase()];
    if (!existing) {
      return { user: null, session: null, error: 'Invalid login credentials. User not found.' };
    }

    if (existing.password && existing.password !== password) {
      return { user: null, session: null, error: 'Invalid password. Please check and try again.' };
    }

    const mockSupabaseUser: SupabaseUser = {
      id: existing.id,
      app_metadata: {},
      user_metadata: { full_name: existing.name, name: existing.name, phone: existing.phone },
      aud: 'authenticated',
      created_at: new Date().toISOString(),
      email: existing.email,
    };

    const mockSession: Session = {
      access_token: 'mock_token_' + Date.now(),
      token_type: 'bearer',
      expires_in: 3600,
      refresh_token: 'mock_refresh_' + Date.now(),
      user: mockSupabaseUser,
    };

    setStoredMockSession(mockSession);
    return { user: mockSupabaseUser, session: mockSession, error: null };
  },

  async signInWithGoogle(): Promise<{ error: string | null }> {
    if (this.isConfigured() && realClient) {
      const { error } = await realClient.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: window.location.origin,
        },
      });
      if (error) return { error: error.message };
      return { error: null };
    }

    // Fallback simulation: signs in with a Google demo profile
    const googleEmail = 'google.user@example.com';
    const users = getStoredMockUsers();
    let user = users[googleEmail];
    if (!user) {
      user = {
        id: `usr_google_${Date.now()}`,
        email: googleEmail,
        name: 'Google User',
        phone: '+92 312 9876543',
      };
      users[googleEmail] = user;
      saveStoredMockUsers(users);
    }

    const mockSupabaseUser: SupabaseUser = {
      id: user.id,
      app_metadata: { provider: 'google' },
      user_metadata: { full_name: user.name, name: user.name, phone: user.phone },
      aud: 'authenticated',
      created_at: new Date().toISOString(),
      email: user.email,
    };

    const mockSession: Session = {
      access_token: 'mock_google_token_' + Date.now(),
      token_type: 'bearer',
      expires_in: 3600,
      refresh_token: 'mock_google_refresh_' + Date.now(),
      user: mockSupabaseUser,
    };

    setStoredMockSession(mockSession);
    return { error: null };
  },

  async resetPasswordForEmail(email: string): Promise<{ error: string | null }> {
    if (this.isConfigured() && realClient) {
      const { error } = await realClient.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/#reset-password`,
      });
      if (error) return { error: error.message };
      return { error: null };
    }

    // Local Fallback simulation
    const users = getStoredMockUsers();
    if (!users[email.toLowerCase()]) {
      return { error: 'No account found with this email address.' };
    }
    return { error: null };
  },

  async updatePassword(newPassword: string): Promise<{ error: string | null }> {
    if (this.isConfigured() && realClient) {
      const { error } = await realClient.auth.updateUser({
        password: newPassword,
      });
      if (error) return { error: error.message };
      return { error: null };
    }

    const current = getStoredMockSession();
    if (current && current.user && current.user.email) {
      const users = getStoredMockUsers();
      if (users[current.user.email]) {
        users[current.user.email].password = newPassword;
        saveStoredMockUsers(users);
      }
    }
    return { error: null };
  },

  async signOut(): Promise<void> {
    if (this.isConfigured() && realClient) {
      await realClient.auth.signOut();
    }
    setStoredMockSession(null);
  },
};
