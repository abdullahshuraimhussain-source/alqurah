export interface User {
  id: string;
  email: string;
  name: string;
  createdAt: string;
}

export interface Member {
  id: string;
  name: string;
  phone: string;
  order: number; // 1 to N
}

export type CycleDurationOption = 7 | 15 | 30 | 'custom';

export type CycleStatus = 'completed' | 'current' | 'upcoming';

export interface CyclePayment {
  memberId: string;
  paid: boolean;
  paidAt?: string;
}

export interface CycleWinner {
  memberId: string;
  memberName: string;
  drawnAt: string;
  videoGenerated: boolean;
  videoUrl?: string;
  winnerCardUrl?: string;
}

export interface StoredReminderImage {
  variantDays: 7 | 3 | 1;
  cycleNumber: number;
  qurahId: string;
  qurahName: string;
  drawDate: string;
  memberCount: number;
  dataUrl: string;
  generatedAt: string;
}

export interface Cycle {
  cycleNumber: number;
  startDate: string;
  drawDate: string;
  status: CycleStatus;
  payments: Record<string, boolean>; // memberId -> boolean
  winner?: CycleWinner;
  reminderImages?: Record<number, StoredReminderImage>;
}

export interface Qurah {
  id: string;
  userId: string;
  name: string;
  description: string;
  memberCount: number;
  amountPerMember: number;
  currency?: string;
  currencySymbol?: string;
  totalAmount: number; // memberCount * amountPerMember
  cycleDurationDays: number; // 7, 15, 30, or custom number
  durationOption: CycleDurationOption;
  startDate: string;
  endDate: string;
  members: Member[];
  cycles: Cycle[];
  currentCycleNumber: number;
  createdAt: string;
  status: 'active' | 'completed';
}

export interface ReminderPostConfig {
  daysLeft: number;
  qurahName: string;
  cycleNumber: number;
  drawDate: string;
  amount: number;
}
