import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HomePage } from './components/HomePage';
import { WorkspacePage } from './components/WorkspacePage';
import { CreateQurahWizard } from './components/CreateQurahWizard';
import { QurahDetailPage } from './components/detail/QurahDetailPage';
import { LoginPage } from './components/auth/LoginPage';
import { SignUpPage } from './components/auth/SignUpPage';
import { ForgotPasswordPage } from './components/auth/ForgotPasswordPage';
import { Footer } from './components/Footer';
import { NotFound } from '@/components/ui/not-found-2';
import { StorageService } from './lib/storage';
import { authService } from './lib/supabase';
// @ts-ignore
import { supabase } from './supabaseClient';
import { User, Qurah } from './types';

export default function App() {
  // Current Authenticated User state
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isInitializingAuth, setIsInitializingAuth] = useState(true);

  // Navigation State
  const [currentPage, setCurrentPage] = useState<
    'home' | 'workspace' | 'detail' | 'login' | 'signup' | 'forgot-password' | '404'
  >('home');
  const [selectedQurahId, setSelectedQurahId] = useState<string | null>(null);
  const [redirectNotice, setRedirectNotice] = useState<string | null>(null);
  const [isUpdatingPasswordMode, setIsUpdatingPasswordMode] = useState(false);
  const [prefillEmail, setPrefillEmail] = useState<string>('');
  const [signupSuccessMsg, setSignupSuccessMsg] = useState<string | null>(null);

  // Wizard Modal
  const [wizardOpen, setWizardOpen] = useState(false);

  // User's Quras loaded from storage
  const [quras, setQuras] = useState<Qurah[]>([]);

  // Helper to verify active session with supabase.auth.getSession() and redirect to /login if none exists
  const verifySessionOrRedirect = async (notice = 'Please sign in to access this page.'): Promise<boolean> => {
    try {
      const { data } = await supabase.auth.getSession();
      if (!data?.session) {
        if (typeof window !== 'undefined') {
          window.history.pushState({}, '', '/login');
        }
        setRedirectNotice(notice);
        setCurrentPage('login');
        setWizardOpen(false);
        return false;
      }
      return true;
    } catch {
      if (typeof window !== 'undefined') {
        window.history.pushState({}, '', '/login');
      }
      setCurrentPage('login');
      return false;
    }
  };

  // 1. Initialize Supabase Auth & Session Persistence
  useEffect(() => {
    let mounted = true;

    // Check URL hash for password recovery
    if (
      window.location.hash.includes('reset-password') ||
      window.location.hash.includes('type=recovery')
    ) {
      setIsUpdatingPasswordMode(true);
      setCurrentPage('forgot-password');
    }

    const initAuth = async () => {
      try {
        const { data } = await supabase.auth.getSession();
        const session = data?.session;
        if (mounted && session?.user) {
          const u: User = {
            id: session.user.id,
            email: session.user.email || '',
            name:
              session.user.user_metadata?.full_name ||
              session.user.user_metadata?.name ||
              session.user.email?.split('@')[0] ||
              'Member',
            createdAt: session.user.created_at || new Date().toISOString(),
          };
          setCurrentUser(u);

          const path = window.location.pathname;
          if (path === '/workspace') {
            setCurrentPage('workspace');
          } else if (path === '/signup') {
            setCurrentPage('signup');
          } else if (path === '/login') {
            setCurrentPage('login');
          } else if (path === '/404') {
            setCurrentPage('404');
          }
        } else if (mounted) {
          setCurrentUser(null);
          // If accessing private route with no session, redirect to /login
          const path = window.location.pathname;
          if (path === '/workspace' || path === '/detail' || path === '/dashboard') {
            window.history.pushState({}, '', '/login');
            setRedirectNotice('Please sign in to access your Qurahs and management tools.');
            setCurrentPage('login');
          } else if (path === '/signup') {
            setCurrentPage('signup');
          } else if (path === '/login') {
            setCurrentPage('login');
          } else if (path === '/404') {
            setCurrentPage('404');
          }
        }
      } catch (err) {
        console.warn('Error checking initial session:', err);
      } finally {
        if (mounted) {
          setIsInitializingAuth(false);
        }
      }
    };

    initAuth();

    // Listen to Supabase Auth State changes (Login, Logout, Token refresh)
    const { data: authListener } = supabase.auth.onAuthStateChange((event: string, session: any) => {
      if (!mounted) return;

      if (event === 'PASSWORD_RECOVERY') {
        setIsUpdatingPasswordMode(true);
        setCurrentPage('forgot-password');
      }

      if (session?.user) {
        const u: User = {
          id: session.user.id,
          email: session.user.email || '',
          name:
            session.user.user_metadata?.full_name ||
            session.user.user_metadata?.name ||
            session.user.email?.split('@')[0] ||
            'Member',
          createdAt: session.user.created_at || new Date().toISOString(),
        };
        setCurrentUser(u);
      } else {
        setCurrentUser(null);
        // If current page is private, redirect to /login
        setCurrentPage((prev) => {
          if (prev === 'workspace' || prev === 'detail') {
            if (typeof window !== 'undefined') {
              window.history.pushState({}, '', '/login');
            }
            return 'login';
          }
          return prev;
        });
      }
    });

    const handlePopState = async () => {
      const path = window.location.pathname;
      if (path === '/login') {
        setCurrentPage('login');
      } else if (path === '/signup') {
        setCurrentPage('signup');
      } else if (path === '/workspace' || path === '/detail' || path === '/dashboard') {
        const { data } = await supabase.auth.getSession();
        if (!data?.session) {
          window.history.pushState({}, '', '/login');
          setRedirectNotice('Please sign in to access this page.');
          setCurrentPage('login');
        } else {
          setCurrentPage(path === '/detail' ? 'detail' : 'workspace');
        }
      } else if (path === '/404') {
        setCurrentPage('404');
      } else if (path === '/') {
        setCurrentPage('home');
      } else {
        setCurrentPage('404');
      }
    };

    window.addEventListener('popstate', handlePopState);

    return () => {
      mounted = false;
      authListener?.subscription?.unsubscribe();
      window.removeEventListener('popstate', handlePopState);
    };
  }, []);

  // Guard private pages with supabase.auth.getSession()
  // if no session, redirect to /login
  useEffect(() => {
    if (isInitializingAuth) return;

    if (currentPage === 'workspace' || currentPage === 'detail') {
      supabase.auth.getSession().then(({ data }: any) => {
        if (!data?.session) {
          if (typeof window !== 'undefined') {
            window.history.pushState({}, '', '/login');
          }
          setRedirectNotice('Please sign in to access your Qurahs and management tools.');
          setCurrentPage('login');
        }
      });
    }
  }, [currentPage, isInitializingAuth]);

  // 2. Load User's Qurahs whenever currentUser changes
  useEffect(() => {
    if (currentUser) {
      const userQuras = StorageService.getUserQuras(currentUser.id);
      setQuras(userQuras);
    } else {
      setQuras([]);
    }
  }, [currentUser]);

  // Navigations with authentication protection
  const handleNavigate = async (target: 'home' | 'workspace' | 'login' | 'signup' | '404') => {
    setRedirectNotice(null);
    if (target === 'workspace') {
      const hasSession = await verifySessionOrRedirect('Please sign in to access your Qurahs and management tools.');
      if (!hasSession) return;
      if (typeof window !== 'undefined') {
        window.history.pushState({}, '', '/workspace');
      }
      setCurrentPage('workspace');
      setSelectedQurahId(null);
      return;
    }

    if (typeof window !== 'undefined') {
      window.history.pushState({}, '', target === 'home' ? '/' : `/${target}`);
    }
    setCurrentPage(target);
    setSelectedQurahId(null);
  };

  const handleOpenCreateWizard = async () => {
    const hasSession = await verifySessionOrRedirect('Please sign in to create an Islamic rotating committee (Qurah).');
    if (!hasSession) return;
    setWizardOpen(true);
  };

  // Auth Success Handler
  const handleAuthSuccess = () => {
    setRedirectNotice(null);
    setCurrentPage('home');
    if (typeof window !== 'undefined' && window.location.pathname !== '/') {
      window.history.pushState({}, '', '/');
    }
  };

  // Logout Handler
  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
    } catch (e) {
      console.warn('Sign out error:', e);
    }
    setCurrentUser(null);
    setQuras([]);
    setSelectedQurahId(null);
    setWizardOpen(false);
    if (typeof window !== 'undefined') {
      window.history.pushState({}, '', '/');
    }
    setCurrentPage('home');
  };

  // Handler for creating new Qurah
  const handleQurahCreated = (newQurah: Qurah) => {
    StorageService.saveQura(newQurah);
    if (currentUser) {
      setQuras(StorageService.getUserQuras(currentUser.id));
    }
    setSelectedQurahId(newQurah.id);
    setCurrentPage('detail');
  };

  // Handler for updating existing Qurah (payments, winners, etc.)
  const handleUpdateQurah = (updatedQurah: Qurah) => {
    StorageService.saveQura(updatedQurah);
    if (currentUser) {
      setQuras(StorageService.getUserQuras(currentUser.id));
    }
  };

  // Select Qura to open detail view (Protected)
  const handleSelectQurah = async (id: string) => {
    const hasSession = await verifySessionOrRedirect('Please sign in to view Qurah details.');
    if (!hasSession) return;
    setSelectedQurahId(id);
    setCurrentPage('detail');
  };

  // Selected Qura object
  const activeQurah = quras.find((q) => q.id === selectedQurahId) || null;

  // If still checking session on first load
  if (isInitializingAuth) {
    return (
      <div className="min-h-screen bg-[#050608] text-white flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-white/10 flex items-center justify-center text-white border border-white/15 animate-pulse">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" className="w-6 h-6">
              <path d="M4 21V10C4 6 7.5 3 12 3C16.5 3 20 6 20 10V21" />
              <path d="M9 21V13C9 11.5 10.5 10 12 10C13.5 10 15 11.5 15 13V21" />
            </svg>
          </div>
          <span className="text-xs font-bold tracking-widest text-slate-400 uppercase">Loading Al Qura...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050608] text-white flex flex-col font-sans selection:bg-white/20 selection:text-white">
      {/* Top Main Navigation Bar */}
      <Navbar
        currentPage={currentPage}
        onNavigate={handleNavigate}
        onCreateQurahClick={handleOpenCreateWizard}
        currentUser={currentUser}
        onLogout={handleLogout}
      />

      {/* Primary Page Router */}
      <div className="flex-1 flex flex-col">
        {currentPage === 'home' && (
          <HomePage
            currentUser={currentUser}
            onNavigateToWorkspace={() => handleNavigate('workspace')}
            onCreateQurahClick={handleOpenCreateWizard}
          />
        )}

        {/* AUTH PAGES */}
        {currentPage === 'login' && (
          <LoginPage
            onSuccess={handleAuthSuccess}
            onNavigateToSignUp={() => {
              setSignupSuccessMsg(null);
              setCurrentPage('signup');
            }}
            onNavigateToForgotPassword={() => {
              setIsUpdatingPasswordMode(false);
              setCurrentPage('forgot-password');
            }}
            redirectNotice={redirectNotice || undefined}
            initialEmail={prefillEmail}
            signupSuccessMessage={signupSuccessMsg || undefined}
          />
        )}

        {currentPage === 'signup' && (
          <SignUpPage
            onSuccess={handleAuthSuccess}
            onNavigateToLogin={(emailParam?: string, msgParam?: string) => {
              if (emailParam) setPrefillEmail(emailParam);
              if (msgParam) setSignupSuccessMsg(msgParam);
              if (typeof window !== 'undefined' && window.location.pathname !== '/login') {
                window.history.pushState({}, '', '/login');
              }
              setCurrentPage('login');
            }}
          />
        )}

        {currentPage === 'forgot-password' && (
          <ForgotPasswordPage
            onNavigateToLogin={() => {
              setIsUpdatingPasswordMode(false);
              setCurrentPage('login');
            }}
            isUpdatingPassword={isUpdatingPasswordMode}
            onPasswordUpdated={() => {
              setIsUpdatingPasswordMode(false);
              setCurrentPage('login');
            }}
          />
        )}

        {/* PROTECTED ROUTES */}
        {currentPage === 'workspace' && currentUser && (
          <WorkspacePage
            currentUser={currentUser}
            quras={quras}
            onSelectQura={handleSelectQurah}
            onCreateQurahClick={handleOpenCreateWizard}
            onNavigate={(page) => handleNavigate(page)}
          />
        )}

        {currentPage === 'detail' && currentUser && activeQurah && (
          <QurahDetailPage
            qurah={activeQurah}
            onBack={() => {
              setSelectedQurahId(null);
              setCurrentPage('workspace');
            }}
            onUpdateQurah={handleUpdateQurah}
            onNavigate={(page) => handleNavigate(page)}
            onLogout={handleLogout}
          />
        )}

        {/* 404 Not Found Page */}
        {currentPage === '404' && (
          <NotFound
            onGoHome={() => handleNavigate('home')}
            onExplore={() => handleNavigate('workspace')}
          />
        )}
      </div>

      {/* Footer */}
      <Footer
        onNavigate={(page) => {
          handleNavigate(page);
        }}
      />

      {/* Create Qurah Multi-Step Wizard Modal (Requires currentUser) */}
      {currentUser && (
        <CreateQurahWizard
          isOpen={wizardOpen}
          onClose={() => setWizardOpen(false)}
          userId={currentUser.id}
          onQurahCreated={handleQurahCreated}
        />
      )}
    </div>
  );
}
