import { createClient } from '@supabase/supabase-js';

// Project credentials (you can replace these anytime or configure via env)
const envUrl = typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_URL;
const envKey = typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_ANON_KEY;

const SUPABASE_URL = (envUrl && envUrl.startsWith('http')) ? envUrl : 'https://xbzglhbrxxnoucqkopyu.supabase.co';
const SUPABASE_PUBLIC_KEY = envKey || 'sb_publishable_cI0VbF0JIQ8WQjbR-_uU5w_s1e0qucN';

// Normalize the project URL (strips trailing /rest/v1/ if present)
const formattedUrl = (SUPABASE_URL.startsWith('http') ? SUPABASE_URL : SUPABASE_PUBLIC_KEY)
  .replace(/\/rest\/v1\/?$/, '')
  .trim();

// Normalize the key (in case URL and key were swapped)
const formattedKey = (SUPABASE_PUBLIC_KEY.startsWith('http') ? SUPABASE_URL : SUPABASE_PUBLIC_KEY).trim();

export const supabase = createClient(formattedUrl, formattedKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

export { SUPABASE_URL, SUPABASE_PUBLIC_KEY };
export default supabase;
